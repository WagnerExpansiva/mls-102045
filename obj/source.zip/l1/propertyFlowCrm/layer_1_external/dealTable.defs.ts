/// <mls fileReference="_102045_/l1/propertyFlowCrm/layer_1_external/dealTable.defs.ts" enhancement="_blank"/>

export const dealTableDefinition = {
  "schemaVersion": "2026-06-06",
  "artifactType": "table",
  "artifactId": "dealTable",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanTableDefinition",
    "stepId": 41,
    "planId": ""
  },
  "data": {
    "tableDefinition": {
      "tableId": "dealTable",
      "tableName": "deal",
      "title": "Negócios/Propostas",
      "purpose": "Armazenar registros de negócios e propostas comerciais vinculados a leads e imóveis, com pipeline de etapas",
      "moduleId": "propertyFlowCrm",
      "ownership": "moduleOwned",
      "layer": "layer_1_external",
      "tableKind": "transactional",
      "rootEntity": "Deal",
      "accessPolicy": {
        "directAccessAllowedFor": [
          "layer_3_usecases"
        ],
        "forbiddenFor": [
          "pages",
          "layer_2_controllers",
          "agents"
        ]
      },
      "columns": [
        {
          "name": "deal_id",
          "type": "uuid",
          "nullable": false,
          "primaryKey": true,
          "description": "Identificador único do negócio"
        },
        {
          "name": "lead_id",
          "type": "uuid",
          "nullable": false,
          "description": "ID do lead associado ao negócio"
        },
        {
          "name": "property_id",
          "type": "uuid",
          "nullable": false,
          "description": "ID do imóvel objeto do negócio"
        },
        {
          "name": "broker_id",
          "type": "uuid",
          "nullable": false,
          "description": "ID do corretor responsável pelo negócio"
        },
        {
          "name": "deal_type",
          "type": "varchar(20)",
          "nullable": false,
          "description": "Tipo do negócio (venda, locação)"
        },
        {
          "name": "proposed_value",
          "type": "decimal(15,2)",
          "nullable": false,
          "description": "Valor proposto pelo cliente"
        },
        {
          "name": "accepted_value",
          "type": "decimal(15,2)",
          "nullable": true,
          "description": "Valor aceito/negociado"
        },
        {
          "name": "pipeline_stage",
          "type": "varchar(20)",
          "nullable": false,
          "default": "proposal",
          "description": "Etapa atual no pipeline (proposal, negotiation, documentation, closing, won, lost)"
        },
        {
          "name": "status",
          "type": "varchar(10)",
          "nullable": false,
          "default": "open",
          "description": "Status do negócio (open, closed)"
        },
        {
          "name": "loss_reason",
          "type": "varchar(255)",
          "nullable": true,
          "description": "Motivo da perda do negócio, se aplicável"
        },
        {
          "name": "expected_close_date",
          "type": "date",
          "nullable": true,
          "description": "Data prevista para fechamento"
        },
        {
          "name": "actual_close_date",
          "type": "date",
          "nullable": true,
          "description": "Data real de fechamento"
        },
        {
          "name": "created_at",
          "type": "timestamptz",
          "nullable": false,
          "description": "Data de criação do registro"
        },
        {
          "name": "updated_at",
          "type": "timestamptz",
          "nullable": false,
          "description": "Data da última atualização"
        }
      ],
      "primaryKey": [
        "deal_id"
      ],
      "detailsColumn": {
        "enabled": true,
        "columnName": "details",
        "reason": "Armazenar notas e dados adicionais do negócio que não requerem filtragem frequente",
        "jsonSchemaRef": "DealDetails"
      },
      "foreignRefs": [
        {
          "fieldName": "lead_id",
          "targetEntity": "Lead",
          "targetOwnership": "mdmOwned",
          "reason": "Referência ao lead/cliente associado ao negócio"
        },
        {
          "fieldName": "property_id",
          "targetEntity": "Property",
          "targetOwnership": "mdmOwned",
          "reason": "Referência ao imóvel objeto do negócio"
        },
        {
          "fieldName": "broker_id",
          "targetEntity": "Broker",
          "targetOwnership": "mdmOwned",
          "reason": "Referência ao corretor responsável pelo negócio"
        }
      ],
      "indexes": [
        {
          "indexName": "idx_deal_lead_id",
          "columns": [
            "lead_id"
          ],
          "unique": false,
          "reason": "Busca de negócios por lead para visualização no tracker e dashboard"
        },
        {
          "indexName": "idx_deal_property_id",
          "columns": [
            "property_id"
          ],
          "unique": false,
          "reason": "Busca de negócios por imóvel para validação e listagem"
        },
        {
          "indexName": "idx_deal_broker_id",
          "columns": [
            "broker_id"
          ],
          "unique": false,
          "reason": "Busca de negócios por corretor para dashboard e relatórios"
        },
        {
          "indexName": "idx_deal_pipeline_stage",
          "columns": [
            "pipeline_stage"
          ],
          "unique": false,
          "reason": "Filtragem por etapa do pipeline para kanban e workflow"
        },
        {
          "indexName": "idx_deal_status",
          "columns": [
            "status"
          ],
          "unique": false,
          "reason": "Filtragem por status para listagem de negócios abertos/fechados"
        },
        {
          "indexName": "idx_deal_broker_stage",
          "columns": [
            "broker_id",
            "pipeline_stage"
          ],
          "unique": false,
          "reason": "Consulta combinada de negócios por corretor e etapa para dealsTrackerPage"
        },
        {
          "indexName": "idx_deal_expected_close",
          "columns": [
            "expected_close_date"
          ],
          "unique": false,
          "reason": "Filtragem por data prevista de fechamento para dashboard e alertas"
        }
      ],
      "metricUpdatePolicy": {
        "feedsMetrics": true,
        "updatedByLayer": "layer_3_usecases",
        "metricRefs": [
          "crmMetricsTable"
        ]
      },
      "rulesApplied": [
        "ruleDealRequiredFields",
        "ruleDealPipelineTransition",
        "ruleDealPropertyActive"
      ]
    },
    "defsPlan": {
      "fileName": "tables/dealTable.defs.ts",
      "exportName": "dealTableDefinition",
      "saveAsDefs": true
    }
  }
} as const;

export default dealTableDefinition;
