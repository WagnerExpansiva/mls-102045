/// <mls fileReference="_102045_/l1/propertyFlowCrm/layer_1_external/visitMetrics.defs.ts" enhancement="_blank"/>

export const visitMetricsTable = {
  "schemaVersion": "2026-06-06",
  "artifactType": "metricTable",
  "artifactId": "visitMetrics",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanMetricTableDefinition",
    "stepId": 45,
    "planId": ""
  },
  "data": {
    "metricTableDefinition": {
      "metricTableId": "visitMetrics",
      "tableName": "visit_metrics",
      "moduleId": "propertyFlowCrm",
      "title": "Métricas de Visitas",
      "purpose": "Rastrear agendamentos, reagendamentos e cancelamentos de visitas",
      "tableKind": "metricTimeseries",
      "storageEngine": "postgresTimescaleDB",
      "layer": "layer_1_external",
      "timeColumn": "event_time",
      "columns": [
        {
          "name": "event_time",
          "type": "timestamptz",
          "nullable": false,
          "default": "now()",
          "description": "Momento do evento de visita"
        },
        {
          "name": "broker_id",
          "type": "uuid",
          "nullable": false,
          "description": "Corretor responsável pela visita"
        },
        {
          "name": "visit_status",
          "type": "text",
          "nullable": false,
          "description": "Status da visita"
        },
        {
          "name": "property_id",
          "type": "uuid",
          "nullable": false,
          "description": "Imóvel visitado"
        },
        {
          "name": "visits_scheduled",
          "type": "integer",
          "nullable": false,
          "default": 0,
          "description": "Visitas agendadas"
        },
        {
          "name": "visits_rescheduled",
          "type": "integer",
          "nullable": false,
          "default": 0,
          "description": "Visitas reagendadas"
        },
        {
          "name": "visits_cancelled",
          "type": "integer",
          "nullable": false,
          "default": 0,
          "description": "Visitas canceladas"
        }
      ],
      "dimensions": [
        {
          "dimensionId": "brokerId",
          "column": "broker_id",
          "type": "uuid",
          "description": "Corretor responsável pela visita"
        },
        {
          "dimensionId": "visitStatus",
          "column": "visit_status",
          "type": "string",
          "description": "Status da visita"
        },
        {
          "dimensionId": "propertyId",
          "column": "property_id",
          "type": "uuid",
          "description": "Imóvel visitado"
        }
      ],
      "measures": [
        {
          "measureId": "visitsScheduled",
          "column": "visits_scheduled",
          "aggregation": "sum",
          "unit": "count",
          "description": "Visitas agendadas"
        },
        {
          "measureId": "visitsRescheduled",
          "column": "visits_rescheduled",
          "aggregation": "sum",
          "unit": "count",
          "description": "Visitas reagendadas"
        },
        {
          "measureId": "visitsCancelled",
          "column": "visits_cancelled",
          "aggregation": "sum",
          "unit": "count",
          "description": "Visitas canceladas"
        }
      ],
      "sourceWriteEvents": [
        "scheduleVisit",
        "rescheduleVisit",
        "cancelVisit"
      ],
      "hypertable": {
        "timeColumn": "event_time",
        "chunkTimeInterval": "7 days",
        "retentionPolicy": "1 year",
        "compressionPolicy": "30 days",
        "indexes": [
          {
            "indexName": "visit_metrics_time_idx",
            "columns": [
              "event_time"
            ],
            "purpose": "Otimizar consultas por janela temporal"
          },
          {
            "indexName": "visit_metrics_broker_time_idx",
            "columns": [
              "broker_id",
              "event_time"
            ],
            "purpose": "Análises por corretor ao longo do tempo"
          },
          {
            "indexName": "visit_metrics_status_time_idx",
            "columns": [
              "visit_status",
              "event_time"
            ],
            "purpose": "Análises por status ao longo do tempo"
          },
          {
            "indexName": "visit_metrics_property_time_idx",
            "columns": [
              "property_id",
              "event_time"
            ],
            "purpose": "Análises por imóvel ao longo do tempo"
          }
        ]
      },
      "updatePolicy": {
        "updatedByLayer": "layer_3_usecases",
        "pagesMayUpdate": false,
        "controllersMayUpdate": false,
        "usecaseRefs": [
          "scheduleVisitUsecase",
          "rescheduleVisitUsecase",
          "cancelVisitUsecase"
        ]
      },
      "accessPolicy": {
        "directAccessAllowedFor": [
          "layer_3_usecases"
        ],
        "forbiddenFor": [
          "pages",
          "layer_2_controllers",
          "agents"
        ]
      },
      "rulesApplied": [
        "ruleVisitRequiresLinks"
      ]
    },
    "defsPlan": {
      "fileName": "tables/visitMetrics.defs.ts",
      "exportName": "visitMetricsTable",
      "saveAsDefs": true
    }
  }
} as const;

export default visitMetricsTable;
