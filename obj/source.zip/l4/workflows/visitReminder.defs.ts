/// <mls fileReference="_102045_/l4/workflows/visitReminder.defs.ts" enhancement="_blank"/>

export const visitReminderDef = {
  "schemaVersion": "2026-06-06",
  "artifactType": "workflow",
  "artifactId": "visitReminder",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanWorkflowDefinition",
    "stepId": 25,
    "planId": "plan-validate-solution-coverage"
  },
  "data": {
    "workflowDefinition": {
      "workflowId": "visitReminder",
      "title": "Lembretes de Visita",
      "purpose": "Enviar notificações e criar tarefas de lembrete para visitas agendadas, garantindo presença do corretor e do cliente.",
      "executionMode": "automation",
      "createsTask": true,
      "taskConfig": {
        "taskTitleTemplate": "Lembrete: Visita agendada para {scheduledAt} - {propertyAddress}",
        "assigneeRules": [
          "assignToBrokerResponsible"
        ],
        "slaRules": [
          "slaReminder24hBeforeVisit",
          "slaRescheduleNoShow48h"
        ],
        "taskRoomRequired": false
      },
      "actors": [
        "broker"
      ],
      "states": [
        {
          "stateId": "idle",
          "description": "Estado inicial - aguardando visitas confirmadas para monitorar"
        },
        {
          "stateId": "reminderScheduled",
          "description": "Lembrete de 24h agendado para visita confirmada"
        },
        {
          "stateId": "reminderSent",
          "description": "Notificação de lembrete enviada ao corretor e lead"
        },
        {
          "stateId": "visitCompleted",
          "description": "Visita realizada com sucesso - workflow encerrado"
        },
        {
          "stateId": "noShowDetected",
          "description": "Não comparecimento detectado - tarefa de reagendamento criada"
        },
        {
          "stateId": "rescheduleTaskCreated",
          "description": "Tarefa de reagendamento criada para o corretor"
        },
        {
          "stateId": "closed",
          "description": "Workflow encerrado (visita cancelada ou reagendamento concluído)"
        }
      ],
      "transitions": [
        {
          "from": "idle",
          "to": "reminderScheduled",
          "trigger": "visitConfirmed",
          "actor": "system",
          "conditions": [
            "visit.status == 'confirmed'",
            "visit.scheduledAt > now() + 24h"
          ],
          "actions": [
            "scheduleReminder24hBefore(visit.visitId, visit.scheduledAt)"
          ],
          "rulesApplied": [
            "ruleVisitStatusTransition"
          ]
        },
        {
          "from": "reminderScheduled",
          "to": "reminderSent",
          "trigger": "reminder24hTriggered",
          "actor": "system",
          "conditions": [
            "now() >= visit.scheduledAt - 24h"
          ],
          "actions": [
            "sendReminderNotification(visit.brokerId, visit.leadId, visit.visitId)",
            "createReminderTask(visit.visitId, visit.brokerId)"
          ],
          "rulesApplied": []
        },
        {
          "from": "reminderSent",
          "to": "visitCompleted",
          "trigger": "visitMarkedCompleted",
          "actor": "broker",
          "conditions": [
            "visit.status == 'completed'"
          ],
          "actions": [
            "closeReminderTask(visit.visitId)",
            "recordVisitCompletion(visit.visitId)"
          ],
          "rulesApplied": [
            "ruleVisitStatusTransition"
          ]
        },
        {
          "from": "reminderSent",
          "to": "noShowDetected",
          "trigger": "visitMarkedNoShow",
          "actor": "broker",
          "conditions": [
            "visit.status == 'noShow'"
          ],
          "actions": [
            "closeReminderTask(visit.visitId)",
            "flagNoShowEvent(visit.visitId)"
          ],
          "rulesApplied": [
            "ruleVisitStatusTransition"
          ]
        },
        {
          "from": "noShowDetected",
          "to": "rescheduleTaskCreated",
          "trigger": "createRescheduleTask",
          "actor": "system",
          "conditions": [],
          "actions": [
            "createRescheduleTask(visit.visitId, visit.brokerId, visit.leadId, visit.propertyId)"
          ],
          "rulesApplied": []
        },
        {
          "from": "rescheduleTaskCreated",
          "to": "closed",
          "trigger": "rescheduleCompleted",
          "actor": "broker",
          "conditions": [
            "rescheduleTask.status == 'done'"
          ],
          "actions": [
            "closeRescheduleTask(visit.visitId)"
          ],
          "rulesApplied": []
        },
        {
          "from": "reminderSent",
          "to": "closed",
          "trigger": "visitCancelled",
          "actor": "broker",
          "conditions": [
            "visit.status == 'cancelled'"
          ],
          "actions": [
            "closeReminderTask(visit.visitId)",
            "cancelScheduledReminders(visit.visitId)"
          ],
          "rulesApplied": [
            "ruleVisitStatusTransition"
          ]
        },
        {
          "from": "reminderScheduled",
          "to": "closed",
          "trigger": "visitCancelledBeforeReminder",
          "actor": "broker",
          "conditions": [
            "visit.status == 'cancelled'"
          ],
          "actions": [
            "cancelScheduledReminders(visit.visitId)"
          ],
          "rulesApplied": [
            "ruleVisitStatusTransition"
          ]
        }
      ],
      "requiredEntities": [
        "Visit"
      ],
      "persistenceRefs": [
        "visitTable",
        "visitMetrics",
        "crmActivityMetrics"
      ],
      "usecaseRefs": [
        "scheduleVisit",
        "confirmVisit",
        "listVisits"
      ],
      "metricRefs": [
        "visitMetrics",
        "crmActivityMetrics"
      ],
      "userActions": [
        "confirmarVisita",
        "marcarVisitaRealizada",
        "marcarNaoComparecimento",
        "cancelarVisita",
        "reagendarVisita"
      ],
      "relatedPages": [
        "brokerDashboard",
        "brokerDashboardPage",
        "visitCalendarPage",
        "visitDetail",
        "visitForm",
        "visitList",
        "visitSchedulerPage"
      ],
      "relatedAgents": [],
      "relatedPlugins": [],
      "rulesApplied": [
        "ruleVisitStatusTransition"
      ],
      "implementationSuggestions": [
        {
          "suggestionId": "suggestVisitReminder24h",
          "title": "Criar lembrete automático 24h antes da visita confirmada",
          "priority": "now",
          "description": "Implementar job scheduler que monitora visitas confirmadas e dispara notificação push/email 24 horas antes do horário agendado. Reduz significativamente a taxa de no-show.",
          "tradeoff": "Requer infraestrutura de job scheduling (cron/queue) e serviço de notificação configurado."
        },
        {
          "suggestionId": "suggestVisitNoShowTask",
          "title": "Criar tarefa de reagendamento quando visita for marcada como 'noShow'",
          "priority": "soon",
          "description": "Ao detectar não comparecimento, criar automaticamente uma tarefa para o corretor entrar em contato com o lead e reagendar a visita. Recupera oportunidades perdidas.",
          "tradeoff": "Aumenta volume de tarefas para o corretor; necessário balancear com priorização adequada."
        },
        {
          "suggestionId": "suggestMultiChannelReminder",
          "title": "Enviar lembretes por múltiplos canais (email, SMS, push)",
          "priority": "later",
          "description": "Expandir o sistema de lembretes para suportar múltiplos canais de comunicação conforme preferência do lead.",
          "tradeoff": "Requer integração com provedores de SMS e push notifications; custo operacional adicional."
        },
        {
          "suggestionId": "suggestLeadConfirmationRequest",
          "title": "Solicitar confirmação do lead via link no lembrete",
          "priority": "later",
          "description": "Incluir link de confirmação/cancelamento no lembrete enviado ao lead, permitindo atualização automática do status.",
          "tradeoff": "Requer endpoint público para confirmação e lógica de expiração de links."
        }
      ],
      "workflowScope": "singleModule",
      "moduleRefs": [
        "propertyFlowCrm"
      ],
      "pageRefsByModule": [
        {
          "moduleId": "propertyFlowCrm",
          "pageId": "visitSchedulerPage"
        },
        {
          "moduleId": "propertyFlowCrm",
          "pageId": "visitCalendarPage"
        },
        {
          "moduleId": "propertyFlowCrm",
          "pageId": "brokerDashboardPage"
        }
      ],
      "entityRefsByModule": [
        {
          "moduleId": "propertyFlowCrm",
          "entity": "Visit"
        }
      ],
      "writesArtifacts": [
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "table",
          "artifactId": "visitTable"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "metricTable",
          "artifactId": "visitMetrics"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "metricTable",
          "artifactId": "crmActivityMetrics"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "usecase",
          "artifactId": "confirmVisit"
        }
      ]
    },
    "defsPlan": {
      "fileName": "workflows/visitReminder.defs.ts",
      "exportName": "visitReminderDef",
      "saveAsDefs": true
    }
  }
} as const;

export default visitReminderDef;
