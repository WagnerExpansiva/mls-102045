/// <mls fileReference="_102045_/l4/workflows/leadPipelineWorkflow.defs.ts" enhancement="_blank"/>

export const leadPipelineWorkflowDef = {
  "schemaVersion": "2026-06-06",
  "artifactType": "workflow",
  "artifactId": "leadPipelineWorkflow",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanWorkflowDefinition",
    "stepId": 59,
    "planId": ""
  },
  "data": {
    "workflowDefinition": {
      "workflowId": "leadPipelineWorkflow",
      "title": "Pipeline de Leads",
      "purpose": "Gerenciar o ciclo de vida dos leads desde o primeiro contato até a conversão ou arquivamento, controlando transições entre estágios e temperatura no kanban.",
      "executionMode": "entityLifecycle",
      "createsTask": false,
      "taskConfig": {
        "taskTitleTemplate": "",
        "assigneeRules": [],
        "slaRules": [],
        "taskRoomRequired": false
      },
      "actors": [
        "corretor"
      ],
      "states": [
        {
          "stateId": "novo",
          "description": "Lead recém-cadastrado aguardando primeiro contato."
        },
        {
          "stateId": "contatado",
          "description": "Lead com contato inicial realizado."
        },
        {
          "stateId": "qualificado",
          "description": "Lead avaliado como com potencial de conversão."
        },
        {
          "stateId": "convertido",
          "description": "Lead convertido em negócio/proposta."
        },
        {
          "stateId": "arquivado",
          "description": "Lead encerrado ou descartado."
        }
      ],
      "transitions": [
        {
          "from": "novo",
          "to": "contatado",
          "trigger": "updateLeadStage",
          "actor": "corretor",
          "conditions": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ],
          "actions": [
            "Lead.stage=contatado"
          ],
          "rulesApplied": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ]
        },
        {
          "from": "contatado",
          "to": "qualificado",
          "trigger": "qualifyLeadWithAi",
          "actor": "corretor",
          "conditions": [
            "ruleLeadTemperature",
            "ruleBrokerPermissions"
          ],
          "actions": [
            "Lead.stage=qualificado",
            "Lead.temperature=quente"
          ],
          "rulesApplied": [
            "ruleLeadTemperature",
            "ruleBrokerPermissions"
          ]
        },
        {
          "from": "qualificado",
          "to": "convertido",
          "trigger": "updateLeadStage",
          "actor": "corretor",
          "conditions": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ],
          "actions": [
            "Lead.stage=convertido"
          ],
          "rulesApplied": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ]
        },
        {
          "from": "novo",
          "to": "arquivado",
          "trigger": "updateLeadStage",
          "actor": "corretor",
          "conditions": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ],
          "actions": [
            "Lead.stage=arquivado"
          ],
          "rulesApplied": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ]
        },
        {
          "from": "contatado",
          "to": "arquivado",
          "trigger": "updateLeadStage",
          "actor": "corretor",
          "conditions": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ],
          "actions": [
            "Lead.stage=arquivado"
          ],
          "rulesApplied": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ]
        },
        {
          "from": "qualificado",
          "to": "arquivado",
          "trigger": "updateLeadStage",
          "actor": "corretor",
          "conditions": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ],
          "actions": [
            "Lead.stage=arquivado"
          ],
          "rulesApplied": [
            "ruleLeadStageTransition",
            "ruleBrokerPermissions"
          ]
        }
      ],
      "requiredEntities": [
        "Lead"
      ],
      "persistenceRefs": [
        "lead_metrics"
      ],
      "usecaseRefs": [
        "createLead",
        "updateLeadStage",
        "qualifyLeadWithAi"
      ],
      "metricRefs": [
        "leadMetrics"
      ],
      "userActions": [
        "cadastrarLead",
        "moverLeadNoKanban",
        "qualificarLeadComIa",
        "arquivarLead"
      ],
      "relatedPages": [],
      "relatedAgents": [],
      "relatedPlugins": [],
      "rulesApplied": [
        "ruleLeadStageTransition",
        "ruleLeadTemperature",
        "ruleBrokerPermissions"
      ],
      "implementationSuggestions": [
        {
          "suggestionId": "leadKanbanView",
          "title": "Visualização em Kanban para pipeline de leads",
          "priority": "now",
          "description": "Permite ao corretor mover leads entre colunas representando os estágios de forma intuitiva.",
          "tradeoff": "Requer desenho de UI com drag-and-drop."
        },
        {
          "suggestionId": "leadStageValidation",
          "title": "Validar transições de estágio por regras de negócio",
          "priority": "now",
          "description": "Garantir que apenas transições válidas sejam permitidas conforme o processo de vendas.",
          "tradeoff": "Exige manutenção das regras de estágio ao evoluir o processo."
        },
        {
          "suggestionId": "noTaskNeededForPipeline",
          "title": "Fluxo sem tarefas dedicadas",
          "priority": "now",
          "description": "O pipeline é gerenciado diretamente no kanban; não há necessidade de gerar tarefas separadas para cada lead.",
          "tradeoff": "Menos rastreio de SLAs individuais, depende de disciplina do corretor."
        }
      ],
      "workflowScope": "singleModule",
      "moduleRefs": [
        "propertyFlowCrm"
      ],
      "pageRefsByModule": [],
      "entityRefsByModule": [
        {
          "moduleId": "propertyFlowCrm",
          "entity": "Lead"
        }
      ],
      "writesArtifacts": [
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "workflow",
          "artifactId": "leadPipelineWorkflow"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "usecase",
          "artifactId": "createLead"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "usecase",
          "artifactId": "updateLeadStage"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "usecase",
          "artifactId": "qualifyLeadWithAi"
        },
        {
          "moduleId": "propertyFlowCrm",
          "artifactType": "metricTable",
          "artifactId": "leadMetrics"
        }
      ]
    },
    "defsPlan": {
      "fileName": "workflows/leadPipelineWorkflow.defs.ts",
      "exportName": "leadPipelineWorkflowDef",
      "saveAsDefs": true
    }
  }
} as const;

export default leadPipelineWorkflowDef;
