/// <mls fileReference="_102045_/l2/propertyFlowCrm/visitDetail.defs.ts" enhancement="_blank"/>

export const visitDetailPagePlan = {
  "schemaVersion": "2026-06-06",
  "artifactType": "page",
  "artifactId": "visitDetail",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanPageDefinition",
    "stepId": 67,
    "planId": ""
  },
  "data": {
    "pageDefinition": {
      "pageId": "visitDetail",
      "pageName": "Detalhe da visita",
      "actor": "corretor",
      "purpose": "Ver detalhes e atualizar visita.",
      "capabilities": [
        "scheduleVisits"
      ],
      "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [
          "visitLifecycleWorkflow"
        ],
        "taskWorkflows": [],
        "automations": [
          "visitReminderAutomation"
        ]
      },
      "pluginRefs": [],
      "mdmRefs": [
        "property",
        "lead"
      ],
      "pageInputs": [
        {
          "name": "visitId",
          "type": "string",
          "required": true,
          "sources": [
            "routeParam",
            "previousStepResult"
          ],
          "description": "Identificador da visita selecionada.",
          "entityRef": "visitAggregate"
        }
      ],
      "navigationRefs": [
        {
          "direction": "inbound",
          "pageId": "visitsCalendar",
          "trigger": "Selecionar visita"
        },
        {
          "direction": "outbound",
          "pageId": "visitForm",
          "trigger": "Reagendar visita"
        }
      ],
      "sections": [
        {
          "sectionName": "Resumo da visita",
          "mode": "view",
          "organisms": [
            {
              "organismName": "visitDetailCard",
              "purpose": "Exibir dados principais da visita e status.",
              "userActions": [],
              "requiredEntities": [
                "visitAggregate"
              ],
              "readsFields": [
                "visitId",
                "scheduledAt",
                "status",
                "leadId",
                "propertyId"
              ],
              "writesFields": [],
              "rulesApplied": [
                "ruleVisitRequiresLinks",
                "ruleBrokerPermissions"
              ]
            }
          ]
        },
        {
          "sectionName": "Vínculos",
          "mode": "view",
          "organisms": [
            {
              "organismName": "linkedLeadSummary",
              "purpose": "Exibir dados resumidos do lead vinculado.",
              "userActions": [
                "Abrir lead"
              ],
              "requiredEntities": [
                "leadAggregate"
              ],
              "readsFields": [
                "leadId",
                "name",
                "phone",
                "email"
              ],
              "writesFields": [],
              "rulesApplied": [
                "ruleVisitRequiresLinks"
              ]
            },
            {
              "organismName": "linkedPropertySummary",
              "purpose": "Exibir dados resumidos do imóvel vinculado.",
              "userActions": [
                "Abrir imóvel"
              ],
              "requiredEntities": [
                "propertyAggregate"
              ],
              "readsFields": [
                "propertyId",
                "title",
                "address",
                "price"
              ],
              "writesFields": [],
              "rulesApplied": [
                "ruleVisitRequiresLinks"
              ]
            }
          ]
        },
        {
          "sectionName": "Ações",
          "mode": "edit",
          "organisms": [
            {
              "organismName": "rescheduleVisitPanel",
              "purpose": "Reagendar data e hora da visita.",
              "userActions": [
                "Reagendar visita"
              ],
              "requiredEntities": [
                "visitAggregate"
              ],
              "readsFields": [
                "visitId",
                "scheduledAt"
              ],
              "writesFields": [
                "scheduledAt"
              ],
              "rulesApplied": [
                "ruleVisitRequiresLinks",
                "ruleBrokerPermissions"
              ]
            },
            {
              "organismName": "cancelVisitPanel",
              "purpose": "Cancelar a visita com motivo opcional.",
              "userActions": [
                "Cancelar visita"
              ],
              "requiredEntities": [
                "visitAggregate"
              ],
              "readsFields": [
                "visitId"
              ],
              "writesFields": [
                "status",
                "cancelReason"
              ],
              "rulesApplied": [
                "ruleVisitRequiresLinks",
                "ruleBrokerPermissions"
              ]
            }
          ]
        }
      ]
    },
    "bffCommands": [
      {
        "commandName": "getVisit",
        "purpose": "Carregar dados da visita e vínculos.",
        "kind": "query",
        "input": [
          {
            "name": "visitId",
            "type": "string",
            "required": true
          }
        ],
        "output": [
          {
            "name": "visitId",
            "type": "string"
          },
          {
            "name": "scheduledAt",
            "type": "date"
          },
          {
            "name": "status",
            "type": "string"
          },
          {
            "name": "leadId",
            "type": "string"
          },
          {
            "name": "leadName",
            "type": "string"
          },
          {
            "name": "leadPhone",
            "type": "string"
          },
          {
            "name": "leadEmail",
            "type": "string"
          },
          {
            "name": "propertyId",
            "type": "string"
          },
          {
            "name": "propertyTitle",
            "type": "string"
          },
          {
            "name": "propertyAddress",
            "type": "string"
          },
          {
            "name": "propertyPrice",
            "type": "number"
          }
        ],
        "readsEntities": [
          "visitAggregate",
          "leadAggregate",
          "propertyAggregate"
        ],
        "writesEntities": [],
        "readsTables": [],
        "writesTables": [],
        "usecaseRefs": [
          "getVisit"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "ruleVisitRequiresLinks",
          "ruleBrokerPermissions"
        ]
      },
      {
        "commandName": "rescheduleVisit",
        "purpose": "Reagendar visita selecionada.",
        "kind": "command",
        "input": [
          {
            "name": "visitId",
            "type": "string",
            "required": true
          },
          {
            "name": "scheduledAt",
            "type": "date",
            "required": true
          }
        ],
        "output": [
          {
            "name": "visitId",
            "type": "string"
          }
        ],
        "readsEntities": [
          "visitAggregate"
        ],
        "writesEntities": [
          "visitAggregate"
        ],
        "readsTables": [],
        "writesTables": [
          "visit_metrics"
        ],
        "usecaseRefs": [
          "rescheduleVisit"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "ruleVisitRequiresLinks",
          "ruleBrokerPermissions"
        ]
      },
      {
        "commandName": "cancelVisit",
        "purpose": "Cancelar visita selecionada.",
        "kind": "command",
        "input": [
          {
            "name": "visitId",
            "type": "string",
            "required": true
          },
          {
            "name": "reason",
            "type": "string",
            "required": false
          }
        ],
        "output": [
          {
            "name": "visitId",
            "type": "string"
          }
        ],
        "readsEntities": [
          "visitAggregate"
        ],
        "writesEntities": [
          "visitAggregate"
        ],
        "readsTables": [],
        "writesTables": [
          "visit_metrics"
        ],
        "usecaseRefs": [
          "cancelVisit"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "ruleVisitRequiresLinks",
          "ruleBrokerPermissions"
        ]
      }
    ]
  }
} as const;

export default visitDetailPagePlan;
