declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Broker.defs" {
    export const BrokerMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Broker";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Broker";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "broker";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Corretor";
            readonly sourceOfTruth: "Shared MDM platform (project 102034)";
            readonly governanceRules: readonly ["ruleBrokerRequiredFields", "ruleBrokerAssignment"];
            readonly title: "Corretor";
            readonly description: "Representa um corretor de imóveis que opera no sistema, com dados pessoais e área de atuação.";
            readonly fields: readonly [{
                readonly fieldId: "brokerId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do corretor.";
            }, {
                readonly fieldId: "fullName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome completo do corretor.";
            }, {
                readonly fieldId: "email";
                readonly type: "email";
                readonly required: true;
                readonly description: "E-mail do corretor.";
            }, {
                readonly fieldId: "phone";
                readonly type: "string";
                readonly required: true;
                readonly description: "Telefone de contato.";
            }, {
                readonly fieldId: "creci";
                readonly type: "string";
                readonly required: false;
                readonly description: "Número do registro CRECI.";
            }, {
                readonly fieldId: "status";
                readonly type: "enum";
                readonly required: true;
                readonly description: "Status do corretor (ativo, inativo).";
            }, {
                readonly fieldId: "role";
                readonly type: "enum";
                readonly required: true;
                readonly description: "Perfil de acesso (corretor, gerente, administrador).";
            }, {
                readonly fieldId: "specializations";
                readonly type: "array";
                readonly required: false;
                readonly description: "Especializações do corretor (residencial, comercial, luxo, etc.).";
            }, {
                readonly fieldId: "workingAreas";
                readonly type: "array";
                readonly required: false;
                readonly description: "Bairros ou regiões de atuação.";
            }, {
                readonly fieldId: "photoUrl";
                readonly type: "string";
                readonly required: false;
                readonly description: "URL da foto do corretor.";
            }, {
                readonly fieldId: "hireDate";
                readonly type: "date";
                readonly required: false;
                readonly description: "Data de contratação.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização.";
            }];
        };
    };
    export default BrokerMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Lead.defs" {
    export const LeadMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Lead";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Lead";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "lead";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Lead/Cliente";
            readonly sourceOfTruth: "Shared MDM platform (project 102034)";
            readonly governanceRules: readonly ["ruleLeadRequiredFields", "ruleLeadPipelineTransition", "ruleBrokerAssignment"];
            readonly title: "Lead/Cliente";
            readonly description: "Representa um potencial cliente interessado em imóveis, com informações de contato e histórico de interações.";
            readonly fields: readonly [{
                readonly fieldId: "leadId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do lead.";
            }, {
                readonly fieldId: "fullName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome completo do lead.";
            }, {
                readonly fieldId: "email";
                readonly type: "email";
                readonly required: false;
                readonly description: "E-mail de contato.";
            }, {
                readonly fieldId: "phone";
                readonly type: "string";
                readonly required: true;
                readonly description: "Telefone de contato.";
            }, {
                readonly fieldId: "source";
                readonly type: "enum";
                readonly required: false;
                readonly description: "Origem do lead (site, indicação, portal, redes sociais, etc.).";
            }, {
                readonly fieldId: "pipelineStage";
                readonly type: "enum";
                readonly required: true;
                readonly description: "Etapa atual no pipeline (novo, em contato, qualificado, negociando, convertido, perdido).";
            }, {
                readonly fieldId: "temperature";
                readonly type: "enum";
                readonly required: false;
                readonly description: "Classificação de temperatura do lead (quente, morno, frio).";
            }, {
                readonly fieldId: "interestType";
                readonly type: "enum";
                readonly required: false;
                readonly description: "Tipo de interesse (compra, locação, ambos).";
            }, {
                readonly fieldId: "preferredPropertyType";
                readonly type: "enum";
                readonly required: false;
                readonly description: "Tipo de imóvel de preferência.";
            }, {
                readonly fieldId: "budgetMin";
                readonly type: "decimal";
                readonly required: false;
                readonly description: "Orçamento mínimo do lead.";
            }, {
                readonly fieldId: "budgetMax";
                readonly type: "decimal";
                readonly required: false;
                readonly description: "Orçamento máximo do lead.";
            }, {
                readonly fieldId: "preferredNeighborhoods";
                readonly type: "array";
                readonly required: false;
                readonly description: "Bairros de preferência.";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Anotações e observações sobre o lead.";
            }, {
                readonly fieldId: "assignedBrokerId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "ID do corretor responsável pelo lead.";
            }, {
                readonly fieldId: "lastContactAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data do último contato.";
            }, {
                readonly fieldId: "nextFollowUpAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data sugerida para próximo follow-up.";
            }, {
                readonly fieldId: "suggestedFollowUpMessage";
                readonly type: "text";
                readonly required: false;
                readonly description: "Mensagem de follow-up sugerida pela IA.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização.";
            }];
        };
    };
    export default LeadMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Property.defs" {
    export const PropertyMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Property";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Property";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "property";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Imóvel";
            readonly sourceOfTruth: "Shared MDM platform (project 102034)";
            readonly governanceRules: readonly ["rulePropertyRequiredFields", "rulePropertyStatusTransition", "ruleVisitPropertyActive", "ruleDealPropertyActive"];
            readonly title: "Imóvel";
            readonly description: "Representa um imóvel disponível para venda ou locação, com todas as suas características, localização e fotos.";
            readonly fields: readonly [{
                readonly fieldId: "propertyId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do imóvel.";
            }, {
                readonly fieldId: "title";
                readonly type: "string";
                readonly required: true;
                readonly description: "Título do anúncio do imóvel.";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição comercial detalhada do imóvel.";
            }, {
                readonly fieldId: "propertyType";
                readonly type: "enum";
                readonly required: true;
                readonly description: "Tipo do imóvel (apartamento, casa, terreno, comercial, etc.).";
            }, {
                readonly fieldId: "transactionType";
                readonly type: "enum";
                readonly required: true;
                readonly description: "Tipo de transação (venda, locação, venda e locação).";
            }, {
                readonly fieldId: "price";
                readonly type: "decimal";
                readonly required: true;
                readonly description: "Preço de venda ou valor do aluguel.";
            }, {
                readonly fieldId: "status";
                readonly type: "enum";
                readonly required: true;
                readonly description: "Status atual do imóvel (ativo, inativo, vendido, alugado, reservado).";
            }, {
                readonly fieldId: "addressStreet";
                readonly type: "string";
                readonly required: true;
                readonly description: "Logradouro do endereço.";
            }, {
                readonly fieldId: "addressNumber";
                readonly type: "string";
                readonly required: false;
                readonly description: "Número do endereço.";
            }, {
                readonly fieldId: "addressComplement";
                readonly type: "string";
                readonly required: false;
                readonly description: "Complemento do endereço.";
            }, {
                readonly fieldId: "addressNeighborhood";
                readonly type: "string";
                readonly required: true;
                readonly description: "Bairro do imóvel.";
            }, {
                readonly fieldId: "addressCity";
                readonly type: "string";
                readonly required: true;
                readonly description: "Cidade do imóvel.";
            }, {
                readonly fieldId: "addressState";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado/UF do imóvel.";
            }, {
                readonly fieldId: "addressZipCode";
                readonly type: "string";
                readonly required: false;
                readonly description: "CEP do imóvel.";
            }, {
                readonly fieldId: "area";
                readonly type: "decimal";
                readonly required: false;
                readonly description: "Área total em metros quadrados.";
            }, {
                readonly fieldId: "bedrooms";
                readonly type: "integer";
                readonly required: false;
                readonly description: "Número de quartos.";
            }, {
                readonly fieldId: "bathrooms";
                readonly type: "integer";
                readonly required: false;
                readonly description: "Número de banheiros.";
            }, {
                readonly fieldId: "parkingSpaces";
                readonly type: "integer";
                readonly required: false;
                readonly description: "Número de vagas de garagem.";
            }, {
                readonly fieldId: "features";
                readonly type: "array";
                readonly required: false;
                readonly description: "Lista de características adicionais (piscina, churrasqueira, etc.).";
            }, {
                readonly fieldId: "photoUrls";
                readonly type: "array";
                readonly required: false;
                readonly description: "URLs das fotos mock do imóvel.";
            }, {
                readonly fieldId: "assignedBrokerId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "ID do corretor responsável pelo imóvel.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização.";
            }];
        };
    };
    export default PropertyMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/crmActivityMetrics.defs" {
    export const crmActivityMetricsDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "crmActivityMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "crmActivityMetrics";
                readonly tableName: "crm_activity_metrics";
                readonly title: "Tabela de Métricas do CRM";
                readonly purpose: "Consolidar eventos operacionais de todas as entidades do CRM para monitoramento unificado de produtividade e riscos operacionais.";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento operacional";
                }, {
                    readonly name: "entity_id";
                    readonly type: "varchar(36)";
                    readonly nullable: false;
                    readonly description: "Identificador do registro afetado";
                }, {
                    readonly name: "entity_type";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Tipo da entidade (Property, Lead, Deal, Visit, LeadInteraction)";
                }, {
                    readonly name: "broker_id";
                    readonly type: "varchar(36)";
                    readonly nullable: true;
                    readonly description: "Corretor responsável pela ação";
                }, {
                    readonly name: "lead_id";
                    readonly type: "varchar(36)";
                    readonly nullable: true;
                    readonly description: "Lead relacionado quando aplicável";
                }, {
                    readonly name: "property_id";
                    readonly type: "varchar(36)";
                    readonly nullable: true;
                    readonly description: "Imóvel relacionado quando aplicável";
                }, {
                    readonly name: "action_type";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Tipo de ação realizada";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: true;
                    readonly description: "Status resultante da ação";
                }, {
                    readonly name: "event_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de eventos operacionais";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "entityId";
                    readonly column: "entity_id";
                    readonly type: "string";
                    readonly description: "Identificador do registro afetado";
                }, {
                    readonly dimensionId: "entityType";
                    readonly column: "entity_type";
                    readonly type: "string";
                    readonly description: "Tipo da entidade (Property, Lead, Deal, Visit, LeadInteraction)";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável pela ação";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Lead relacionado quando aplicável";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "Imóvel relacionado quando aplicável";
                }, {
                    readonly dimensionId: "actionType";
                    readonly column: "action_type";
                    readonly type: "string";
                    readonly description: "Tipo de ação realizada";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status resultante da ação";
                }];
                readonly measures: readonly [{
                    readonly measureId: "eventCount";
                    readonly column: "event_count";
                    readonly aggregation: "count";
                    readonly unit: "eventos";
                    readonly description: "Contagem de eventos operacionais";
                }];
                readonly sourceWriteEvents: readonly ["createProperty", "updateProperty", "changePropertyStatus", "createLead", "updateLead", "moveLeadStage", "classifyLeadTemperature", "createDeal", "advanceDealStage", "closeDealWon", "closeDealLost", "scheduleVisit", "confirmVisit", "completeVisit", "cancelVisit", "registerInteraction"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createPropertyUsecase", "updatePropertyUsecase", "changePropertyStatusUsecase", "createLeadUsecase", "updateLeadUsecase", "moveLeadStageUsecase", "classifyLeadTemperatureUsecase", "createDealUsecase", "advanceDealStageUsecase", "closeDealWonUsecase", "closeDealLostUsecase", "scheduleVisitUsecase", "confirmVisitUsecase", "completeVisitUsecase", "cancelVisitUsecase", "registerInteractionUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "7 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_crm_activity_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Índice primário de tempo para consultas de série temporal e particionamento";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_crm_activity_metrics_entity_type_time";
                        readonly columns: readonly ["entity_type", "event_time"];
                        readonly purpose: "Filtragem por tipo de entidade com ordenação temporal";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_crm_activity_metrics_broker_id_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consultas de atividade por corretor para dashboard de desempenho";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_crm_activity_metrics_lead_id_time";
                        readonly columns: readonly ["lead_id", "event_time"];
                        readonly purpose: "Histórico de eventos relacionados a um lead específico";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_crm_activity_metrics_property_id_time";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Histórico de eventos relacionados a um imóvel específico";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_crm_activity_metrics_action_type_time";
                        readonly columns: readonly ["action_type", "event_time"];
                        readonly purpose: "Análise de frequência de tipos de ação ao longo do tempo";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/crmActivityMetrics.defs.ts";
                readonly exportName: "crmActivityMetricsDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default crmActivityMetricsDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/dealPipelineMetrics.defs" {
    export const dealPipelineMetricsDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dealPipelineMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dealPipelineMetrics";
                readonly tableName: "deal_pipeline_metrics";
                readonly title: "Métrica de Pipeline de Fechamentos";
                readonly purpose: "Rastrear movimentação, valor e resultados do pipeline de negócios.";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de métrica";
                }, {
                    readonly name: "deal_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do negócio";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo negócio";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead relacionado ao negócio";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel relacionado ao negócio";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Status do negócio";
                }, {
                    readonly name: "lifecycle_state";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Estado do ciclo de vida do negócio";
                }, {
                    readonly name: "deal_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de negócios";
                }, {
                    readonly name: "deal_value";
                    readonly type: "numeric(15,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor do negócio";
                }, {
                    readonly name: "won_value";
                    readonly type: "numeric(15,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor de negócios ganhos";
                }, {
                    readonly name: "lost_value";
                    readonly type: "numeric(15,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor de negócios perdidos";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "dealId";
                    readonly column: "deal_id";
                    readonly type: "string";
                    readonly description: "Identificador do negócio";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável pelo negócio";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Lead relacionado ao negócio";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "Imóvel relacionado ao negócio";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do negócio";
                }, {
                    readonly dimensionId: "lifecycleState";
                    readonly column: "lifecycle_state";
                    readonly type: "string";
                    readonly description: "Estado do ciclo de vida do negócio";
                }];
                readonly measures: readonly [{
                    readonly measureId: "dealCount";
                    readonly column: "deal_count";
                    readonly aggregation: "count";
                    readonly unit: "negócios";
                    readonly description: "Contagem de negócios";
                }, {
                    readonly measureId: "dealValue";
                    readonly column: "deal_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor do negócio";
                }, {
                    readonly measureId: "wonValue";
                    readonly column: "won_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor de negócios ganhos";
                }, {
                    readonly measureId: "lostValue";
                    readonly column: "lost_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor de negócios perdidos";
                }];
                readonly sourceWriteEvents: readonly ["createDeal", "advanceDealStage", "closeDealWon", "closeDealLost"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createDealUsecase", "advanceDealStageUsecase", "closeDealWonUsecase", "closeDealLostUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "3 years";
                    readonly compressionPolicy: "7 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_deal_pipeline_metrics_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consultas por intervalo de tempo para agregações e dashboards";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_deal_id";
                        readonly columns: readonly ["deal_id"];
                        readonly purpose: "Consultas de métricas por negócio específico";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_broker_id";
                        readonly columns: readonly ["broker_id"];
                        readonly purpose: "Consultas de métricas por corretor para dashboard de performance";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_lead_id";
                        readonly columns: readonly ["lead_id"];
                        readonly purpose: "Consultas de métricas por lead relacionado";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_property_id";
                        readonly columns: readonly ["property_id"];
                        readonly purpose: "Consultas de métricas por imóvel relacionado";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_status";
                        readonly columns: readonly ["status"];
                        readonly purpose: "Filtragem por status do negócio para análises de pipeline";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_broker_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consultas combinadas de métricas por corretor e período";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["ruleDealRequiredFields", "ruleDealPipelineTransition", "ruleBrokerAssignment", "ruleDealPropertyActive"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealPipelineMetrics.defs.ts";
                readonly exportName: "dealPipelineMetricsDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealPipelineMetricsDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/dealTable.defs" {
    export const dealTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dealTable";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dealTable";
                readonly tableName: "deal";
                readonly title: "Negócios/Propostas";
                readonly purpose: "Armazenar registros de negócios e propostas comerciais vinculados a leads e imóveis, com pipeline de etapas";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly rootEntity: "Deal";
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly columns: readonly [{
                    readonly name: "deal_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do negócio";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do lead associado ao negócio";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do imóvel objeto do negócio";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor responsável pelo negócio";
                }, {
                    readonly name: "deal_type";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Tipo do negócio (venda, locação)";
                }, {
                    readonly name: "proposed_value";
                    readonly type: "decimal(15,2)";
                    readonly nullable: false;
                    readonly description: "Valor proposto pelo cliente";
                }, {
                    readonly name: "accepted_value";
                    readonly type: "decimal(15,2)";
                    readonly nullable: true;
                    readonly description: "Valor aceito/negociado";
                }, {
                    readonly name: "pipeline_stage";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly default: "proposal";
                    readonly description: "Etapa atual no pipeline (proposal, negotiation, documentation, closing, won, lost)";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(10)";
                    readonly nullable: false;
                    readonly default: "open";
                    readonly description: "Status do negócio (open, closed)";
                }, {
                    readonly name: "loss_reason";
                    readonly type: "varchar(255)";
                    readonly nullable: true;
                    readonly description: "Motivo da perda do negócio, se aplicável";
                }, {
                    readonly name: "expected_close_date";
                    readonly type: "date";
                    readonly nullable: true;
                    readonly description: "Data prevista para fechamento";
                }, {
                    readonly name: "actual_close_date";
                    readonly type: "date";
                    readonly nullable: true;
                    readonly description: "Data real de fechamento";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização";
                }];
                readonly primaryKey: readonly ["deal_id"];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar notas e dados adicionais do negócio que não requerem filtragem frequente";
                    readonly jsonSchemaRef: "DealDetails";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao lead/cliente associado ao negócio";
                }, {
                    readonly fieldName: "property_id";
                    readonly targetEntity: "Property";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao imóvel objeto do negócio";
                }, {
                    readonly fieldName: "broker_id";
                    readonly targetEntity: "Broker";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao corretor responsável pelo negócio";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_deal_lead_id";
                    readonly columns: readonly ["lead_id"];
                    readonly unique: false;
                    readonly reason: "Busca de negócios por lead para visualização no tracker e dashboard";
                }, {
                    readonly indexName: "idx_deal_property_id";
                    readonly columns: readonly ["property_id"];
                    readonly unique: false;
                    readonly reason: "Busca de negócios por imóvel para validação e listagem";
                }, {
                    readonly indexName: "idx_deal_broker_id";
                    readonly columns: readonly ["broker_id"];
                    readonly unique: false;
                    readonly reason: "Busca de negócios por corretor para dashboard e relatórios";
                }, {
                    readonly indexName: "idx_deal_pipeline_stage";
                    readonly columns: readonly ["pipeline_stage"];
                    readonly unique: false;
                    readonly reason: "Filtragem por etapa do pipeline para kanban e workflow";
                }, {
                    readonly indexName: "idx_deal_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por status para listagem de negócios abertos/fechados";
                }, {
                    readonly indexName: "idx_deal_broker_stage";
                    readonly columns: readonly ["broker_id", "pipeline_stage"];
                    readonly unique: false;
                    readonly reason: "Consulta combinada de negócios por corretor e etapa para dealsTrackerPage";
                }, {
                    readonly indexName: "idx_deal_expected_close";
                    readonly columns: readonly ["expected_close_date"];
                    readonly unique: false;
                    readonly reason: "Filtragem por data prevista de fechamento para dashboard e alertas";
                }];
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly metricRefs: readonly ["crmMetricsTable"];
                };
                readonly rulesApplied: readonly ["ruleDealRequiredFields", "ruleDealPipelineTransition", "ruleDealPropertyActive"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealTable.defs.ts";
                readonly exportName: "dealTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadInteractionTable.defs" {
    export const leadInteractionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "leadInteractionTable";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "leadInteractionTable";
                readonly tableName: "lead_interaction";
                readonly title: "Interações com Lead";
                readonly purpose: "Registrar histórico de interações entre corretores e leads, incluindo tipo de contato, notas e data";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly rootEntity: "LeadInteraction";
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly columns: readonly [{
                    readonly name: "interaction_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da interação";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do lead relacionado (referência ao MDM de Lead)";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor que realizou a interação (referência ao MDM de Corretor)";
                }, {
                    readonly name: "interaction_type";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Tipo de interação (ligação, e-mail, WhatsApp, presencial, etc.)";
                }, {
                    readonly name: "direction";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Direção da interação (entrada, saída)";
                }, {
                    readonly name: "summary";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Resumo da interação";
                }, {
                    readonly name: "interaction_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da interação";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do registro";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Dados adicionais da interação em formato JSON (anexos, metadados, etc.)";
                }];
                readonly primaryKey: readonly ["interaction_id"];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar dados adicionais como anexos, metadados de canal, informações complementares que não requerem filtragem frequente";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao lead do MDM de Lead";
                }, {
                    readonly fieldName: "broker_id";
                    readonly targetEntity: "Broker";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao corretor do MDM de Corretor";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_lead_interaction_lead_id";
                    readonly columns: readonly ["lead_id"];
                    readonly unique: false;
                    readonly reason: "Consulta frequente de interações por lead no pipeline e histórico";
                }, {
                    readonly indexName: "idx_lead_interaction_broker_id";
                    readonly columns: readonly ["broker_id"];
                    readonly unique: false;
                    readonly reason: "Consulta de interações por corretor para relatórios e dashboards";
                }, {
                    readonly indexName: "idx_lead_interaction_lead_interaction_at";
                    readonly columns: readonly ["lead_id", "interaction_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação cronológica de interações por lead para timeline e agentes de IA";
                }, {
                    readonly indexName: "idx_lead_interaction_type";
                    readonly columns: readonly ["interaction_type"];
                    readonly unique: false;
                    readonly reason: "Filtragem por tipo de interação para análises e relatórios";
                }, {
                    readonly indexName: "idx_lead_interaction_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtragem por data de criação para consultas recentes e sincronização";
                }];
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly metricRefs: readonly ["interactionCountMetric", "brokerActivityMetric"];
                };
                readonly rulesApplied: readonly ["ruleInteractionRequiredFields", "ruleBrokerAssignment"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadInteractionTable.defs.ts";
                readonly exportName: "leadInteractionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadInteractionTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadMetrics.defs" {
    export const leadMetricsDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "leadMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "leadMetrics";
                readonly tableName: "lead_metrics";
                readonly title: "Métrica de Leads do Mês";
                readonly purpose: "Monitorar a quantidade, qualificação e movimentação de leads no pipeline.";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de métrica";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do lead";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo lead";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly description: "Status do lead (new, contacted, qualified, negotiating, converted, lost)";
                }, {
                    readonly name: "lifecycle_state";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Estado do ciclo de vida do lead (active, archived)";
                }, {
                    readonly name: "lead_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de leads (sempre 1 por evento)";
                }, {
                    readonly name: "qualified_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Indicador de lead qualificado (1 se qualificado, 0 caso contrário)";
                }, {
                    readonly name: "converted_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Indicador de lead convertido (1 se convertido, 0 caso contrário)";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Identificador do lead";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável pelo lead";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do lead";
                }, {
                    readonly dimensionId: "lifecycleState";
                    readonly column: "lifecycle_state";
                    readonly type: "string";
                    readonly description: "Estado do ciclo de vida do lead";
                }];
                readonly measures: readonly [{
                    readonly measureId: "leadCount";
                    readonly column: "lead_count";
                    readonly aggregation: "count";
                    readonly unit: "leads";
                    readonly description: "Contagem de leads";
                }, {
                    readonly measureId: "qualifiedCount";
                    readonly column: "qualified_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Indicador de lead qualificado";
                }, {
                    readonly measureId: "convertedCount";
                    readonly column: "converted_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Indicador de lead convertido";
                }];
                readonly sourceWriteEvents: readonly ["createLead", "updateLead", "moveLeadStage", "classifyLeadTemperature"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createLeadUsecase", "updateLeadUsecase", "moveLeadStageUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_lead_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Índice primário de tempo para consultas de séries temporais";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_metrics_lead_id_time";
                        readonly columns: readonly ["lead_id", "event_time"];
                        readonly purpose: "Consultas de histórico de métricas por lead específico";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_metrics_broker_id_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consultas de métricas por corretor para dashboard de desempenho";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_metrics_status";
                        readonly columns: readonly ["status"];
                        readonly purpose: "Filtragem por status do lead para análise de pipeline";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_metrics_lifecycle_state";
                        readonly columns: readonly ["lifecycle_state"];
                        readonly purpose: "Filtragem por estado do ciclo de vida";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["ruleLeadRequiredFields", "ruleLeadPipelineTransition", "ruleBrokerAssignment"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadMetrics.defs.ts";
                readonly exportName: "leadMetricsDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadMetricsDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/propertyMetrics.defs" {
    export const propertyMetricsDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "propertyMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "propertyMetrics";
                readonly tableName: "property_metrics";
                readonly title: "Métrica de Imóveis Ativos";
                readonly purpose: "Acompanhar a evolução do estoque e status dos imóveis ao longo do tempo.";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de métrica";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do imóvel";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Corretor responsável pelo imóvel";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Status do imóvel (active, inactive, sold, rented, reserved)";
                }, {
                    readonly name: "lifecycle_state";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Estado do ciclo de vida do imóvel (draft, published, archived)";
                }, {
                    readonly name: "property_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de imóveis (sempre 1 por evento)";
                }, {
                    readonly name: "property_value";
                    readonly type: "numeric(15,2)";
                    readonly nullable: true;
                    readonly description: "Valor do imóvel para métricas de estoque em BRL";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "Identificador do imóvel";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável pelo imóvel";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do imóvel";
                }, {
                    readonly dimensionId: "lifecycleState";
                    readonly column: "lifecycle_state";
                    readonly type: "string";
                    readonly description: "Estado do ciclo de vida do imóvel";
                }];
                readonly measures: readonly [{
                    readonly measureId: "propertyCount";
                    readonly column: "property_count";
                    readonly aggregation: "count";
                    readonly unit: "imóveis";
                    readonly description: "Contagem de imóveis";
                }, {
                    readonly measureId: "propertyValue";
                    readonly column: "property_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor do imóvel para métricas de estoque";
                }];
                readonly sourceWriteEvents: readonly ["createProperty", "updateProperty", "changePropertyStatus"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createPropertyUsecase", "updatePropertyUsecase", "changePropertyStatusUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "7 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_property_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Índice primário de tempo para consultas de série temporal";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_property_metrics_property_id_time";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Consultas de histórico de métricas por imóvel";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_property_metrics_broker_id_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consultas de métricas por corretor responsável";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_property_metrics_status_time";
                        readonly columns: readonly ["status", "event_time"];
                        readonly purpose: "Filtragem por status do imóvel ao longo do tempo";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_property_metrics_lifecycle_time";
                        readonly columns: readonly ["lifecycle_state", "event_time"];
                        readonly purpose: "Filtragem por estado do ciclo de vida ao longo do tempo";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["rulePropertyRequiredFields", "rulePropertyStatusTransition", "ruleBrokerAssignment"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/propertyMetrics.defs.ts";
                readonly exportName: "propertyMetricsDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default propertyMetricsDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/visitMetrics.defs" {
    export const visitMetricsDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "visitMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "visitMetrics";
                readonly tableName: "visit_metrics";
                readonly title: "Métrica de Visitas Agendadas";
                readonly purpose: "Acompanhar agendamentos, confirmações, realizações e cancelamentos de visitas.";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de métrica";
                }, {
                    readonly name: "visit_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da visita";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pela visita";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead visitante";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel visitado";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Status da visita (scheduled, confirmed, completed, cancelled, noShow)";
                }, {
                    readonly name: "lifecycle_state";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Estado do ciclo de vida da visita (pending, done)";
                }, {
                    readonly name: "visit_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de visitas";
                }, {
                    readonly name: "completed_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Indicador de visita realizada (1 se completed, 0 caso contrário)";
                }, {
                    readonly name: "cancelled_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Indicador de visita cancelada (1 se cancelled, 0 caso contrário)";
                }, {
                    readonly name: "no_show_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Indicador de não comparecimento (1 se noShow, 0 caso contrário)";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "visitId";
                    readonly column: "visit_id";
                    readonly type: "string";
                    readonly description: "Identificador da visita";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável pela visita";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Lead visitante";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "Imóvel visitado";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status da visita";
                }, {
                    readonly dimensionId: "lifecycleState";
                    readonly column: "lifecycle_state";
                    readonly type: "string";
                    readonly description: "Estado do ciclo de vida da visita";
                }];
                readonly measures: readonly [{
                    readonly measureId: "visitCount";
                    readonly column: "visit_count";
                    readonly aggregation: "count";
                    readonly unit: "visitas";
                    readonly description: "Contagem de visitas";
                }, {
                    readonly measureId: "completedCount";
                    readonly column: "completed_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Visitas realizadas";
                }, {
                    readonly measureId: "cancelledCount";
                    readonly column: "cancelled_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Visitas canceladas";
                }, {
                    readonly measureId: "noShowCount";
                    readonly column: "no_show_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Visitas com não comparecimento";
                }];
                readonly sourceWriteEvents: readonly ["scheduleVisit", "confirmVisit", "completeVisit", "cancelVisit"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["scheduleVisitUsecase", "confirmVisitUsecase", "completeVisitUsecase", "cancelVisitUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "7 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_visit_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Índice primário de tempo para consultas de série temporal";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visit_metrics_broker_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consultas de métricas por corretor ao longo do tempo";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visit_metrics_lead_time";
                        readonly columns: readonly ["lead_id", "event_time"];
                        readonly purpose: "Consultas de métricas por lead ao longo do tempo";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visit_metrics_property_time";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Consultas de métricas por imóvel ao longo do tempo";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visit_metrics_status";
                        readonly columns: readonly ["status", "event_time"];
                        readonly purpose: "Filtragem por status da visita para análises de conversão";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visit_metrics_visit_id";
                        readonly columns: readonly ["visit_id"];
                        readonly purpose: "Consultas por identificador da visita";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitStatusTransition", "ruleBrokerAssignment", "ruleVisitPropertyActive"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitMetrics.defs.ts";
                readonly exportName: "visitMetricsDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitMetricsDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/visitTable.defs" {
    export const visitTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "visitTable";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "visitTable";
                readonly tableName: "visit";
                readonly title: "Visitas/Agendamentos";
                readonly purpose: "Armazenar registros de visitas agendadas entre leads e imóveis, incluindo status, data/hora e feedback";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly rootEntity: "Visit";
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly columns: readonly [{
                    readonly name: "visit_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da visita";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do lead que fará a visita";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do imóvel a ser visitado";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor responsável pela visita";
                }, {
                    readonly name: "scheduled_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora agendada para a visita";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly default: "scheduled";
                    readonly description: "Status da visita: scheduled, confirmed, completed, cancelled, noShow";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações sobre a visita";
                }, {
                    readonly name: "feedback";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Feedback do lead após a visita";
                }, {
                    readonly name: "rating";
                    readonly type: "smallint";
                    readonly nullable: true;
                    readonly description: "Avaliação do lead sobre o imóvel (1-5)";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Dados adicionais da visita em formato JSON";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização";
                }];
                readonly primaryKey: readonly ["visit_id"];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar dados adicionais como preferências de horário alternativo, informações de acompanhantes, ou metadados de integração com calendário";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao lead/cliente que realizará a visita, gerenciado pelo MDM de Lead";
                }, {
                    readonly fieldName: "property_id";
                    readonly targetEntity: "Property";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao imóvel a ser visitado, gerenciado pelo MDM de Imóvel";
                }, {
                    readonly fieldName: "broker_id";
                    readonly targetEntity: "Broker";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao corretor responsável pela visita, gerenciado pelo MDM de Corretor";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_visit_lead_id";
                    readonly columns: readonly ["lead_id"];
                    readonly unique: false;
                    readonly reason: "Consultas frequentes de visitas por lead para histórico e dashboard";
                }, {
                    readonly indexName: "idx_visit_property_id";
                    readonly columns: readonly ["property_id"];
                    readonly unique: false;
                    readonly reason: "Consultas de visitas agendadas por imóvel na página de detalhe do imóvel";
                }, {
                    readonly indexName: "idx_visit_broker_id";
                    readonly columns: readonly ["broker_id"];
                    readonly unique: false;
                    readonly reason: "Consultas de agenda do corretor no agendador de visitas";
                }, {
                    readonly indexName: "idx_visit_scheduled_at";
                    readonly columns: readonly ["scheduled_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por data/hora para calendário e workflows de confirmação";
                }, {
                    readonly indexName: "idx_visit_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtros por status para dashboard e relatórios de conversão";
                }, {
                    readonly indexName: "idx_visit_broker_scheduled";
                    readonly columns: readonly ["broker_id", "scheduled_at"];
                    readonly unique: false;
                    readonly reason: "Consulta composta para agenda do corretor ordenada por data";
                }];
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly metricRefs: readonly ["crmMetricsTable"];
                };
                readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitStatusTransition", "ruleVisitPropertyActive"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitTable.defs.ts";
                readonly exportName: "visitTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/advanceDealStage.defs" {
    export const useCase: {
        readonly usecaseId: "advanceDealStage";
        readonly title: "Avançar Etapa do Negócio";
        readonly purpose: "Avançar um negócio para a próxima etapa do pipeline";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
        readonly commands: readonly [{
            readonly commandId: "advanceDealStage";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "newStage";
                readonly type: "DealStatusEnum";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "previousStage";
                readonly type: "string";
            }, {
                readonly name: "currentStage";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/cancelVisit.defs" {
    export const useCase: {
        readonly usecaseId: "cancelVisit";
        readonly title: "Cancelar Visita";
        readonly purpose: "Cancelar uma visita agendada";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
        readonly commands: readonly [{
            readonly commandId: "cancelVisit";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "cancellationReason";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "cancelledBy";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/changePropertyStatus.defs" {
    export const useCase: {
        readonly usecaseId: "changePropertyStatus";
        readonly title: "Alterar Status do Imóvel";
        readonly purpose: "Alterar o status de um imóvel (ativo, inativo, vendido, alugado, reservado)";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["rulePropertyStatusTransition"];
        readonly commands: readonly [{
            readonly commandId: "changePropertyStatus";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "newStatus";
                readonly type: "PropertyStatusEnum";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }, {
                readonly name: "previousStatus";
                readonly type: "string";
            }, {
                readonly name: "currentStatus";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/closeDealLost.defs" {
    export const useCase: {
        readonly usecaseId: "closeDealLost";
        readonly title: "Fechar Negócio como Perdido";
        readonly purpose: "Fechar um negócio como perdido/não concluído";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
        readonly commands: readonly [{
            readonly commandId: "closeDealLost";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "lossReason";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "competitorInfo";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/closeDealWon.defs" {
    export const useCase: {
        readonly usecaseId: "closeDealWon";
        readonly title: "Fechar Negócio como Ganho";
        readonly purpose: "Fechar um negócio como ganho/concluído com sucesso";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
        readonly commands: readonly [{
            readonly commandId: "closeDealWon";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "finalValue";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "closingDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "commissionPercentage";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "propertyNewStatus";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/completeVisit.defs" {
    export const useCase: {
        readonly usecaseId: "completeVisit";
        readonly title: "Registrar Visita Realizada";
        readonly purpose: "Registrar que uma visita foi realizada com sucesso";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
        readonly commands: readonly [{
            readonly commandId: "completeVisit";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "feedback";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "leadInterest";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "nextSteps";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/confirmVisit.defs" {
    export const useCase: {
        readonly usecaseId: "confirmVisit";
        readonly title: "Confirmar Visita";
        readonly purpose: "Confirmar uma visita previamente agendada";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
        readonly commands: readonly [{
            readonly commandId: "confirmVisit";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "confirmedBy";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createBroker.defs" {
    export const useCase: {
        readonly usecaseId: "createBroker";
        readonly title: "Cadastrar Corretor";
        readonly purpose: "Cadastrar um novo corretor no sistema";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "broker";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["ruleBrokerRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "createBroker";
            readonly input: readonly [{
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "creci";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "specializations";
                readonly type: "string[]";
                readonly required: false;
            }, {
                readonly name: "regions";
                readonly type: "string[]";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createDeal.defs" {
    export const useCase: {
        readonly usecaseId: "createDeal";
        readonly title: "Criar Negócio/Proposta";
        readonly purpose: "Criar um novo negócio/proposta comercial";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleDealRequiredFields", "ruleDealPropertyActive"];
        readonly commands: readonly [{
            readonly commandId: "createDeal";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "proposedValue";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "dealType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "expectedCloseDate";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createLead.defs" {
    export const useCase: {
        readonly usecaseId: "createLead";
        readonly title: "Cadastrar Lead";
        readonly purpose: "Criar um novo lead/cliente potencial no sistema";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleLeadRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "createLead";
            readonly input: readonly [{
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "source";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "interestedPropertyType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "budget";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "preferredRegion";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createProperty.defs" {
    export const useCase: {
        readonly usecaseId: "createProperty";
        readonly title: "Cadastrar Imóvel";
        readonly purpose: "Criar um novo imóvel no sistema com dados básicos e fotos";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "createProperty";
            readonly input: readonly [{
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "propertyType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "transactionType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "address";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "city";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "neighborhood";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "area";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "bedrooms";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "bathrooms";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "parkingSpaces";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "features";
                readonly type: "string[]";
                readonly required: false;
            }, {
                readonly name: "photos";
                readonly type: "string[]";
                readonly required: false;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/deactivateBroker.defs" {
    export const useCase: {
        readonly usecaseId: "deactivateBroker";
        readonly title: "Desativar Corretor";
        readonly purpose: "Desativar um corretor no sistema";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "broker";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "broker";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["ruleBrokerAssignment"];
        readonly commands: readonly [{
            readonly commandId: "deactivateBroker";
            readonly input: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "reassignTo";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "reassignedLeads";
                readonly type: "number";
            }, {
                readonly name: "reassignedDeals";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/getDashboardMetrics.defs" {
    export const useCase: {
        readonly usecaseId: "getDashboardMetrics";
        readonly title: "Obter Métricas do Dashboard";
        readonly purpose: "Obter métricas consolidadas para o dashboard do gerente";
        readonly actor: "agencyManager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "getDashboardMetrics";
            readonly input: readonly [{
                readonly name: "period";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "activeProperties";
                readonly type: "number";
            }, {
                readonly name: "newLeadsThisMonth";
                readonly type: "number";
            }, {
                readonly name: "scheduledVisits";
                readonly type: "number";
            }, {
                readonly name: "openDeals";
                readonly type: "number";
            }, {
                readonly name: "closedDealsValue";
                readonly type: "number";
            }, {
                readonly name: "conversionRate";
                readonly type: "number";
            }, {
                readonly name: "brokerPerformance";
                readonly type: "BrokerMetric[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/getPropertyDetail.defs" {
    export const useCase: {
        readonly usecaseId: "getPropertyDetail";
        readonly title: "Obter Detalhe do Imóvel";
        readonly purpose: "Obter detalhes completos de um imóvel específico";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "getPropertyDetail";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "property";
                readonly type: "Property";
            }, {
                readonly name: "recentVisits";
                readonly type: "Visit[]";
            }, {
                readonly name: "activeDeals";
                readonly type: "Deal[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listBrokers.defs" {
    export const useCase: {
        readonly usecaseId: "listBrokers";
        readonly title: "Listar Corretores";
        readonly purpose: "Listar corretores cadastrados no sistema";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "broker";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listBrokers";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "BrokerStatusEnum";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "brokers";
                readonly type: "Broker[]";
            }, {
                readonly name: "total";
                readonly type: "number";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listDeals.defs" {
    export const useCase: {
        readonly usecaseId: "listDeals";
        readonly title: "Listar Negócios";
        readonly purpose: "Listar negócios/propostas com filtros para o rastreador";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listDeals";
            readonly input: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "status";
                readonly type: "DealStatusEnum";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "deals";
                readonly type: "Deal[]";
            }, {
                readonly name: "total";
                readonly type: "number";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listLeadInteractions.defs" {
    export const useCase: {
        readonly usecaseId: "listLeadInteractions";
        readonly title: "Listar Interações do Lead";
        readonly purpose: "Listar histórico de interações de um lead específico";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadInteractionEntity"];
        readonly outputEntities: readonly ["leadInteractionEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_interaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listLeadInteractions";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "interactionType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "interactions";
                readonly type: "LeadInteraction[]";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listLeads.defs" {
    export const useCase: {
        readonly usecaseId: "listLeads";
        readonly title: "Listar Leads";
        readonly purpose: "Listar leads com filtros e paginação para o pipeline";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listLeads";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "LeadStatusEnum";
                readonly required: false;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "source";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "temperature";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "leads";
                readonly type: "Lead[]";
            }, {
                readonly name: "total";
                readonly type: "number";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listProperties.defs" {
    export const useCase: {
        readonly usecaseId: "listProperties";
        readonly title: "Listar Imóveis";
        readonly purpose: "Listar imóveis com filtros e paginação";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listProperties";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "PropertyStatusEnum";
                readonly required: false;
            }, {
                readonly name: "propertyType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "transactionType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "city";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "neighborhood";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "minPrice";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "maxPrice";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "properties";
                readonly type: "Property[]";
            }, {
                readonly name: "total";
                readonly type: "number";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listVisits.defs" {
    export const useCase: {
        readonly usecaseId: "listVisits";
        readonly title: "Listar Visitas";
        readonly purpose: "Listar visitas agendadas com filtros para o calendário";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listVisits";
            readonly input: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "status";
                readonly type: "VisitStatusEnum";
                readonly required: false;
            }, {
                readonly name: "startDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "endDate";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visits";
                readonly type: "Visit[]";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/moveLeadStage.defs" {
    export const useCase: {
        readonly usecaseId: "moveLeadStage";
        readonly title: "Mover Lead de Etapa";
        readonly purpose: "Mover um lead para uma nova etapa do pipeline de vendas";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleLeadPipelineTransition"];
        readonly commands: readonly [{
            readonly commandId: "moveLeadStage";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "newStage";
                readonly type: "LeadStatusEnum";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }, {
                readonly name: "previousStage";
                readonly type: "string";
            }, {
                readonly name: "currentStage";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/registerInteraction.defs" {
    export const useCase: {
        readonly usecaseId: "registerInteraction";
        readonly title: "Registrar Interação";
        readonly purpose: "Registrar uma interação com um lead (ligação, email, reunião, etc.)";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadInteractionEntity"];
        readonly outputEntities: readonly ["leadInteractionEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead_interaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleInteractionRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "registerInteraction";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "interactionType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "interactionDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "outcome";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "nextAction";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "interactionId";
                readonly type: "string";
            }, {
                readonly name: "leadId";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/scheduleVisit.defs" {
    export const useCase: {
        readonly usecaseId: "scheduleVisit";
        readonly title: "Agendar Visita";
        readonly purpose: "Agendar uma visita a um imóvel para um lead";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "crm_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitPropertyActive"];
        readonly commands: readonly [{
            readonly commandId: "scheduleVisit";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "scheduledDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "scheduledTime";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateBroker.defs" {
    export const useCase: {
        readonly usecaseId: "updateBroker";
        readonly title: "Atualizar Corretor";
        readonly purpose: "Atualizar dados de um corretor existente";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "broker";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "broker";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["ruleBrokerRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "updateBroker";
            readonly input: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "specializations";
                readonly type: "string[]";
                readonly required: false;
            }, {
                readonly name: "regions";
                readonly type: "string[]";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "brokerId";
                readonly type: "string";
            }, {
                readonly name: "updated";
                readonly type: "boolean";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateLead.defs" {
    export const useCase: {
        readonly usecaseId: "updateLead";
        readonly title: "Atualizar Lead";
        readonly purpose: "Atualizar dados de um lead existente";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["ruleLeadRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "updateLead";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "interestedPropertyType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "budget";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "preferredRegion";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }, {
                readonly name: "updated";
                readonly type: "boolean";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateProperty.defs" {
    export const useCase: {
        readonly usecaseId: "updateProperty";
        readonly title: "Atualizar Imóvel";
        readonly purpose: "Atualizar dados de um imóvel existente";
        readonly actor: "broker";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
        readonly commands: readonly [{
            readonly commandId: "updateProperty";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "address";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "area";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "bedrooms";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "bathrooms";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "parkingSpaces";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "features";
                readonly type: "string[]";
                readonly required: false;
            }, {
                readonly name: "photos";
                readonly type: "string[]";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }, {
                readonly name: "updated";
                readonly type: "boolean";
            }];
        }];
    };
    export default useCase;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102045_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102045_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102045_/l2/propertyFlowCrm/brokerDashboard.defs" {
    export const brokerDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "brokerDashboard";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "brokerDashboard";
                readonly pageName: "Painel do Corretor";
                readonly actor: "broker";
                readonly purpose: "Visão geral das atividades do corretor com resumo de leads, visitas pendentes, negócios em andamento e tarefas de follow-up.";
                readonly capabilities: readonly ["viewDashboard", "manageLeads", "scheduleVisits", "trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["visitReminder", "leadFollowUp"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead", "property"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyList";
                    readonly trigger: "Acessar imóveis";
                    readonly description: "Navegar para lista de imóveis do corretor";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadList";
                    readonly trigger: "Acessar leads";
                    readonly description: "Navegar para pipeline de leads";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitList";
                    readonly trigger: "Acessar visitas";
                    readonly description: "Navegar para agenda de visitas";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealList";
                    readonly trigger: "Acessar negócios";
                    readonly description: "Navegar para pipeline de negócios";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo de Atividades";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "ActivitySummaryCards";
                        readonly purpose: "Exibir cards com contadores de leads ativos, visitas do dia, negócios em andamento e tarefas pendentes";
                        readonly userActions: readonly ["Visualizar resumo de atividades"];
                        readonly requiredEntities: readonly ["Lead", "Visit", "Deal"];
                        readonly readsFields: readonly ["Lead.status", "Lead.temperature", "Visit.status", "Visit.scheduledAt", "Deal.status", "Deal.pipelineStage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Leads Quentes";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "HotLeadsList";
                        readonly purpose: "Listar leads com temperatura quente que requerem atenção imediata do corretor";
                        readonly userActions: readonly ["Acessar leads quentes", "Navegar para detalhes do lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.fullName", "Lead.temperature", "Lead.pipelineStage", "Lead.lastContactAt", "Lead.suggestedFollowUpMessage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Visitas do Dia";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "TodayVisitsList";
                        readonly purpose: "Exibir lista de visitas agendadas para o dia atual com informações de lead, imóvel e horário";
                        readonly userActions: readonly ["Ver visitas do dia", "Navegar para detalhes da visita"];
                        readonly requiredEntities: readonly ["Visit", "Lead", "Property"];
                        readonly readsFields: readonly ["Visit.scheduledAt", "Visit.status", "Lead.fullName", "Property.address", "Property.propertyType"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Negócios em Andamento";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "ActiveDealsList";
                        readonly purpose: "Exibir negócios em andamento com etapa do pipeline, valor e próximas ações";
                        readonly userActions: readonly ["Visualizar negócios ativos", "Navegar para detalhes do negócio"];
                        readonly requiredEntities: readonly ["Deal", "Lead", "Property"];
                        readonly readsFields: readonly ["Deal.pipelineStage", "Deal.status", "Deal.value", "Lead.fullName", "Property.address"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getDashboardSummary";
                readonly purpose: "Obter contadores resumidos de leads, visitas e negócios para os cards do dashboard";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "activeLeadsCount";
                    readonly type: "number";
                }, {
                    readonly name: "hotLeadsCount";
                    readonly type: "number";
                }, {
                    readonly name: "todayVisitsCount";
                    readonly type: "number";
                }, {
                    readonly name: "activeDealsCount";
                    readonly type: "number";
                }, {
                    readonly name: "pendingTasksCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead", "visitEntity", "dealEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit", "deal"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads", "listVisits", "listDeals"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listHotLeads";
                readonly purpose: "Obter lista de leads com temperatura quente para exibição no dashboard";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "limit";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listTodayVisits";
                readonly purpose: "Obter visitas agendadas para o dia atual do corretor";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "visits";
                    readonly type: "Visit[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["visitEntity", "Lead", "Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listVisits"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listActiveDeals";
                readonly purpose: "Obter negócios em andamento do corretor para exibição no dashboard";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "limit";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "deals";
                    readonly type: "Deal[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["dealEntity", "Lead", "Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listDeals"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default brokerDashboardPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/brokerDetail.defs" {
    export const brokerDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "brokerDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 68;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "brokerDetail";
                readonly pageName: "Detalhes do Corretor";
                readonly actor: "admin";
                readonly purpose: "Visualizar informações do corretor e executar ações de edição ou desativação.";
                readonly capabilities: readonly ["manageBrokers"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["brokerLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["broker"];
                readonly pageInputs: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador único do corretor a ser visualizado";
                    readonly entityRef: "Broker";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "brokerList";
                    readonly trigger: "Ver detalhes";
                    readonly description: "Navegação a partir da lista de corretores";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "brokerForm";
                    readonly trigger: "Editar corretor";
                    readonly description: "Navegação para edição do corretor";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Informações do Corretor";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerInfoCard";
                        readonly purpose: "Exibir informações principais do corretor como nome, email, telefone, status e área de atuação.";
                        readonly userActions: readonly ["Ver detalhes"];
                        readonly requiredEntities: readonly ["Broker"];
                        readonly readsFields: readonly ["Broker.id", "Broker.fullName", "Broker.email", "Broker.phone", "Broker.role", "Broker.status", "Broker.createdAt", "Broker.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações do Corretor";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerActionsPanel";
                        readonly purpose: "Permitir ao administrador editar ou desativar o corretor.";
                        readonly userActions: readonly ["Editar corretor", "Desativar corretor"];
                        readonly requiredEntities: readonly ["Broker"];
                        readonly readsFields: readonly ["Broker.id", "Broker.status"];
                        readonly writesFields: readonly ["Broker.status"];
                        readonly rulesApplied: readonly ["ruleBrokerAssignment"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getBrokerDetail";
                readonly purpose: "Obter detalhes completos de um corretor específico pelo seu identificador.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "id";
                    readonly type: "string";
                }, {
                    readonly name: "fullName";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "role";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "BrokerStatusEnum";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Broker"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listBrokers"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "deactivateBroker";
                readonly purpose: "Desativar um corretor no sistema, opcionalmente reatribuindo leads e negócios.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "reassignTo";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "reassignedLeads";
                    readonly type: "number";
                }, {
                    readonly name: "reassignedDeals";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Broker"];
                readonly writesEntities: readonly ["Broker"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["deactivateBroker"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerAssignment"];
            }];
        };
    };
    export default brokerDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/brokerForm.defs" {
    export const brokerFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "brokerForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "brokerForm";
                readonly pageName: "Cadastro de Corretor";
                readonly actor: "admin";
                readonly purpose: "Cadastrar ou editar informações de um corretor.";
                readonly capabilities: readonly ["manageBrokers"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["brokerLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["broker"];
                readonly pageInputs: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do corretor para edição. Quando ausente, indica cadastro de novo corretor.";
                    readonly entityRef: "Broker";
                    readonly fieldRef: "brokerId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "brokerList";
                    readonly trigger: "Cadastrar corretor";
                    readonly description: "Navegação a partir da lista de corretores para criar novo corretor";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "brokerDetail";
                    readonly trigger: "Editar corretor";
                    readonly description: "Navegação a partir dos detalhes do corretor para edição";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "brokerDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Redireciona para detalhes do corretor após salvar com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Formulário de Corretor";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerDataForm";
                        readonly purpose: "Formulário para preenchimento dos dados do corretor incluindo nome, e-mail, telefone, CRECI, especializações e regiões de atuação.";
                        readonly userActions: readonly ["Preencher dados do corretor", "Selecionar especializações", "Selecionar regiões de atuação"];
                        readonly requiredEntities: readonly ["Broker"];
                        readonly readsFields: readonly ["Broker.name", "Broker.email", "Broker.phone", "Broker.creci", "Broker.specializations", "Broker.regions", "Broker.status"];
                        readonly writesFields: readonly ["Broker.name", "Broker.email", "Broker.phone", "Broker.creci", "Broker.specializations", "Broker.regions"];
                        readonly rulesApplied: readonly ["ruleBrokerRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Ações do Formulário";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerFormActions";
                        readonly purpose: "Botões de ação para salvar ou cancelar o cadastro/edição do corretor.";
                        readonly userActions: readonly ["Salvar corretor", "Cancelar e voltar"];
                        readonly requiredEntities: readonly ["Broker"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getBrokerForEdit";
                readonly purpose: "Buscar dados do corretor para preencher o formulário de edição";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "creci";
                    readonly type: "string";
                }, {
                    readonly name: "specializations";
                    readonly type: "string[]";
                }, {
                    readonly name: "regions";
                    readonly type: "string[]";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Broker"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "createBroker";
                readonly purpose: "Cadastrar novo corretor no sistema";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "creci";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "specializations";
                    readonly type: "string[]";
                    readonly required: false;
                }, {
                    readonly name: "regions";
                    readonly type: "string[]";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["Broker"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["createBroker"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerRequiredFields"];
            }, {
                readonly commandName: "updateBroker";
                readonly purpose: "Atualizar dados de um corretor existente";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "specializations";
                    readonly type: "string[]";
                    readonly required: false;
                }, {
                    readonly name: "regions";
                    readonly type: "string[]";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "brokerId";
                    readonly type: "string";
                }, {
                    readonly name: "updated";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["Broker"];
                readonly writesEntities: readonly ["Broker"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateBroker"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerRequiredFields"];
            }];
        };
    };
    export default brokerFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/brokerList.defs" {
    export const brokerListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "brokerList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 69;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "brokerList";
                readonly pageName: "Lista de Corretores";
                readonly actor: "admin";
                readonly purpose: "Listar e gerenciar corretores cadastrados no sistema.";
                readonly capabilities: readonly ["manageBrokers"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["brokerLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "brokerForm";
                    readonly trigger: "Cadastrar corretor";
                    readonly description: "Navegar para o formulário de cadastro de novo corretor";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "brokerDetail";
                    readonly trigger: "Ver detalhes do corretor";
                    readonly description: "Navegar para a página de detalhes de um corretor selecionado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerSearchFilter";
                        readonly purpose: "Permitir busca e filtragem de corretores por nome, status e outros critérios";
                        readonly userActions: readonly ["Buscar corretores", "Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Broker"];
                        readonly readsFields: readonly ["Broker.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Corretores";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerTable";
                        readonly purpose: "Exibir lista paginada de corretores com informações resumidas";
                        readonly userActions: readonly ["Ver detalhes", "Ordenar lista", "Navegar páginas"];
                        readonly requiredEntities: readonly ["Broker"];
                        readonly readsFields: readonly ["Broker.id", "Broker.fullName", "Broker.email", "Broker.phone", "Broker.role", "Broker.status", "Broker.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações Principais";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerListActions";
                        readonly purpose: "Fornecer ações principais como cadastrar novo corretor";
                        readonly userActions: readonly ["Cadastrar novo corretor"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listBrokers";
                readonly purpose: "Listar corretores cadastrados com filtros de status e paginação";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "BrokerStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "brokers";
                    readonly type: "Broker[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Broker"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listBrokers"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default brokerListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/dealDetail.defs" {
    export const dealDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 70;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealDetail";
                readonly pageName: "Detalhes do Negócio";
                readonly actor: "broker";
                readonly purpose: "Visualizar informações do negócio e executar ações de avanço de etapa ou fechamento.";
                readonly capabilities: readonly ["trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador único do negócio a ser visualizado";
                    readonly entityRef: "Deal";
                    readonly fieldRef: "dealId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dealList";
                    readonly trigger: "Ver detalhes";
                    readonly description: "Navegação a partir da lista de negócios";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Ver lead";
                    readonly description: "Navegar para detalhes do lead associado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Ver imóvel";
                    readonly description: "Navegar para detalhes do imóvel associado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Negócio";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "DealHeaderCard";
                        readonly purpose: "Exibir resumo do negócio com status atual, etapa do pipeline, tipo e valores";
                        readonly userActions: readonly ["Ver detalhes"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.dealType", "Deal.pipelineStage", "Deal.status", "Deal.proposedValue", "Deal.acceptedValue", "Deal.expectedCloseDate", "Deal.actualCloseDate", "Deal.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Informações Relacionadas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "DealLeadSummary";
                        readonly purpose: "Exibir resumo do lead associado ao negócio com link para detalhes";
                        readonly userActions: readonly ["Ver lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone", "Lead.temperature"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "DealPropertySummary";
                        readonly purpose: "Exibir resumo do imóvel associado ao negócio com link para detalhes";
                        readonly userActions: readonly ["Ver imóvel"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.propertyType", "Property.price", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Histórico e Notas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "DealNotesPanel";
                        readonly purpose: "Exibir notas e observações registradas sobre o negócio";
                        readonly userActions: readonly ["Ver detalhes"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.notes", "Deal.lossReason"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações do Negócio";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "DealStageAdvanceForm";
                        readonly purpose: "Permitir avançar o negócio para a próxima etapa do pipeline";
                        readonly userActions: readonly ["Avançar etapa"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.pipelineStage", "Deal.status"];
                        readonly writesFields: readonly ["Deal.pipelineStage", "Deal.updatedAt"];
                        readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
                    }, {
                        readonly organismName: "DealCloseWonForm";
                        readonly purpose: "Permitir fechar o negócio como ganho com valor final e data de fechamento";
                        readonly userActions: readonly ["Fechar como ganho"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.pipelineStage", "Deal.status", "Deal.proposedValue"];
                        readonly writesFields: readonly ["Deal.pipelineStage", "Deal.status", "Deal.acceptedValue", "Deal.actualCloseDate"];
                        readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
                    }, {
                        readonly organismName: "DealCloseLostForm";
                        readonly purpose: "Permitir fechar o negócio como perdido com motivo da perda";
                        readonly userActions: readonly ["Fechar como perdido"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.pipelineStage", "Deal.status"];
                        readonly writesFields: readonly ["Deal.pipelineStage", "Deal.status", "Deal.lossReason", "Deal.actualCloseDate"];
                        readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getDealDetail";
                readonly purpose: "Obter detalhes completos do negócio incluindo informações do lead e imóvel associados";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                }, {
                    readonly name: "dealType";
                    readonly type: "string";
                }, {
                    readonly name: "pipelineStage";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "proposedValue";
                    readonly type: "decimal";
                }, {
                    readonly name: "acceptedValue";
                    readonly type: "decimal";
                }, {
                    readonly name: "expectedCloseDate";
                    readonly type: "date";
                }, {
                    readonly name: "actualCloseDate";
                    readonly type: "date";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "lossReason";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "leadEmail";
                    readonly type: "string";
                }, {
                    readonly name: "leadPhone";
                    readonly type: "string";
                }, {
                    readonly name: "leadTemperature";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                }, {
                    readonly name: "propertyTitle";
                    readonly type: "string";
                }, {
                    readonly name: "propertyAddress";
                    readonly type: "string";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "propertyPrice";
                    readonly type: "decimal";
                }, {
                    readonly name: "propertyStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["dealEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listDeals"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "advanceDealStage";
                readonly purpose: "Avançar negócio para a próxima etapa do pipeline";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "newStage";
                    readonly type: "DealStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                }, {
                    readonly name: "previousStage";
                    readonly type: "string";
                }, {
                    readonly name: "currentStage";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["dealEntity"];
                readonly writesEntities: readonly ["dealEntity"];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly ["deal", "deal_pipeline_metrics"];
                readonly usecaseRefs: readonly ["advanceDealStage"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
            }, {
                readonly commandName: "closeDealWon";
                readonly purpose: "Fechar negócio como ganho com valor final e data de fechamento";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "finalValue";
                    readonly type: "decimal";
                    readonly required: true;
                }, {
                    readonly name: "closingDate";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "commissionPercentage";
                    readonly type: "decimal";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "propertyNewStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["dealEntity"];
                readonly writesEntities: readonly ["dealEntity"];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly ["deal", "deal_pipeline_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["closeDealWon"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
            }, {
                readonly commandName: "closeDealLost";
                readonly purpose: "Fechar negócio como perdido com motivo da perda";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "lossReason";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "competitorInfo";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["dealEntity"];
                readonly writesEntities: readonly ["dealEntity"];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly ["deal", "deal_pipeline_metrics"];
                readonly usecaseRefs: readonly ["closeDealLost"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealPipelineTransition"];
            }];
        };
    };
    export default dealDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/dealForm.defs" {
    export const dealFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealForm";
                readonly pageName: "Criar Negócio";
                readonly actor: "broker";
                readonly purpose: "Criar um novo negócio/proposta vinculando lead e imóvel com valor e condições.";
                readonly capabilities: readonly ["trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do lead pré-selecionado (opcional, vindo de leadDetail ou visitDetail)";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do imóvel pré-selecionado (opcional, vindo de visitDetail)";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dealList";
                    readonly trigger: "Criar negócio";
                    readonly description: "Acesso via botão de criar na lista de negócios";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Criar negócio";
                    readonly description: "Acesso via ação no detalhe do lead";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "visitDetail";
                    readonly trigger: "Criar negócio após visita";
                    readonly description: "Acesso via ação após visita realizada";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Navegação para detalhes do negócio criado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de Lead";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSelector";
                        readonly purpose: "Permitir busca e seleção do lead associado ao negócio, com pré-seleção se leadId fornecido.";
                        readonly userActions: readonly ["Selecionar lead", "Buscar lead por nome"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone", "Lead.temperature", "Lead.pipelineStage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleDealRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Seleção de Imóvel";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertySelector";
                        readonly purpose: "Permitir busca e seleção do imóvel objeto do negócio, com pré-seleção se propertyId fornecido. Filtra apenas imóveis ativos ou reservados.";
                        readonly userActions: readonly ["Selecionar imóvel", "Buscar imóvel por endereço ou código"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.propertyType", "Property.transactionType", "Property.price", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleDealPropertyActive"];
                    }];
                }, {
                    readonly sectionName: "Dados do Negócio";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "DealFormFields";
                        readonly purpose: "Capturar informações do negócio: tipo de negócio, valor proposto, data prevista de fechamento e observações.";
                        readonly userActions: readonly ["Definir valor e condições", "Preencher tipo de negócio", "Informar data prevista de fechamento", "Adicionar observações"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Deal.dealType", "Deal.proposedValue", "Deal.expectedCloseDate", "Deal.notes"];
                        readonly rulesApplied: readonly ["ruleDealRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "DealFormActions";
                        readonly purpose: "Botões de ação para salvar o negócio ou cancelar a operação.";
                        readonly userActions: readonly ["Salvar negócio", "Cancelar"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Deal.leadId", "Deal.propertyId", "Deal.brokerId", "Deal.dealType", "Deal.proposedValue", "Deal.pipelineStage", "Deal.status"];
                        readonly rulesApplied: readonly ["ruleDealRequiredFields", "ruleDealPropertyActive"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listLeadsForSelection";
                readonly purpose: "Listar leads disponíveis para seleção no formulário de criação de negócio, com busca e paginação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getLeadById";
                readonly purpose: "Obter dados de um lead específico para pré-seleção quando leadId é fornecido como input da página.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "temperature";
                    readonly type: "string";
                }, {
                    readonly name: "pipelineStage";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listPropertiesForSelection";
                readonly purpose: "Listar imóveis disponíveis (ativos ou reservados) para seleção no formulário de criação de negócio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "properties";
                    readonly type: "Property[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealPropertyActive"];
            }, {
                readonly commandName: "getPropertyById";
                readonly purpose: "Obter dados de um imóvel específico para pré-seleção quando propertyId é fornecido como input da página.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "uuid";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "decimal";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealPropertyActive"];
            }, {
                readonly commandName: "createDeal";
                readonly purpose: "Criar novo negócio/proposta vinculando lead, imóvel e corretor com valor e condições.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "dealType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "proposedValue";
                    readonly type: "decimal";
                    readonly required: true;
                }, {
                    readonly name: "expectedCloseDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead", "Property"];
                readonly writesEntities: readonly ["Deal"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["deal"];
                readonly usecaseRefs: readonly ["createDeal"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealRequiredFields", "ruleDealPropertyActive"];
            }];
        };
    };
    export default dealFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/dealList.defs" {
    export const dealListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 69;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealList";
                readonly pageName: "Lista de Negócios";
                readonly actor: "broker";
                readonly purpose: "Visualizar pipeline de negócios com filtros por etapa, valor e status.";
                readonly capabilities: readonly ["trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dealForm";
                    readonly trigger: "Criar negócio";
                    readonly description: "Navegar para formulário de criação de novo negócio";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealDetail";
                    readonly trigger: "Ver detalhes do negócio";
                    readonly description: "Navegar para detalhes de um negócio selecionado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "DealFiltersOrganism";
                        readonly purpose: "Permitir busca e filtragem de negócios por etapa do pipeline, status, valor e período.";
                        readonly userActions: readonly ["Buscar negócios", "Filtrar por etapa", "Filtrar por status", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.pipelineStage", "Deal.status", "Deal.proposedValue", "Deal.expectedCloseDate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Negócios";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "DealListOrganism";
                        readonly purpose: "Exibir lista de negócios do corretor com informações resumidas de lead, imóvel, valor e etapa do pipeline.";
                        readonly userActions: readonly ["Ver detalhes do negócio", "Ordenar lista"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.leadId", "Deal.propertyId", "Deal.dealType", "Deal.proposedValue", "Deal.pipelineStage", "Deal.status", "Deal.expectedCloseDate", "Deal.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "DealActionsOrganism";
                        readonly purpose: "Fornecer ação rápida para criar novo negócio.";
                        readonly userActions: readonly ["Criar novo negócio"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listDeals";
                readonly purpose: "Listar negócios do corretor com filtros de pipeline, status e paginação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "pipelineStage";
                    readonly type: "DealPipelineStageEnum";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "DealStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "minValue";
                    readonly type: "decimal";
                    readonly required: false;
                }, {
                    readonly name: "maxValue";
                    readonly type: "decimal";
                    readonly required: false;
                }, {
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "deals";
                    readonly type: "Deal[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["dealEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listDeals"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default dealListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/interactionForm.defs" {
    export const interactionFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "interactionForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "interactionForm";
                readonly pageName: "Registrar Interação";
                readonly actor: "broker";
                readonly purpose: "Registrar uma nova interação com o lead incluindo tipo, canal, notas e próximos passos.";
                readonly capabilities: readonly ["manageLeads"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadQualification"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do lead para o qual a interação será registrada";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Registrar interação";
                    readonly description: "Usuário clica em registrar interação na página de detalhes do lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Retorna aos detalhes do lead após salvar a interação";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Lead";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSummaryHeader";
                        readonly purpose: "Exibir resumo do lead para contexto durante o registro da interação";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.name", "Lead.email", "Lead.phone", "Lead.pipelineStage", "Lead.temperature"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Formulário de Interação";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "InteractionFormFields";
                        readonly purpose: "Capturar dados da interação incluindo tipo, direção, resumo e data/hora";
                        readonly userActions: readonly ["Preencher dados da interação", "Selecionar tipo de interação", "Selecionar direção", "Informar resumo", "Definir data/hora"];
                        readonly requiredEntities: readonly ["LeadInteraction"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["LeadInteraction.interactionType", "LeadInteraction.direction", "LeadInteraction.summary", "LeadInteraction.interactionAt"];
                        readonly rulesApplied: readonly ["ruleInteractionRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Próximos Passos";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "NextStepsFields";
                        readonly purpose: "Capturar informações opcionais sobre resultado e próxima ação";
                        readonly userActions: readonly ["Informar resultado da interação", "Definir próxima ação"];
                        readonly requiredEntities: readonly ["LeadInteraction"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["LeadInteraction.outcome", "LeadInteraction.nextAction"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "InteractionFormActions";
                        readonly purpose: "Botões para salvar ou cancelar o registro da interação";
                        readonly userActions: readonly ["Salvar interação", "Cancelar"];
                        readonly requiredEntities: readonly ["LeadInteraction"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleInteractionRequiredFields"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLeadSummary";
                readonly purpose: "Buscar resumo do lead para exibição no cabeçalho do formulário de interação";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "pipelineStage";
                    readonly type: "string";
                }, {
                    readonly name: "temperature";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "registerInteraction";
                readonly purpose: "Registrar uma nova interação com o lead";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "interactionType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "direction";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "summary";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "interactionAt";
                    readonly type: "datetime";
                    readonly required: true;
                }, {
                    readonly name: "outcome";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nextAction";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "interactionId";
                    readonly type: "uuid";
                }, {
                    readonly name: "leadId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly ["LeadInteraction"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_interaction", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["registerInteraction"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleInteractionRequiredFields"];
            }];
        };
    };
    export default interactionFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadDetail.defs" {
    export const leadDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 70;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadDetail";
                readonly pageName: "Detalhes do Lead";
                readonly actor: "broker";
                readonly purpose: "Visualizar informações completas do lead, histórico de interações, classificação de temperatura com IA e sugestões de follow-up.";
                readonly capabilities: readonly ["manageLeads", "classifyLeadTemperature", "suggestFollowUp"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadQualification"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["leadFollowUp"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador único do lead a ser visualizado";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadList";
                    readonly trigger: "Ver detalhes";
                    readonly description: "Navegação a partir da lista de leads";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadForm";
                    readonly trigger: "Editar lead";
                    readonly description: "Navegar para edição do lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "interactionForm";
                    readonly trigger: "Registrar interação";
                    readonly description: "Navegar para registro de nova interação";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitForm";
                    readonly trigger: "Agendar visita";
                    readonly description: "Navegar para agendamento de visita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealForm";
                    readonly trigger: "Criar negócio";
                    readonly description: "Navegar para criação de negócio";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Lead";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadHeaderCard";
                        readonly purpose: "Exibir informações principais do lead com nome, contato, etapa do pipeline e temperatura";
                        readonly userActions: readonly ["Editar lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.fullName", "Lead.email", "Lead.phone", "Lead.pipelineStage", "Lead.temperature", "Lead.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações do Pipeline";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PipelineStageActions";
                        readonly purpose: "Permitir mover o lead para outra etapa do pipeline respeitando as transições válidas";
                        readonly userActions: readonly ["Mover etapa"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.pipelineStage"];
                        readonly writesFields: readonly ["Lead.pipelineStage"];
                        readonly rulesApplied: readonly ["ruleLeadPipelineTransition"];
                    }];
                }, {
                    readonly sectionName: "Classificação e Follow-up com IA";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadTemperatureClassifier";
                        readonly purpose: "Exibir e permitir solicitar classificação de temperatura do lead via IA";
                        readonly userActions: readonly ["Classificar temperatura"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.temperature"];
                        readonly writesFields: readonly ["Lead.temperature"];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "FollowUpSuggestionPanel";
                        readonly purpose: "Exibir sugestão de follow-up gerada por IA e permitir solicitar nova sugestão";
                        readonly userActions: readonly ["Solicitar sugestão de follow-up"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.suggestedFollowUpMessage", "Lead.nextFollowUpAt"];
                        readonly writesFields: readonly ["Lead.suggestedFollowUpMessage", "Lead.nextFollowUpAt"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Histórico de Interações";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "InteractionTimeline";
                        readonly purpose: "Exibir timeline cronológica de todas as interações registradas com o lead";
                        readonly userActions: readonly ["Ver detalhes", "Registrar interação"];
                        readonly requiredEntities: readonly ["LeadInteraction"];
                        readonly readsFields: readonly ["LeadInteraction.interactionId", "LeadInteraction.interactionType", "LeadInteraction.direction", "LeadInteraction.summary", "LeadInteraction.interactionAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Visitas Relacionadas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadVisitsList";
                        readonly purpose: "Listar visitas agendadas ou realizadas para este lead";
                        readonly userActions: readonly ["Ver detalhes", "Agendar visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.propertyId", "Visit.scheduledAt", "Visit.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Negócios Relacionados";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadDealsList";
                        readonly purpose: "Listar negócios/propostas associados a este lead";
                        readonly userActions: readonly ["Ver detalhes", "Criar negócio"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.propertyId", "Deal.stage", "Deal.value", "Deal.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLeadDetails";
                readonly purpose: "Obter detalhes completos do lead incluindo dados de contato, etapa do pipeline, temperatura e sugestão de follow-up";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "fullName";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "pipelineStage";
                    readonly type: "LeadStatusEnum";
                }, {
                    readonly name: "temperature";
                    readonly type: "LeadTemperatureEnum";
                }, {
                    readonly name: "suggestedFollowUpMessage";
                    readonly type: "string";
                }, {
                    readonly name: "nextFollowUpAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "lastContactAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listLeadInteractions";
                readonly purpose: "Obter histórico de interações do lead ordenado cronologicamente";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "interactionType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "interactions";
                    readonly type: "LeadInteraction[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["LeadInteraction"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_interaction"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeadInteractions"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listLeadVisits";
                readonly purpose: "Listar visitas agendadas ou realizadas para o lead";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visits";
                    readonly type: "Visit[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Visit"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listLeadDeals";
                readonly purpose: "Listar negócios/propostas associados ao lead";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "deals";
                    readonly type: "Deal[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "moveLeadStage";
                readonly purpose: "Mover lead para outra etapa do pipeline respeitando transições válidas";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "newStage";
                    readonly type: "LeadStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "previousStage";
                    readonly type: "LeadStatusEnum";
                }, {
                    readonly name: "currentStage";
                    readonly type: "LeadStatusEnum";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["moveLeadStage"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineTransition"];
            }, {
                readonly commandName: "classifyLeadTemperature";
                readonly purpose: "Solicitar classificação de temperatura do lead via IA baseada no histórico de interações";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "temperature";
                    readonly type: "LeadTemperatureEnum";
                }, {
                    readonly name: "classificationReason";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead", "LeadInteraction"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly ["lead_interaction"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "generateFollowUpSuggestion";
                readonly purpose: "Gerar sugestão de mensagem de follow-up via IA para o lead";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "suggestedFollowUpMessage";
                    readonly type: "string";
                }, {
                    readonly name: "nextFollowUpAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead", "LeadInteraction"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly ["lead_interaction"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default leadDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadForm.defs" {
    export const leadFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadForm";
                readonly pageName: "Cadastro de Lead";
                readonly actor: "broker";
                readonly purpose: "Cadastrar ou editar informações de um lead incluindo dados de contato e preferências de imóvel.";
                readonly capabilities: readonly ["manageLeads"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadQualification"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do lead para edição. Quando ausente, indica criação de novo lead.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadList";
                    readonly trigger: "Cadastrar lead";
                    readonly description: "Navegação a partir da lista de leads para criar novo lead";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Editar lead";
                    readonly description: "Navegação a partir dos detalhes do lead para edição";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Redireciona para detalhes do lead após salvar com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Formulário de Lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadDataForm";
                        readonly purpose: "Formulário para preenchimento dos dados do lead incluindo informações de contato e preferências de imóvel.";
                        readonly userActions: readonly ["Preencher nome completo", "Preencher telefone", "Preencher e-mail", "Selecionar origem do lead", "Informar tipo de imóvel de interesse", "Informar orçamento", "Informar região preferida", "Adicionar notas"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.name", "Lead.email", "Lead.phone", "Lead.source", "Lead.interestedPropertyType", "Lead.budget", "Lead.preferredRegion", "Lead.notes"];
                        readonly writesFields: readonly ["Lead.name", "Lead.email", "Lead.phone", "Lead.source", "Lead.interestedPropertyType", "Lead.budget", "Lead.preferredRegion", "Lead.notes"];
                        readonly rulesApplied: readonly ["ruleLeadRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Ações do Formulário";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadFormActions";
                        readonly purpose: "Botões de ação para salvar ou cancelar o cadastro/edição do lead.";
                        readonly userActions: readonly ["Salvar lead", "Cancelar"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleLeadRequiredFields"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLeadForEdit";
                readonly purpose: "Buscar dados do lead existente para preencher o formulário de edição";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "source";
                    readonly type: "string";
                }, {
                    readonly name: "interestedPropertyType";
                    readonly type: "string";
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                }, {
                    readonly name: "preferredRegion";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "createLead";
                readonly purpose: "Cadastrar novo lead no sistema";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "source";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "interestedPropertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "preferredRegion";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["createLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadRequiredFields"];
            }, {
                readonly commandName: "updateLead";
                readonly purpose: "Atualizar dados de um lead existente";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "interestedPropertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "preferredRegion";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "updated";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadRequiredFields"];
            }];
        };
    };
    export default leadFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadList.defs" {
    export const leadListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 70;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadList";
                readonly pageName: "Lista de Leads";
                readonly actor: "broker";
                readonly purpose: "Visualizar pipeline de leads com filtros por etapa, temperatura e busca por nome ou contato.";
                readonly capabilities: readonly ["manageLeads"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadQualification"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "leadForm";
                    readonly trigger: "Cadastrar lead";
                    readonly description: "Navegar para o formulário de cadastro de novo lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Ver detalhes do lead";
                    readonly description: "Navegar para a página de detalhes de um lead selecionado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSearchFilter";
                        readonly purpose: "Permitir busca por nome ou contato e aplicação de filtros por etapa do pipeline e temperatura do lead.";
                        readonly userActions: readonly ["Buscar leads", "Filtrar por etapa", "Filtrar por temperatura", "Limpar filtros"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Leads";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadPipelineList";
                        readonly purpose: "Exibir lista de leads do corretor com informações resumidas como nome, contato, etapa do pipeline e temperatura.";
                        readonly userActions: readonly ["Ver detalhes do lead", "Cadastrar novo lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.id", "Lead.name", "Lead.email", "Lead.phone", "Lead.pipelineStage", "Lead.temperature", "Lead.lastContactAt", "Lead.source"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listLeads";
                readonly purpose: "Listar leads com filtros de pipeline, temperatura e busca textual para exibição no pipeline do corretor";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "LeadStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "temperature";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "source";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default leadListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/managerMetricsDashboard.defs" {
    export const managerMetricsDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "managerMetricsDashboard";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 68;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "managerMetricsDashboard";
                readonly pageName: "Dashboard de Métricas do Gerente";
                readonly actor: "agencyManager";
                readonly purpose: "Visualizar métricas consolidadas de imóveis, leads, visitas e negócios para tomada de decisão estratégica.";
                readonly capabilities: readonly ["viewDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de Período";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PeriodFilterBar";
                        readonly purpose: "Permitir ao gerente selecionar o período e filtros para análise das métricas.";
                        readonly userActions: readonly ["Filtrar por período", "Filtrar por corretor"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumo de Métricas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "MetricsSummaryCards";
                        readonly purpose: "Exibir cards com métricas principais: imóveis ativos, leads do mês, visitas agendadas, negócios abertos e valor fechado.";
                        readonly userActions: readonly ["Visualizar métricas"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["activeProperties", "newLeadsThisMonth", "scheduledVisits", "openDeals", "closedDealsValue", "conversionRate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Desempenho de Corretores";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "BrokerPerformanceTable";
                        readonly purpose: "Exibir tabela com desempenho individual de cada corretor incluindo leads, visitas e negócios.";
                        readonly userActions: readonly ["Analisar desempenho"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["brokerPerformance"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getDashboardMetrics";
                readonly purpose: "Obter métricas consolidadas do CRM para o dashboard do gerente, incluindo imóveis, leads, visitas, negócios e desempenho de corretores.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "period";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "activeProperties";
                    readonly type: "number";
                }, {
                    readonly name: "newLeadsThisMonth";
                    readonly type: "number";
                }, {
                    readonly name: "scheduledVisits";
                    readonly type: "number";
                }, {
                    readonly name: "openDeals";
                    readonly type: "number";
                }, {
                    readonly name: "closedDealsValue";
                    readonly type: "number";
                }, {
                    readonly name: "conversionRate";
                    readonly type: "number";
                }, {
                    readonly name: "brokerPerformance";
                    readonly type: "BrokerMetric[]";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["property_metrics", "lead_metrics", "deal_pipeline_metrics", "visit_metrics", "crm_activity_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default managerMetricsDashboardPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertyDetail.defs" {
    export const propertyDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 69;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyDetail";
                readonly pageName: "Detalhes do Imóvel";
                readonly actor: "broker";
                readonly purpose: "Visualizar informações completas do imóvel, histórico de visitas, leads interessados e alterar status.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador único do imóvel a ser visualizado";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "propertyList";
                    readonly trigger: "Ver detalhes";
                    readonly description: "Navegação a partir da lista de imóveis ao clicar em um item";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyForm";
                    readonly trigger: "Editar imóvel";
                    readonly description: "Navegação para edição do imóvel atual";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitForm";
                    readonly trigger: "Agendar visita";
                    readonly description: "Navegação para agendar uma nova visita para este imóvel";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Imóvel";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyHeader";
                        readonly purpose: "Exibir título, endereço, status atual e ações principais do imóvel";
                        readonly userActions: readonly ["Editar imóvel", "Alterar status"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["propertyId", "title", "address", "status", "type", "price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Informações Detalhadas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyDetails";
                        readonly purpose: "Exibir características completas do imóvel como área, quartos, banheiros, vagas e descrição";
                        readonly userActions: readonly ["Ver detalhes"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["area", "bedrooms", "bathrooms", "parkingSpaces", "description", "features", "photos"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Alteração de Status";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyStatusChanger";
                        readonly purpose: "Permitir ao corretor alterar o status do imóvel seguindo as regras de transição";
                        readonly userActions: readonly ["Alterar status"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["propertyId", "status"];
                        readonly writesFields: readonly ["status"];
                        readonly rulesApplied: readonly ["rulePropertyStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Histórico de Visitas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyVisitHistory";
                        readonly purpose: "Listar visitas recentes agendadas ou realizadas para este imóvel";
                        readonly userActions: readonly ["Agendar visita"];
                        readonly requiredEntities: readonly ["visitEntity"];
                        readonly readsFields: readonly ["visitId", "scheduledDate", "status", "leadName"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Negócios Ativos";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyActiveDeals";
                        readonly purpose: "Exibir negócios/propostas em andamento relacionados a este imóvel";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["dealEntity"];
                        readonly readsFields: readonly ["dealId", "stage", "value", "leadName", "createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getPropertyDetail";
                readonly purpose: "Obter detalhes completos do imóvel incluindo visitas recentes e negócios ativos";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "property";
                    readonly type: "Property";
                }, {
                    readonly name: "recentVisits";
                    readonly type: "Visit[]";
                }, {
                    readonly name: "activeDeals";
                    readonly type: "Deal[]";
                }];
                readonly readsEntities: readonly ["Property", "visitEntity", "dealEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit", "deal"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getPropertyDetail"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "changePropertyStatus";
                readonly purpose: "Alterar o status do imóvel seguindo as regras de transição do ciclo de vida";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "newStatus";
                    readonly type: "PropertyStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "previousStatus";
                    readonly type: "string";
                }, {
                    readonly name: "currentStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly ["Property"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["changePropertyStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatusTransition"];
            }];
        };
    };
    export default propertyDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertyForm.defs" {
    export const propertyFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 68;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyForm";
                readonly pageName: "Cadastro de Imóvel";
                readonly actor: "broker";
                readonly purpose: "Cadastrar ou editar informações de um imóvel incluindo características, fotos e geração de descrição com IA.";
                readonly capabilities: readonly ["manageProperties", "generatePropertyDescription"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "ID do imóvel para edição. Quando ausente, o formulário opera em modo de criação.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "propertyList";
                    readonly trigger: "Cadastrar imóvel";
                    readonly description: "Corretor clica em cadastrar novo imóvel na lista";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Editar imóvel";
                    readonly description: "Corretor clica em editar imóvel na página de detalhes";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Redireciona para detalhes do imóvel após salvar com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados Básicos do Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyBasicInfoForm";
                        readonly purpose: "Formulário para preenchimento de título, tipo de imóvel, tipo de transação, preço e status.";
                        readonly userActions: readonly ["Preencher título", "Selecionar tipo de imóvel", "Selecionar tipo de transação", "Informar preço"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.title", "Property.propertyType", "Property.transactionType", "Property.price", "Property.status"];
                        readonly writesFields: readonly ["Property.title", "Property.propertyType", "Property.transactionType", "Property.price"];
                        readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Endereço";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyAddressForm";
                        readonly purpose: "Formulário para preenchimento do endereço completo do imóvel.";
                        readonly userActions: readonly ["Preencher logradouro", "Preencher bairro", "Preencher cidade", "Preencher estado"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.address", "Property.neighborhood", "Property.city", "Property.state"];
                        readonly writesFields: readonly ["Property.address", "Property.neighborhood", "Property.city", "Property.state"];
                        readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Características";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyFeaturesForm";
                        readonly purpose: "Formulário para preenchimento de área, quartos, banheiros, vagas e características adicionais.";
                        readonly userActions: readonly ["Informar área", "Informar número de quartos", "Informar número de banheiros", "Informar vagas de garagem", "Adicionar características"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.area", "Property.bedrooms", "Property.bathrooms", "Property.parkingSpaces", "Property.features"];
                        readonly writesFields: readonly ["Property.area", "Property.bedrooms", "Property.bathrooms", "Property.parkingSpaces", "Property.features"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Descrição";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyDescriptionForm";
                        readonly purpose: "Área de texto para descrição do imóvel com opção de geração automática via IA.";
                        readonly userActions: readonly ["Preencher descrição manualmente", "Gerar descrição com IA"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.description", "Property.features", "Property.propertyType", "Property.bedrooms", "Property.bathrooms", "Property.area"];
                        readonly writesFields: readonly ["Property.description"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Fotos";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyPhotosUploader";
                        readonly purpose: "Componente para upload e gerenciamento de fotos do imóvel.";
                        readonly userActions: readonly ["Fazer upload de fotos", "Remover fotos", "Reordenar fotos"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.photos"];
                        readonly writesFields: readonly ["Property.photos"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyFormActions";
                        readonly purpose: "Botões de ação para salvar ou cancelar o cadastro/edição do imóvel.";
                        readonly userActions: readonly ["Salvar imóvel", "Cancelar"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getPropertyDetail";
                readonly purpose: "Obter detalhes do imóvel para preencher o formulário em modo de edição";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                }, {
                    readonly name: "city";
                    readonly type: "string";
                }, {
                    readonly name: "state";
                    readonly type: "string";
                }, {
                    readonly name: "area";
                    readonly type: "number";
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                }, {
                    readonly name: "parkingSpaces";
                    readonly type: "number";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                }, {
                    readonly name: "features";
                    readonly type: "string[]";
                }, {
                    readonly name: "photos";
                    readonly type: "string[]";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getPropertyDetail"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "createProperty";
                readonly purpose: "Cadastrar novo imóvel no sistema";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "state";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "parkingSpaces";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "features";
                    readonly type: "string[]";
                    readonly required: false;
                }, {
                    readonly name: "photos";
                    readonly type: "string[]";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["Property"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["createProperty"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
            }, {
                readonly commandName: "updateProperty";
                readonly purpose: "Atualizar imóvel existente";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "state";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "parkingSpaces";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "features";
                    readonly type: "string[]";
                    readonly required: false;
                }, {
                    readonly name: "photos";
                    readonly type: "string[]";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "updated";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly ["Property"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateProperty"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyRequiredFields"];
            }, {
                readonly commandName: "generatePropertyDescription";
                readonly purpose: "Gerar descrição comercial do imóvel utilizando IA a partir das características informadas";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "parkingSpaces";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "features";
                    readonly type: "string[]";
                    readonly required: false;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "generatedDescription";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default propertyFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertyList.defs" {
    export const propertyListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyList";
                readonly pageName: "Lista de Imóveis";
                readonly actor: "broker";
                readonly purpose: "Listar e filtrar imóveis cadastrados pelo corretor com opções de busca por status, tipo e localização.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyForm";
                    readonly trigger: "Cadastrar imóvel";
                    readonly description: "Navegar para o formulário de cadastro de novo imóvel";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Ver detalhes do imóvel";
                    readonly description: "Navegar para a página de detalhes de um imóvel selecionado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyFiltersForm";
                        readonly purpose: "Permitir ao corretor filtrar imóveis por status, tipo de imóvel, tipo de transação, cidade, bairro e faixa de preço.";
                        readonly userActions: readonly ["Buscar imóveis", "Filtrar por status", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.status", "Property.propertyType", "Property.transactionType", "Property.city", "Property.neighborhood", "Property.price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Imóveis";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyListTable";
                        readonly purpose: "Exibir a lista de imóveis do corretor com informações resumidas como título, endereço, tipo, preço e status.";
                        readonly userActions: readonly ["Ver detalhes do imóvel", "Ordenar lista", "Navegar paginação"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.id", "Property.title", "Property.address", "Property.city", "Property.neighborhood", "Property.propertyType", "Property.transactionType", "Property.price", "Property.status", "Property.mainPhoto"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações Principais";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyListActions";
                        readonly purpose: "Fornecer ação rápida para cadastrar novo imóvel.";
                        readonly userActions: readonly ["Cadastrar novo imóvel"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listProperties";
                readonly purpose: "Listar imóveis do corretor com filtros de status, tipo, localização e faixa de preço, com suporte a paginação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "minPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "maxPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "properties";
                    readonly type: "Property[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default propertyListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitDetail.defs" {
    export const visitDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitDetail";
                readonly pageName: "Detalhes da Visita";
                readonly actor: "broker";
                readonly purpose: "Visualizar informações da visita e executar ações de confirmação, realização ou cancelamento.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador único da visita a ser visualizada";
                    readonly entityRef: "Visit";
                    readonly fieldRef: "visitId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "visitList";
                    readonly trigger: "Ver detalhes";
                    readonly description: "Navegação a partir da lista de visitas";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealForm";
                    readonly trigger: "Criar negócio após visita";
                    readonly description: "Criar negócio após visita realizada com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho da Visita";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitHeaderCard";
                        readonly purpose: "Exibir informações principais da visita: status, data/hora agendada e corretor responsável.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.status", "Visit.scheduledAt", "Visit.brokerId", "Visit.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Informações do Lead";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadInfoCard";
                        readonly purpose: "Exibir dados do lead vinculado à visita para contexto do corretor.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Informações do Imóvel";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyInfoCard";
                        readonly purpose: "Exibir dados do imóvel vinculado à visita para referência rápida.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.type", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações da Visita";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitActionsPanel";
                        readonly purpose: "Permitir ao corretor executar ações de confirmação, registro de realização ou cancelamento da visita conforme o status atual.";
                        readonly userActions: readonly ["Confirmar visita", "Registrar realização", "Cancelar visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status"];
                        readonly writesFields: readonly ["Visit.status", "Visit.feedback", "Visit.rating"];
                        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Formulário de Realização";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "CompleteVisitForm";
                        readonly purpose: "Capturar feedback e avaliação do lead após a visita ser realizada.";
                        readonly userActions: readonly ["Registrar realização"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status"];
                        readonly writesFields: readonly ["Visit.feedback", "Visit.rating"];
                        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Formulário de Cancelamento";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "CancelVisitForm";
                        readonly purpose: "Capturar motivo do cancelamento da visita.";
                        readonly userActions: readonly ["Cancelar visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status"];
                        readonly writesFields: readonly ["Visit.status"];
                        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getVisitDetail";
                readonly purpose: "Obter detalhes completos da visita incluindo dados do lead e imóvel vinculados";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "feedback";
                    readonly type: "string";
                }, {
                    readonly name: "rating";
                    readonly type: "number";
                }, {
                    readonly name: "brokerId";
                    readonly type: "uuid";
                }, {
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "leadEmail";
                    readonly type: "string";
                }, {
                    readonly name: "leadPhone";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                }, {
                    readonly name: "propertyTitle";
                    readonly type: "string";
                }, {
                    readonly name: "propertyAddress";
                    readonly type: "string";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "propertyStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listVisits"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "confirmVisit";
                readonly purpose: "Confirmar visita agendada alterando status para confirmed";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "confirmedBy";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly ["visitEntity"];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly ["visit", "visit_metrics"];
                readonly usecaseRefs: readonly ["confirmVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
            }, {
                readonly commandName: "completeVisit";
                readonly purpose: "Registrar visita como realizada com feedback opcional do lead";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "feedback";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadInterest";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nextSteps";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly ["visitEntity"];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly ["visit", "visit_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["completeVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
            }, {
                readonly commandName: "cancelVisit";
                readonly purpose: "Cancelar visita agendada ou confirmada com motivo obrigatório";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "cancelledBy";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly ["visitEntity"];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly ["visit", "visit_metrics"];
                readonly usecaseRefs: readonly ["cancelVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
            }];
        };
    };
    export default visitDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitForm.defs" {
    export const visitFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 68;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitForm";
                readonly pageName: "Agendar Visita";
                readonly actor: "broker";
                readonly purpose: "Agendar uma nova visita selecionando lead, imóvel, data e horário.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do lead pré-selecionado (opcional, vindo de leadDetail ou outro contexto)";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do imóvel pré-selecionado (opcional, vindo de propertyDetail ou outro contexto)";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "visitList";
                    readonly trigger: "Agendar visita";
                    readonly description: "Acesso a partir da lista de visitas";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Agendar visita";
                    readonly description: "Acesso a partir dos detalhes do lead com leadId pré-selecionado";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Agendar visita";
                    readonly description: "Acesso a partir dos detalhes do imóvel com propertyId pré-selecionado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Redirecionamento para detalhes da visita após agendamento bem-sucedido";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de Lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSelector";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o lead que fará a visita";
                        readonly userActions: readonly ["Buscar lead", "Selecionar lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone", "Lead.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Seleção de Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertySelector";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o imóvel a ser visitado";
                        readonly userActions: readonly ["Buscar imóvel", "Selecionar imóvel"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.status", "Property.propertyType", "Property.price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitPropertyActive"];
                    }];
                }, {
                    readonly sectionName: "Agendamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitScheduleForm";
                        readonly purpose: "Capturar data, horário e observações da visita";
                        readonly userActions: readonly ["Definir data/hora", "Adicionar observações"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visit.scheduledAt", "Visit.notes"];
                        readonly rulesApplied: readonly ["ruleVisitRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitFormActions";
                        readonly purpose: "Botões de ação para salvar ou cancelar o agendamento";
                        readonly userActions: readonly ["Salvar visita", "Cancelar"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visit.leadId", "Visit.propertyId", "Visit.brokerId", "Visit.scheduledAt", "Visit.status", "Visit.notes"];
                        readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitPropertyActive"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listLeadsForSelection";
                readonly purpose: "Listar leads disponíveis para seleção no agendamento de visita";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "LeadStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listPropertiesForSelection";
                readonly purpose: "Listar imóveis ativos/reservados disponíveis para seleção no agendamento de visita";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "properties";
                    readonly type: "Property[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitPropertyActive"];
            }, {
                readonly commandName: "getLeadById";
                readonly purpose: "Obter dados do lead pré-selecionado quando leadId é fornecido como input da página";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "LeadStatusEnum";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getPropertyById";
                readonly purpose: "Obter dados do imóvel pré-selecionado quando propertyId é fornecido como input da página";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "uuid";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitPropertyActive"];
            }, {
                readonly commandName: "scheduleVisit";
                readonly purpose: "Agendar nova visita vinculando lead, imóvel, corretor e data/hora";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "scheduledDate";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "scheduledTime";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead", "Property"];
                readonly writesEntities: readonly ["Visit"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit"];
                readonly usecaseRefs: readonly ["scheduleVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitPropertyActive"];
            }];
        };
    };
    export default visitFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitList.defs" {
    export const visitListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 69;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitList";
                readonly pageName: "Lista de Visitas";
                readonly actor: "broker";
                readonly purpose: "Visualizar agenda de visitas com filtros por data, status e imóvel.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["visitReminder"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "visitForm";
                    readonly trigger: "Agendar visita";
                    readonly description: "Navegar para formulário de agendamento de nova visita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitDetail";
                    readonly trigger: "Ver detalhes da visita";
                    readonly description: "Navegar para detalhes de uma visita selecionada";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitFiltersForm";
                        readonly purpose: "Permitir ao corretor filtrar visitas por data, status e imóvel";
                        readonly userActions: readonly ["Buscar visitas", "Filtrar por status", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status", "Visit.scheduledAt", "Visit.propertyId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Visitas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitListTable";
                        readonly purpose: "Exibir lista de visitas agendadas com informações resumidas de lead, imóvel, data e status";
                        readonly userActions: readonly ["Ver detalhes da visita", "Agendar nova visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.leadId", "Visit.propertyId", "Visit.brokerId", "Visit.scheduledAt", "Visit.status", "Visit.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listVisits";
                readonly purpose: "Listar visitas agendadas com filtros por data, status e imóvel para o corretor autenticado";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "VisitStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "startDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "endDate";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visits";
                    readonly type: "Visit[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listVisits"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default visitListPagePlan;
}
