declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102045_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102045_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102045_/l2/propertyFlowCrm/propertyList.defs" {
    export const propertyListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyList";
                readonly pageName: "Lista de Imóveis";
                readonly actor: "broker";
                readonly purpose: "Listar e filtrar imóveis cadastrados pelo corretor com opções de busca por status, tipo e localização.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyForm";
                    readonly trigger: "Cadastrar imóvel";
                    readonly description: "Navegar para o formulário de cadastro de novo imóvel";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Ver detalhes do imóvel";
                    readonly description: "Navegar para a página de detalhes de um imóvel selecionado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyFiltersForm";
                        readonly purpose: "Permitir ao corretor filtrar imóveis por status, tipo de imóvel, tipo de transação, cidade, bairro e faixa de preço.";
                        readonly userActions: readonly ["Buscar imóveis", "Filtrar por status", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.status", "Property.propertyType", "Property.transactionType", "Property.city", "Property.neighborhood", "Property.price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Imóveis";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyListTable";
                        readonly purpose: "Exibir a lista de imóveis do corretor com informações resumidas como título, endereço, tipo, preço e status.";
                        readonly userActions: readonly ["Ver detalhes do imóvel", "Ordenar lista", "Navegar paginação"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.id", "Property.title", "Property.address", "Property.city", "Property.neighborhood", "Property.propertyType", "Property.transactionType", "Property.price", "Property.status", "Property.mainPhoto"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações Principais";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyListActions";
                        readonly purpose: "Fornecer ação rápida para cadastrar novo imóvel.";
                        readonly userActions: readonly ["Cadastrar novo imóvel"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listProperties";
                readonly purpose: "Listar imóveis do corretor com filtros de status, tipo, localização e faixa de preço, com suporte a paginação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "minPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "maxPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "properties";
                    readonly type: "Property[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default propertyListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitDetail.defs" {
    export const visitDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitDetail";
                readonly pageName: "Detalhes da Visita";
                readonly actor: "broker";
                readonly purpose: "Visualizar informações da visita e executar ações de confirmação, realização ou cancelamento.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador único da visita a ser visualizada";
                    readonly entityRef: "Visit";
                    readonly fieldRef: "visitId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "visitList";
                    readonly trigger: "Ver detalhes";
                    readonly description: "Navegação a partir da lista de visitas";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealForm";
                    readonly trigger: "Criar negócio após visita";
                    readonly description: "Criar negócio após visita realizada com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho da Visita";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitHeaderCard";
                        readonly purpose: "Exibir informações principais da visita: status, data/hora agendada e corretor responsável.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.status", "Visit.scheduledAt", "Visit.brokerId", "Visit.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Informações do Lead";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadInfoCard";
                        readonly purpose: "Exibir dados do lead vinculado à visita para contexto do corretor.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Informações do Imóvel";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyInfoCard";
                        readonly purpose: "Exibir dados do imóvel vinculado à visita para referência rápida.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.type", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações da Visita";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitActionsPanel";
                        readonly purpose: "Permitir ao corretor executar ações de confirmação, registro de realização ou cancelamento da visita conforme o status atual.";
                        readonly userActions: readonly ["Confirmar visita", "Registrar realização", "Cancelar visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status"];
                        readonly writesFields: readonly ["Visit.status", "Visit.feedback", "Visit.rating"];
                        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Formulário de Realização";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "CompleteVisitForm";
                        readonly purpose: "Capturar feedback e avaliação do lead após a visita ser realizada.";
                        readonly userActions: readonly ["Registrar realização"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status"];
                        readonly writesFields: readonly ["Visit.feedback", "Visit.rating"];
                        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Formulário de Cancelamento";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "CancelVisitForm";
                        readonly purpose: "Capturar motivo do cancelamento da visita.";
                        readonly userActions: readonly ["Cancelar visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status"];
                        readonly writesFields: readonly ["Visit.status"];
                        readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getVisitDetail";
                readonly purpose: "Obter detalhes completos da visita incluindo dados do lead e imóvel vinculados";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "feedback";
                    readonly type: "string";
                }, {
                    readonly name: "rating";
                    readonly type: "number";
                }, {
                    readonly name: "brokerId";
                    readonly type: "uuid";
                }, {
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "leadEmail";
                    readonly type: "string";
                }, {
                    readonly name: "leadPhone";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                }, {
                    readonly name: "propertyTitle";
                    readonly type: "string";
                }, {
                    readonly name: "propertyAddress";
                    readonly type: "string";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "propertyStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listVisits"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "confirmVisit";
                readonly purpose: "Confirmar visita agendada alterando status para confirmed";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "confirmedBy";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly ["visitEntity"];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly ["visit", "visit_metrics"];
                readonly usecaseRefs: readonly ["confirmVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
            }, {
                readonly commandName: "completeVisit";
                readonly purpose: "Registrar visita como realizada com feedback opcional do lead";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "feedback";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadInterest";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nextSteps";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly ["visitEntity"];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly ["visit", "visit_metrics", "crm_activity_metrics"];
                readonly usecaseRefs: readonly ["completeVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
            }, {
                readonly commandName: "cancelVisit";
                readonly purpose: "Cancelar visita agendada ou confirmada com motivo obrigatório";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "cancelledBy";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly ["visitEntity"];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly ["visit", "visit_metrics"];
                readonly usecaseRefs: readonly ["cancelVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatusTransition"];
            }];
        };
    };
    export default visitDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitForm.defs" {
    export const visitFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 68;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitForm";
                readonly pageName: "Agendar Visita";
                readonly actor: "broker";
                readonly purpose: "Agendar uma nova visita selecionando lead, imóvel, data e horário.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do lead pré-selecionado (opcional, vindo de leadDetail ou outro contexto)";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do imóvel pré-selecionado (opcional, vindo de propertyDetail ou outro contexto)";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "visitList";
                    readonly trigger: "Agendar visita";
                    readonly description: "Acesso a partir da lista de visitas";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Agendar visita";
                    readonly description: "Acesso a partir dos detalhes do lead com leadId pré-selecionado";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Agendar visita";
                    readonly description: "Acesso a partir dos detalhes do imóvel com propertyId pré-selecionado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitDetail";
                    readonly trigger: "Após salvar";
                    readonly description: "Redirecionamento para detalhes da visita após agendamento bem-sucedido";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de Lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSelector";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o lead que fará a visita";
                        readonly userActions: readonly ["Buscar lead", "Selecionar lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone", "Lead.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Seleção de Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertySelector";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o imóvel a ser visitado";
                        readonly userActions: readonly ["Buscar imóvel", "Selecionar imóvel"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.status", "Property.propertyType", "Property.price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitPropertyActive"];
                    }];
                }, {
                    readonly sectionName: "Agendamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitScheduleForm";
                        readonly purpose: "Capturar data, horário e observações da visita";
                        readonly userActions: readonly ["Definir data/hora", "Adicionar observações"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visit.scheduledAt", "Visit.notes"];
                        readonly rulesApplied: readonly ["ruleVisitRequiredFields"];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitFormActions";
                        readonly purpose: "Botões de ação para salvar ou cancelar o agendamento";
                        readonly userActions: readonly ["Salvar visita", "Cancelar"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visit.leadId", "Visit.propertyId", "Visit.brokerId", "Visit.scheduledAt", "Visit.status", "Visit.notes"];
                        readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitPropertyActive"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listLeadsForSelection";
                readonly purpose: "Listar leads disponíveis para seleção no agendamento de visita";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "LeadStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listPropertiesForSelection";
                readonly purpose: "Listar imóveis ativos/reservados disponíveis para seleção no agendamento de visita";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "properties";
                    readonly type: "Property[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitPropertyActive"];
            }, {
                readonly commandName: "getLeadById";
                readonly purpose: "Obter dados do lead pré-selecionado quando leadId é fornecido como input da página";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "LeadStatusEnum";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getPropertyById";
                readonly purpose: "Obter dados do imóvel pré-selecionado quando propertyId é fornecido como input da página";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "uuid";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitPropertyActive"];
            }, {
                readonly commandName: "scheduleVisit";
                readonly purpose: "Agendar nova visita vinculando lead, imóvel, corretor e data/hora";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "propertyId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "scheduledDate";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "scheduledTime";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead", "Property"];
                readonly writesEntities: readonly ["Visit"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit"];
                readonly usecaseRefs: readonly ["scheduleVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiredFields", "ruleVisitPropertyActive"];
            }];
        };
    };
    export default visitFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitList.defs" {
    export const visitListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 69;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitList";
                readonly pageName: "Lista de Visitas";
                readonly actor: "broker";
                readonly purpose: "Visualizar agenda de visitas com filtros por data, status e imóvel.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["visitReminder"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "visitForm";
                    readonly trigger: "Agendar visita";
                    readonly description: "Navegar para formulário de agendamento de nova visita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitDetail";
                    readonly trigger: "Ver detalhes da visita";
                    readonly description: "Navegar para detalhes de uma visita selecionada";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de Busca";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitFiltersForm";
                        readonly purpose: "Permitir ao corretor filtrar visitas por data, status e imóvel";
                        readonly userActions: readonly ["Buscar visitas", "Filtrar por status", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.status", "Visit.scheduledAt", "Visit.propertyId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de Visitas";
                    readonly mode: "readonly";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitListTable";
                        readonly purpose: "Exibir lista de visitas agendadas com informações resumidas de lead, imóvel, data e status";
                        readonly userActions: readonly ["Ver detalhes da visita", "Agendar nova visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.leadId", "Visit.propertyId", "Visit.brokerId", "Visit.scheduledAt", "Visit.status", "Visit.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listVisits";
                readonly purpose: "Listar visitas agendadas com filtros por data, status e imóvel para o corretor autenticado";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "VisitStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "startDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "endDate";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visits";
                    readonly type: "Visit[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["visitEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listVisits"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default visitListPagePlan;
}
