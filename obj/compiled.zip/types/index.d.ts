declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/Corretor.defs" {
    export const CorretorMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Corretor";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Corretor";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "manterPropertyFlowCrm";
            readonly domainId: "broker";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Corretor";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["rule-rbac-data-isolation"];
            readonly title: "Corretor";
            readonly description: "Entidade mestre de corretores vinculados à imobiliária. Referenciada por Visitas, Leads e Negócios para controle de acesso e isolamento de registros por perfil.";
            readonly fields: readonly [{
                readonly fieldId: "corretorId";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador único do corretor (UUID), vinculado ao userId do sistema de autenticação.";
            }, {
                readonly fieldId: "userId";
                readonly type: "string";
                readonly required: true;
                readonly description: "ID do usuário no sistema de autenticação (RBAC).";
            }, {
                readonly fieldId: "fullName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome completo do corretor.";
            }, {
                readonly fieldId: "email";
                readonly type: "string";
                readonly required: true;
                readonly description: "E-mail profissional do corretor.";
            }, {
                readonly fieldId: "phone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do corretor.";
            }, {
                readonly fieldId: "role";
                readonly type: "enum(admin,corretor,assistente)";
                readonly required: true;
                readonly description: "Perfil de acesso do corretor no sistema.";
            }, {
                readonly fieldId: "creci";
                readonly type: "string";
                readonly required: false;
                readonly description: "Número do CRECI (Conselho Regional de Corretores de Imóveis).";
            }, {
                readonly fieldId: "avatarUrl";
                readonly type: "string";
                readonly required: false;
                readonly description: "URL da foto de perfil do corretor.";
            }, {
                readonly fieldId: "status";
                readonly type: "enum(ativo,inativo)";
                readonly required: true;
                readonly description: "Status do corretor na imobiliária.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização.";
            }];
        };
    };
    export default CorretorMdm;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/Lead.defs" {
    export const LeadMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Lead";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Lead";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "manterPropertyFlowCrm";
            readonly domainId: "lead";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Lead / Cliente";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["rule-lead-stage-transition", "rule-rbac-data-isolation"];
            readonly title: "Lead / Cliente";
            readonly description: "Entidade mestre de leads e clientes com dados de contato, anotações, classificação de temperatura gerada por IA, histórico de interações e corretor responsável.";
            readonly fields: readonly [{
                readonly fieldId: "leadId";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador único do lead (UUID).";
            }, {
                readonly fieldId: "fullName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome completo do lead/cliente.";
            }, {
                readonly fieldId: "email";
                readonly type: "string";
                readonly required: false;
                readonly description: "E-mail de contato do lead.";
            }, {
                readonly fieldId: "phone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone/WhatsApp de contato do lead.";
            }, {
                readonly fieldId: "stage";
                readonly type: "enum(novo,contato,visita,proposta,fechado,perdido)";
                readonly required: true;
                readonly description: "Etapa atual do lead no funil de vendas.";
            }, {
                readonly fieldId: "temperature";
                readonly type: "enum(quente,morno,frio)";
                readonly required: false;
                readonly description: "Classificação de temperatura do lead gerada pelo agente de IA.";
            }, {
                readonly fieldId: "temperatureJustification";
                readonly type: "string";
                readonly required: false;
                readonly description: "Justificativa da classificação de temperatura gerada pela IA.";
            }, {
                readonly fieldId: "followUpSuggestion";
                readonly type: "string";
                readonly required: false;
                readonly description: "Sugestão de mensagem de follow-up gerada pelo agente de IA.";
            }, {
                readonly fieldId: "notes";
                readonly type: "string";
                readonly required: false;
                readonly description: "Anotações livres sobre o lead, usadas como input para os agentes de IA.";
            }, {
                readonly fieldId: "interactionHistory";
                readonly type: "object[]";
                readonly required: false;
                readonly description: "Histórico de interações com o lead (data, tipo, descrição).";
            }, {
                readonly fieldId: "interestedPropertyIds";
                readonly type: "string[]";
                readonly required: false;
                readonly description: "IDs dos imóveis de interesse do lead.";
            }, {
                readonly fieldId: "assignedCorretorId";
                readonly type: "string";
                readonly required: true;
                readonly description: "ID do corretor responsável pelo lead.";
            }, {
                readonly fieldId: "source";
                readonly type: "string";
                readonly required: false;
                readonly description: "Origem do lead (ex: site, indicação, portal imobiliário).";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização.";
            }, {
                readonly fieldId: "createdBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "ID do usuário que criou o registro.";
            }];
        };
    };
    export default LeadMdm;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/Property.defs" {
    export const PropertyMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Property";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Property";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "manterPropertyFlowCrm";
            readonly domainId: "property";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Imóvel";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["rule-property-status-transition", "rule-rbac-data-isolation"];
            readonly title: "Imóvel";
            readonly description: "Entidade mestre central do domínio imobiliário. Representa um imóvel disponível para venda ou locação, com todos os seus atributos, características e fotos mock.";
            readonly fields: readonly [{
                readonly fieldId: "propertyId";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador único do imóvel (UUID).";
            }, {
                readonly fieldId: "title";
                readonly type: "string";
                readonly required: true;
                readonly description: "Título ou nome de referência do imóvel.";
            }, {
                readonly fieldId: "description";
                readonly type: "string";
                readonly required: false;
                readonly description: "Descrição profissional do imóvel, podendo ser gerada pelo agente de IA.";
            }, {
                readonly fieldId: "propertyType";
                readonly type: "enum(apartamento,casa,comercial,terreno,rural,outro)";
                readonly required: true;
                readonly description: "Tipo do imóvel.";
            }, {
                readonly fieldId: "transactionType";
                readonly type: "enum(venda,locacao,ambos)";
                readonly required: true;
                readonly description: "Tipo de transação: venda, locação ou ambos.";
            }, {
                readonly fieldId: "price";
                readonly type: "number";
                readonly required: true;
                readonly description: "Preço de venda ou valor de locação mensal em reais.";
            }, {
                readonly fieldId: "status";
                readonly type: "enum(disponivel,reservado,vendido,alugado,inativo)";
                readonly required: true;
                readonly description: "Status atual do imóvel no ciclo de vida.";
            }, {
                readonly fieldId: "addressStreet";
                readonly type: "string";
                readonly required: true;
                readonly description: "Logradouro do endereço do imóvel.";
            }, {
                readonly fieldId: "addressNumber";
                readonly type: "string";
                readonly required: true;
                readonly description: "Número do endereço.";
            }, {
                readonly fieldId: "addressComplement";
                readonly type: "string";
                readonly required: false;
                readonly description: "Complemento do endereço (apto, bloco etc.).";
            }, {
                readonly fieldId: "addressNeighborhood";
                readonly type: "string";
                readonly required: true;
                readonly description: "Bairro do imóvel.";
            }, {
                readonly fieldId: "addressCity";
                readonly type: "string";
                readonly required: true;
                readonly description: "Cidade do imóvel.";
            }, {
                readonly fieldId: "addressState";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado (UF) do imóvel.";
            }, {
                readonly fieldId: "addressZipCode";
                readonly type: "string";
                readonly required: false;
                readonly description: "CEP do imóvel.";
            }, {
                readonly fieldId: "areaM2";
                readonly type: "number";
                readonly required: false;
                readonly description: "Área total do imóvel em metros quadrados.";
            }, {
                readonly fieldId: "bedrooms";
                readonly type: "integer";
                readonly required: false;
                readonly description: "Número de quartos/dormitórios.";
            }, {
                readonly fieldId: "bathrooms";
                readonly type: "integer";
                readonly required: false;
                readonly description: "Número de banheiros.";
            }, {
                readonly fieldId: "parkingSpots";
                readonly type: "integer";
                readonly required: false;
                readonly description: "Número de vagas de garagem.";
            }, {
                readonly fieldId: "features";
                readonly type: "string[]";
                readonly required: false;
                readonly description: "Lista de características e diferenciais do imóvel (ex: piscina, churrasqueira, academia).";
            }, {
                readonly fieldId: "photoUrls";
                readonly type: "string[]";
                readonly required: false;
                readonly description: "Lista de URLs de fotos mock do imóvel (picsum.photos).";
            }, {
                readonly fieldId: "aiBullets";
                readonly type: "string";
                readonly required: false;
                readonly description: "Bullets/características em texto livre usados como input para o agente de geração de descrição IA.";
            }, {
                readonly fieldId: "assignedCorretorId";
                readonly type: "string";
                readonly required: false;
                readonly description: "ID do corretor responsável pelo imóvel.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização.";
            }, {
                readonly fieldId: "createdBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "ID do usuário que criou o registro.";
            }];
        };
    };
    export default PropertyMdm;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/activePropertiesMetric.defs" {
    export const activePropertiesMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "activePropertiesMetric";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "activePropertiesMetric";
                readonly tableName: "active_properties_metric";
                readonly title: "Imóveis Ativos";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly purpose: "Acompanhar a evolução da quantidade de imóveis por status ao longo do tempo, permitindo ao administrador visualizar o estoque de imóveis disponíveis, reservados, vendidos e alugados, identificando gargalos e oportunidades de reposição.";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Instante em que o snapshot da métrica foi registrado. Coluna de tempo do hypertable TimescaleDB.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do imóvel (dimensão). FK derivada da entidade Property (MDM).";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status atual do imóvel no momento do registro (disponivel, reservado, vendido, alugado, inativo).";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do corretor responsável pelo imóvel. FK derivada do relacionamento ontológico rel-property-corretor (Property → Corretor). Nullable pois o imóvel pode não ter corretor atribuído.";
                }, {
                    readonly name: "property_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Quantidade de imóveis representada por este registro. Medida principal agregada por SUM.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "uuid";
                    readonly description: "Identificador do imóvel";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "text";
                    readonly description: "Status atual do imóvel";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship rel-property-corretor (Property -> Corretor)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "propertyCount";
                    readonly column: "property_count";
                    readonly aggregation: "sum";
                    readonly unit: "imóveis";
                    readonly description: "Quantidade de imóveis agregada por SUM para os filtros de dimensão aplicados.";
                }];
                readonly sourceWriteEvents: readonly ["property.created", "property.status.updated", "propertyStatusTransitionEvent.created"];
                readonly rulesApplied: readonly ["rule-property-status-transition", "rule-rbac-data-isolation"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["propertyStatusWorkflow", "action-update-property-status", "action-create-deal", "action-advance-deal-stage", "action-mark-deal-lost"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "compress chunks older than 30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_apm_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Índice primário de tempo exigido pelo hypertable TimescaleDB. Suporta queries de range temporal para todos os widgets do Dashboard Operacional.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_apm_property_id_recorded_at";
                        readonly columns: readonly ["property_id", "recorded_at"];
                        readonly purpose: "Lookup de série temporal por imóvel específico. Usado para detalhar a evolução de status de um imóvel ao longo do tempo.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_apm_status_recorded_at";
                        readonly columns: readonly ["status", "recorded_at"];
                        readonly purpose: "Filtro por status do imóvel com range temporal. Suporta o widget de Imóveis Ativos no Dashboard (ex: contagem de 'disponivel' no último mês).";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_apm_corretor_id_recorded_at";
                        readonly columns: readonly ["corretor_id", "recorded_at"];
                        readonly purpose: "Filtro por corretor com range temporal. Suporta isolamento de dados por perfil (rule-rbac-data-isolation): Corretor visualiza apenas imóveis atribuídos a ele.";
                        readonly unique: false;
                    }];
                };
            };
            readonly defsPlan: {
                readonly fileName: "tables/activePropertiesMetric.defs.ts";
                readonly exportName: "activePropertiesMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default activePropertiesMetricTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/aiCommandLog.defs" {
    export const aiCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "aiCommandLog";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "aiCommandLog";
                readonly tableName: "ai_command_log";
                readonly title: "Log de Comandos de IA (LLM)";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly purpose: "Registra todas as invocações dos agentes LLM (geração de descrição de imóvel, classificação de lead e sugestão de follow-up), armazenando input, output, modelo utilizado, latência e status para rastreabilidade, auditoria e melhoria contínua.";
                readonly rootEntity: "PropertyDescriptionCommand";
                readonly primaryKey: readonly ["command_id"];
                readonly columns: readonly [{
                    readonly name: "command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do comando LLM (UUID). Chave primária da tabela.";
                }, {
                    readonly name: "command_type";
                    readonly type: "varchar(64)";
                    readonly nullable: false;
                    readonly description: "Discriminador do tipo de comando: 'property_description', 'lead_classification' ou 'followup_suggestion'.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(32)";
                    readonly nullable: false;
                    readonly default: "pending";
                    readonly description: "Status do processamento do comando: pending, completed, failed.";
                }, {
                    readonly name: "requested_by";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do usuário (UserAccount) que acionou o comando. Usado para RBAC e auditoria.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "ID do imóvel relacionado ao comando (preenchido para command_type = 'property_description'). Referência ao MDM de Imóvel.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "ID do lead relacionado ao comando (preenchido para command_type = 'lead_classification' ou 'followup_suggestion'). Referência ao MDM de Lead.";
                }, {
                    readonly name: "ai_model";
                    readonly type: "varchar(128)";
                    readonly nullable: true;
                    readonly description: "Identificador do modelo LLM utilizado na invocação (ex: gpt-4o, claude-3-sonnet).";
                }, {
                    readonly name: "latency_ms";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Latência da chamada ao agente LLM em milissegundos.";
                }, {
                    readonly name: "token_count_input";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Número de tokens consumidos no prompt de entrada.";
                }, {
                    readonly name: "token_count_output";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Número de tokens gerados na resposta do agente.";
                }, {
                    readonly name: "error_message";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Mensagem de erro em caso de status = 'failed'.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação/invocação do comando.";
                }, {
                    readonly name: "completed_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data e hora de conclusão do processamento do comando (completed ou failed).";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Dados internos do comando: prompt completo, resposta bruta do agente, bullets de input, resultado de classificação, justificativa, sugestão de follow-up, idioma alvo, contexto do lead, etc.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "AiCommandLogDetails";
                    readonly reason: "Prompt, resposta bruta, bullets de input, resultado de classificação, justificativa, sugestão de follow-up, idioma alvo e contexto do lead variam por command_type, têm estrutura heterogênea e não são usados em filtros/joins frequentes. Armazenar como JSONB evita fragmentação em múltiplas colunas esparsas e facilita análise de uso de IA.";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "requested_by";
                    readonly targetEntity: "UserAccount";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "Rastreabilidade e RBAC: identifica o usuário autenticado que acionou o agente LLM (rule-rbac-data-isolation, rule-llm-agent-invocation).";
                }, {
                    readonly fieldName: "property_id";
                    readonly targetEntity: "Property";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao imóvel para o qual a descrição foi gerada (command_type = property_description). Gerenciado pelo MDM de Imóvel.";
                }, {
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao lead classificado ou para o qual foi gerada sugestão de follow-up. Gerenciado pelo MDM de Lead.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_ai_command_log_command_type_status";
                    readonly columns: readonly ["command_type", "status"];
                    readonly unique: false;
                    readonly reason: "Suporta consultas de auditoria e dashboards que filtram logs por tipo de agente e status de processamento.";
                }, {
                    readonly indexName: "idx_ai_command_log_requested_by";
                    readonly columns: readonly ["requested_by"];
                    readonly unique: false;
                    readonly reason: "Suporta isolamento de dados por usuário (RBAC) e consultas de histórico de comandos por corretor/assistente.";
                }, {
                    readonly indexName: "idx_ai_command_log_lead_id";
                    readonly columns: readonly ["lead_id"];
                    readonly unique: false;
                    readonly reason: "Suporta lookup de todos os comandos LLM associados a um lead específico (tela Detalhe do Lead / Cliente e Pipeline de Leads).";
                }, {
                    readonly indexName: "idx_ai_command_log_property_id";
                    readonly columns: readonly ["property_id"];
                    readonly unique: false;
                    readonly reason: "Suporta lookup de todos os comandos de geração de descrição associados a um imóvel (tela Detalhe / Formulário de Imóvel).";
                }, {
                    readonly indexName: "idx_ai_command_log_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Suporta filtros por período para análise de uso de IA e melhoria contínua dos agentes.";
                }];
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/aiCommandLog.defs.ts";
                readonly exportName: "aiCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default aiCommandLogTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/dealPipelineMetric.defs" {
    export const dealPipelineMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dealPipelineMetric";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dealPipelineMetric";
                readonly tableName: "deal_pipeline_metric";
                readonly title: "Pipeline de Fechamentos";
                readonly moduleId: "propertyFlowCrm";
                readonly purpose: "Rastrear o volume e progresso de negócios no pipeline de vendas ao longo do tempo, permitindo previsão de receita, identificação de negócios parados e otimização do funil de fechamento.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do registro da métrica. Coluna de tempo principal do hypertable TimescaleDB.";
                }, {
                    readonly name: "deal_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do negócio (Deal). Dimensão FK derivada da relação ontológica Deal → Deal.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead vinculado ao negócio. Dimensão FK derivada da relação ontológica Deal → Lead (rel-deal-lead).";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel vinculado ao negócio. Dimensão FK derivada da relação ontológica Deal → Property (rel-deal-property).";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo negócio. Dimensão FK derivada da relação ontológica Deal → Corretor (rel-deal-corretor).";
                }, {
                    readonly name: "stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Etapa atual do negócio no funil de fechamento (proposta, negociacao, contrato, fechado, perdido).";
                }, {
                    readonly name: "deal_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de negócios registrados neste ponto temporal. Medida principal agregada por sum.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "dealId";
                    readonly column: "deal_id";
                    readonly type: "uuid";
                    readonly description: "Identificador do negócio";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "uuid";
                    readonly description: "Lead vinculado ao negócio — FK da relação ontológica Deal → Lead (rel-deal-lead)";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "uuid";
                    readonly description: "Imóvel vinculado ao negócio — FK da relação ontológica Deal → Property (rel-deal-property)";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pelo negócio — FK da relação ontológica Deal → Corretor (rel-deal-corretor)";
                }, {
                    readonly dimensionId: "stage";
                    readonly column: "stage";
                    readonly type: "text";
                    readonly description: "Etapa atual do negócio no funil de fechamento";
                }];
                readonly measures: readonly [{
                    readonly measureId: "dealCount";
                    readonly column: "deal_count";
                    readonly aggregation: "sum";
                    readonly unit: "negócios";
                    readonly description: "Quantidade de negócios registrados no ponto temporal";
                }];
                readonly sourceWriteEvents: readonly ["deal.created", "deal.stage.updated", "dealStageTransitionEvent.created"];
                readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-deal-requires-property-and-lead", "rule-rbac-data-isolation"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["dealStageWorkflow", "action-create-deal", "action-advance-deal-stage", "action-mark-deal-lost"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "compress chunks older than 30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_deal_pipeline_metric_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Índice primário de tempo exigido pelo hypertable TimescaleDB para particionamento e queries de range temporal.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metric_deal_id_recorded_at";
                        readonly columns: readonly ["deal_id", "recorded_at"];
                        readonly purpose: "Lookup de série temporal por negócio específico. Usado pelo Rastreador de Negócios e pelo dealStageWorkflow.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metric_corretor_id_recorded_at";
                        readonly columns: readonly ["corretor_id", "recorded_at"];
                        readonly purpose: "Filtro por corretor com range temporal para isolamento RBAC (rule-rbac-data-isolation) e Dashboard Operacional filtrado por corretorId.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metric_stage_recorded_at";
                        readonly columns: readonly ["stage", "recorded_at"];
                        readonly purpose: "Filtro por etapa do funil com range temporal para o widget de funil de negócios no Dashboard Operacional.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metric_lead_id_recorded_at";
                        readonly columns: readonly ["lead_id", "recorded_at"];
                        readonly purpose: "Lookup de métricas de pipeline associadas a um lead específico. Suporta LeadConversionMetric e tela Detalhe do Lead.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_deal_pipeline_metric_property_id_recorded_at";
                        readonly columns: readonly ["property_id", "recorded_at"];
                        readonly purpose: "Lookup de negócios associados a um imóvel específico ao longo do tempo. Suporta tela Detalhe do Imóvel e análise de giro de imóveis.";
                        readonly unique: false;
                    }];
                };
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealPipelineMetric.defs.ts";
                readonly exportName: "dealPipelineMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealPipelineMetricTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/dealStageTransitionEventLog.defs" {
    export const dealStageTransitionEventLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dealStageTransitionEventLog";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dealStageTransitionEventLog";
                readonly tableName: "deal_stage_transition_event_log";
                readonly title: "Log de Transições de Etapa do Negócio";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly purpose: "Registra cada avanço ou regressão de etapa de um negócio/proposta, mantendo histórico auditável das progressões e perdas para análise de pipeline e conformidade com regras de transição.";
                readonly rootEntity: "DealStageTransitionEvent";
                readonly primaryKey: readonly ["event_id"];
                readonly columns: readonly [{
                    readonly name: "event_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do evento de transição (UUID). Chave primária imutável.";
                }, {
                    readonly name: "deal_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do negócio (Deal) que sofreu a transição. Referência ao MDM de Negócio/Proposta.";
                }, {
                    readonly name: "from_stage";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Etapa de origem da transição (ex: proposta, negociacao, contrato).";
                }, {
                    readonly name: "to_stage";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Etapa de destino da transição (ex: negociacao, contrato, fechado, perdido).";
                }, {
                    readonly name: "performed_by";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do usuário (UserAccount) que realizou a transição. Suporta isolamento RBAC e auditoria.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora exata da transição. Usado para ordenação cronológica e filtros de período no Dashboard Operacional.";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Contexto complementar da transição: motivo de perda (lostReason), valor proposto (dealValue), observações (notes) e outros dados de apoio não usados em filtros frequentes.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "DealStageTransitionEventDetails";
                    readonly reason: "Campos como lostReason, dealValue e notes são contextuais, não são usados em filtros, joins ou lifecycle. Armazenados como JSONB para flexibilidade e extensibilidade sem migrações de schema.";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "deal_id";
                    readonly targetEntity: "Deal";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Cada evento pertence a um negócio gerenciado pelo MDM de Negócio/Proposta. Necessário para lookup de histórico por negócio no Rastreador de Negócios e no Workflow de Progressão.";
                }, {
                    readonly fieldName: "performed_by";
                    readonly targetEntity: "UserAccount";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "Rastreabilidade de quem executou a transição. Suporta rule-rbac-data-isolation e auditoria de conformidade.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_dste_deal_id_occurred_at";
                    readonly columns: readonly ["deal_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Lookup principal: buscar histórico cronológico de transições de um negócio específico. Usado pelo Rastreador de Negócios e pelo Workflow de Progressão de Etapas.";
                }, {
                    readonly indexName: "idx_dste_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por período para o Dashboard Operacional e análise de pipeline (ex: transições do mês corrente).";
                }, {
                    readonly indexName: "idx_dste_to_stage_occurred_at";
                    readonly columns: readonly ["to_stage", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Suporta queries de funil: quantos negócios chegaram a cada etapa em um período. Alimenta métricas de DealPipelineMetric e LeadConversionMetric.";
                }, {
                    readonly indexName: "idx_dste_performed_by";
                    readonly columns: readonly ["performed_by"];
                    readonly unique: false;
                    readonly reason: "Filtro por corretor para isolamento RBAC (rule-rbac-data-isolation): corretor visualiza apenas transições realizadas por ele.";
                }];
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["DealPipelineMetric", "LeadConversionMetric"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealStageTransitionEventLog.defs.ts";
                readonly exportName: "dealStageTransitionEventLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealStageTransitionEventLogTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/leadConversionMetric.defs" {
    export const leadConversionMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "leadConversionMetric";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "leadConversionMetric";
                readonly tableName: "lead_conversion_metric";
                readonly title: "Taxa de Conversão de Leads";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly purpose: "Medir a eficiência da conversão de leads entre as etapas do funil, permitindo análise de performance por corretor, par de etapas e janela temporal.";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do registro da métrica. Coluna de tempo do hypertable TimescaleDB.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do lead relacionado à transição de etapa.";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo lead no momento da transição.";
                }, {
                    readonly name: "from_stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Etapa de origem da transição (ex: novo, contato, visita, proposta).";
                }, {
                    readonly name: "to_stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Etapa de destino da transição (ex: contato, visita, proposta, fechado, perdido).";
                }, {
                    readonly name: "transition_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de transições de etapa registradas no período.";
                }, {
                    readonly name: "converted_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de leads convertidos (to_stage = fechado) no período.";
                }, {
                    readonly name: "lost_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de leads perdidos (to_stage = perdido) no período.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "uuid";
                    readonly description: "Identificador do lead. FK derivada da relação ontológica Lead → LeadStageTransitionEvent.";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pelo lead. FK derivada da relação ontológica Lead → Corretor (rel-lead-corretor).";
                }, {
                    readonly dimensionId: "fromStage";
                    readonly column: "from_stage";
                    readonly type: "text";
                    readonly description: "Etapa de origem da transição no funil de leads.";
                }, {
                    readonly dimensionId: "toStage";
                    readonly column: "to_stage";
                    readonly type: "text";
                    readonly description: "Etapa de destino da transição no funil de leads.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "transitionCount";
                    readonly column: "transition_count";
                    readonly aggregation: "sum";
                    readonly unit: "transições";
                    readonly description: "Total de transições de etapa registradas no período.";
                }, {
                    readonly measureId: "convertedCount";
                    readonly column: "converted_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Leads convertidos (fechados) no período.";
                }, {
                    readonly measureId: "lostCount";
                    readonly column: "lost_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Leads perdidos no período.";
                }];
                readonly sourceWriteEvents: readonly ["leadStageTransitionEvent.created"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["leadStageTransitionWorkflow"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "compress chunks older than 30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_lead_conversion_metric_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Índice primário de tempo exigido pelo hypertable TimescaleDB para particionamento e queries de range temporal.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_conversion_metric_corretor_id_recorded_at";
                        readonly columns: readonly ["corretor_id", "recorded_at"];
                        readonly purpose: "Suporta filtros por corretor com range temporal para isolamento RBAC (rule-rbac-data-isolation) e análise de performance individual.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_conversion_metric_lead_id_recorded_at";
                        readonly columns: readonly ["lead_id", "recorded_at"];
                        readonly purpose: "Suporta lookup de histórico de transições de um lead específico ao longo do tempo.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_lead_conversion_metric_from_to_stage_recorded_at";
                        readonly columns: readonly ["from_stage", "to_stage", "recorded_at"];
                        readonly purpose: "Suporta análise de funil por par de etapas (ex: proposta → fechado) em janelas temporais para o Dashboard Operacional.";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["rule-lead-stage-transition", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadConversionMetric.defs.ts";
                readonly exportName: "leadConversionMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadConversionMetricTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/leadStageTransitionEventLog.defs" {
    export const leadStageTransitionEventLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "leadStageTransitionEventLog";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "leadStageTransitionEventLog";
                readonly tableName: "lead_stage_transition_event_log";
                readonly title: "Log de Transições de Etapa do Lead";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly purpose: "Registra cada transição de etapa do lead no funil (Kanban) como log imutável de eventos, preservando o histórico completo de movimentações para auditoria, rastreabilidade e suporte às regras de transição válidas (rule-lead-stage-transition).";
                readonly rootEntity: "LeadStageTransitionEvent";
                readonly primaryKey: readonly ["event_id"];
                readonly columns: readonly [{
                    readonly name: "event_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do evento de transição (UUID). Chave primária imutável.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do lead (MDM) que sofreu a transição. Foreign ref para Lead MDM.";
                }, {
                    readonly name: "from_stage";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Etapa de origem da transição (ex: novo, contato, visita, proposta, fechado, perdido).";
                }, {
                    readonly name: "to_stage";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Etapa de destino da transição (ex: contato, visita, proposta, fechado, perdido).";
                }, {
                    readonly name: "performed_by";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do usuário (UserAccount horizontal) que realizou a transição. Suporta rule-rbac-data-isolation.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora exata da transição. Usado para ordenação cronológica do histórico e filtros de data no Dashboard Operacional.";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Metadados contextuais da transição: motivo (transitionReason), origem da ação (manual, workflow, agente IA), dados do agente (action-classify-lead-ai), e quaisquer campos adicionais não críticos para filtragem.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "LeadStageTransitionEventDetails";
                    readonly reason: "Armazena metadados contextuais da transição (motivo, origem da ação, dados do agente IA de action-classify-lead-ai) que não são necessários para filtragem, joins ou lifecycle, conforme recomendação detailsColumnRecommended=true do plano de persistência.";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "O evento de transição pertence a um Lead gerenciado pelo MDM. Necessário para joins no Pipeline Kanban, Detalhe do Lead e Workflow de Transição.";
                }, {
                    readonly fieldName: "performed_by";
                    readonly targetEntity: "UserAccount";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "Rastreabilidade de quem realizou a transição. Suporta rule-rbac-data-isolation e auditoria.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_lstel_lead_id_occurred_at";
                    readonly columns: readonly ["lead_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Lookup principal: busca do histórico cronológico de transições de um lead específico. Usado por Pipeline de Leads (Kanban), Detalhe do Lead e Workflow de Transição de Etapa.";
                }, {
                    readonly indexName: "idx_lstel_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por período no Dashboard Operacional e relatórios de auditoria. Suporta queries de range temporal.";
                }, {
                    readonly indexName: "idx_lstel_performed_by";
                    readonly columns: readonly ["performed_by"];
                    readonly unique: false;
                    readonly reason: "Filtro por corretor responsável para isolamento de dados (rule-rbac-data-isolation) e auditoria de ações por usuário.";
                }, {
                    readonly indexName: "idx_lstel_to_stage";
                    readonly columns: readonly ["to_stage"];
                    readonly unique: false;
                    readonly reason: "Filtro por etapa de destino para análise de funil e métricas de conversão no Dashboard Operacional.";
                }];
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["MonthlyLeadsMetric", "LeadConversionMetric"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly rulesApplied: readonly ["rule-lead-stage-transition", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadStageTransitionEventLog.defs.ts";
                readonly exportName: "leadStageTransitionEventLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadStageTransitionEventLogTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/monthlyLeadsMetric.defs" {
    export const monthlyLeadsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "monthlyLeadsMetric";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "monthlyLeadsMetric";
                readonly tableName: "monthly_leads_metric";
                readonly title: "Leads do Mês";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly purpose: "Monitorar a captação e distribuição de leads entre corretores ao longo do tempo, permitindo análise de volume por etapa do funil e por corretor responsável.";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do registro da métrica. Coluna de tempo principal do hypertable TimescaleDB.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do lead. Dimensão FK derivada da entidade Lead (MDM).";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo lead. Dimensão FK derivada do relacionamento ontológico rel-lead-corretor (Lead → Corretor).";
                }, {
                    readonly name: "stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Etapa atual do funil de leads (novo, contato, visita, proposta, fechado, perdido).";
                }, {
                    readonly name: "lead_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de leads registrados neste ponto temporal para a combinação de dimensões.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "uuid";
                    readonly description: "Identificador do lead";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pelo lead. FK do relacionamento ontológico rel-lead-corretor (Lead → Corretor).";
                }, {
                    readonly dimensionId: "stage";
                    readonly column: "stage";
                    readonly type: "text";
                    readonly description: "Etapa atual do funil de leads";
                }];
                readonly measures: readonly [{
                    readonly measureId: "leadCount";
                    readonly column: "lead_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Quantidade de leads";
                }];
                readonly sourceWriteEvents: readonly ["lead.created", "lead.stage.updated", "leadStageTransitionEvent.created"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["leadStageTransitionWorkflow", "action-create-lead", "action-move-lead-stage"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "compress chunks older than 30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_monthly_leads_metric_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Índice primário de tempo exigido pelo hypertable TimescaleDB. Suporta filtros por período (mês, semana, dia) no Dashboard Operacional.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_monthly_leads_metric_corretor_id_recorded_at";
                        readonly columns: readonly ["corretor_id", "recorded_at"];
                        readonly purpose: "Suporta isolamento de dados por corretor (rule-rbac-data-isolation) e consultas de volume de leads por corretor ao longo do tempo.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_monthly_leads_metric_lead_id_recorded_at";
                        readonly columns: readonly ["lead_id", "recorded_at"];
                        readonly purpose: "Suporta lookup de série temporal de um lead específico para rastreamento de histórico no Pipeline Kanban e Detalhe do Lead.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_monthly_leads_metric_stage_recorded_at";
                        readonly columns: readonly ["stage", "recorded_at"];
                        readonly purpose: "Suporta agregações por etapa do funil ao longo do tempo para o widget de Leads do Mês no Dashboard Operacional.";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["rule-lead-stage-transition", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/monthlyLeadsMetric.defs.ts";
                readonly exportName: "monthlyLeadsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default monthlyLeadsMetricTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/propertyStatusTransitionEventLog.defs" {
    export const propertyStatusTransitionEventLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "propertyStatusTransitionEventLog";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "propertyStatusTransitionEventLog";
                readonly tableName: "property_status_transition_event_log";
                readonly title: "Log de Transições de Status do Imóvel";
                readonly purpose: "Registra cada mudança de status de um imóvel (disponível → reservado → vendido/alugado/inativo), preservando histórico imutável para auditoria e suporte às regras de transição válidas (rule-property-status-transition).";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly rootEntity: "PropertyStatusTransitionEvent";
                readonly primaryKey: readonly ["event_id"];
                readonly columns: readonly [{
                    readonly name: "event_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do evento de transição (UUID). Chave primária imutável.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do imóvel (MDM) que sofreu a transição de status. Referência externa ao domínio MDM de Imóvel.";
                }, {
                    readonly name: "from_status";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Status de origem da transição. Enum: disponivel, reservado, vendido, alugado, inativo.";
                }, {
                    readonly name: "to_status";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Status de destino da transição. Enum: disponivel, reservado, vendido, alugado, inativo.";
                }, {
                    readonly name: "triggered_by";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Origem da transição: manual (Admin) ou automática via workflow (dealClosed, dealLost, dealCreated).";
                }, {
                    readonly name: "related_deal_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "ID do negócio (MDM) que originou a transição automática, quando aplicável.";
                }, {
                    readonly name: "performed_by";
                    readonly type: "varchar(255)";
                    readonly nullable: false;
                    readonly description: "ID do usuário (horizontal RBAC) ou identificador do sistema que realizou a transição.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora exata da transição de status. Usado para ordenação cronológica e filtros de auditoria.";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Contexto adicional da transição em JSON: observações, metadados do workflow, informações de rastreabilidade não usadas em filtros.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "PropertyStatusTransitionEventDetails";
                    readonly reason: "Armazena contexto interno da transição (observações do usuário, metadados do workflow, informações de rastreabilidade) que não são usados em filtros, joins ou lifecycle, conforme recomendação detailsColumnRecommended: true.";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "property_id";
                    readonly targetEntity: "Property";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao imóvel MDM cujo status foi alterado. Não implica criação de tabela neste módulo.";
                }, {
                    readonly fieldName: "related_deal_id";
                    readonly targetEntity: "Deal";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência opcional ao negócio MDM que originou a transição automática (dealClosed, dealLost, dealCreated).";
                }, {
                    readonly fieldName: "performed_by";
                    readonly targetEntity: "UserAccount";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "Referência ao usuário horizontal (RBAC) que executou a transição, para rastreabilidade e isolamento por perfil (rule-rbac-data-isolation).";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_pste_property_id_occurred_at";
                    readonly columns: readonly ["property_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Suporta consultas de histórico cronológico de transições por imóvel, usadas pelo Detalhe/Formulário de Imóvel e pelo Workflow de Atualização de Status.";
                }, {
                    readonly indexName: "idx_pste_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Suporta filtros por período no Dashboard Operacional e relatórios de auditoria.";
                }, {
                    readonly indexName: "idx_pste_to_status";
                    readonly columns: readonly ["to_status"];
                    readonly unique: false;
                    readonly reason: "Suporta consultas de imóveis que atingiram determinado status (ex: vendido, alugado) para métricas e lista de imóveis.";
                }, {
                    readonly indexName: "idx_pste_performed_by";
                    readonly columns: readonly ["performed_by"];
                    readonly unique: false;
                    readonly reason: "Suporta isolamento de dados por perfil (rule-rbac-data-isolation): filtragem de eventos realizados por um corretor específico.";
                }, {
                    readonly indexName: "idx_pste_related_deal_id";
                    readonly columns: readonly ["related_deal_id"];
                    readonly unique: false;
                    readonly reason: "Suporta lookup de transições originadas por um negócio específico, usado pelo workflow dealStageWorkflow e auditoria de negócios.";
                }];
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["ActivePropertiesMetric"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly rulesApplied: readonly ["rule-property-status-transition", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/propertyStatusTransitionEventLog.defs.ts";
                readonly exportName: "propertyStatusTransitionEventLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default propertyStatusTransitionEventLogTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/visitStatusTransitionEventLog.defs" {
    export const visitStatusTransitionEventLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "visitStatusTransitionEventLog";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 44;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "visitStatusTransitionEventLog";
                readonly tableName: "visit_status_transition_event_log";
                readonly title: "Log de Transições de Status da Visita";
                readonly moduleId: "propertyFlowCrm";
                readonly ownership: "moduleOwned";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly purpose: "Registra de forma imutável cada mudança de status de uma visita (agendada → confirmada → realizada / cancelada / reagendada), garantindo rastreabilidade completa do ciclo de vida e suporte à regra de não-conflito de horários. Alimenta a VisitsPerMonthMetric.";
                readonly rootEntity: "VisitStatusTransitionEvent";
                readonly primaryKey: readonly ["event_id"];
                readonly columns: readonly [{
                    readonly name: "event_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do evento de transição (UUID). Chave primária imutável.";
                }, {
                    readonly name: "visit_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID da visita (MDM) que sofreu a transição de status. FK para a entidade Visit gerenciada pelo MDM.";
                }, {
                    readonly name: "from_status";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Status de origem da transição (ex: agendada, confirmada, realizada, cancelada, reagendada).";
                }, {
                    readonly name: "to_status";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Status de destino da transição. Indexado para filtros por estado final.";
                }, {
                    readonly name: "performed_by";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do usuário (UserAccount horizontal) que realizou a transição. Suporta rule-rbac-data-isolation.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora exata da transição. Usado para ordenação cronológica e filtros de período (Dashboard Operacional, VisitsPerMonthMetric).";
                }, {
                    readonly name: "details";
                    readonly type: "jsonb";
                    readonly nullable: true;
                    readonly description: "Dados complementares do evento: motivo da transição (transitionReason), referência a evento de calendário externo (plugin futuro) e quaisquer metadados adicionais não filtráveis.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "VisitStatusTransitionEventDetails";
                    readonly reason: "transitionReason (motivo de cancelamento/reagendamento) e referência ao evento de calendário externo são dados complementares não utilizados em filtros, joins ou lifecycle direto. Armazenados como JSONB conforme recomendação da entidade e padrão eventLog.";
                };
                readonly foreignRefs: readonly [{
                    readonly fieldName: "visit_id";
                    readonly targetEntity: "Visit";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Toda transição pertence a uma visita gerenciada pelo MDM. Necessário para rastreabilidade e para o Workflow: Ciclo de Vida da Visita.";
                }, {
                    readonly fieldName: "performed_by";
                    readonly targetEntity: "UserAccount";
                    readonly targetOwnership: "horizontalOwned";
                    readonly reason: "Rastreabilidade de quem executou a transição; suporta rule-rbac-data-isolation e auditoria.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_vstel_visit_id";
                    readonly columns: readonly ["visit_id"];
                    readonly unique: false;
                    readonly reason: "Lookup principal: buscar todo o histórico de transições de uma visita específica (Agendador de Visitas, Workflow: Ciclo de Vida da Visita, action-update-visit-status).";
                }, {
                    readonly indexName: "idx_vstel_visit_id_occurred_at";
                    readonly columns: readonly ["visit_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação cronológica do log por visita; usado pelo Workflow para determinar o estado mais recente e validar rule-visit-no-conflict.";
                }, {
                    readonly indexName: "idx_vstel_to_status";
                    readonly columns: readonly ["to_status"];
                    readonly unique: false;
                    readonly reason: "Filtro por status de destino para agregações do Dashboard Operacional e cálculo da VisitsPerMonthMetric.";
                }, {
                    readonly indexName: "idx_vstel_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por período (mês/semana) para o Dashboard Operacional e alimentação da VisitsPerMonthMetric.";
                }, {
                    readonly indexName: "idx_vstel_performed_by";
                    readonly columns: readonly ["performed_by"];
                    readonly unique: false;
                    readonly reason: "Suporte a rule-rbac-data-isolation: filtrar eventos realizados por um corretor específico.";
                }];
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["VisitsPerMonthMetric"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly rulesApplied: readonly ["rule-visit-no-conflict", "rule-visit-requires-property-lead-corretor", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitStatusTransitionEventLog.defs.ts";
                readonly exportName: "visitStatusTransitionEventLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitStatusTransitionEventLogTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_1_external/visitsPerMonthMetric.defs" {
    export const visitsPerMonthMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "visitsPerMonthMetric";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "visitsPerMonthMetric";
                readonly tableName: "visits_per_month_metric";
                readonly title: "Visitas Realizadas no Mês";
                readonly moduleId: "propertyFlowCrm";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly purpose: "Acompanhar o agendamento, conclusão e cancelamento de visitas ao longo do tempo, permitindo avaliar a produtividade dos corretores e o engajamento dos leads por imóvel.";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do registro da métrica. Coluna de tempo do hypertable TimescaleDB.";
                }, {
                    readonly name: "visit_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da visita. Dimensão FK derivada da entidade Visit.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel visitado. Dimensão FK derivada do relacionamento rel-visit-property (Visit → Property).";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead que agendou a visita. Dimensão FK derivada do relacionamento rel-visit-lead (Visit → Lead).";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pela visita. Dimensão FK derivada do relacionamento rel-visit-corretor (Visit → Corretor).";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status atual da visita no momento do registro (agendada, confirmada, realizada, cancelada, reagendada).";
                }, {
                    readonly name: "visit_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de visitas contabilizadas neste registro. Medida agregável via SUM.";
                }, {
                    readonly name: "completed_visit_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Visitas realizadas com sucesso (status = realizada). Medida agregável via SUM.";
                }, {
                    readonly name: "cancelled_visit_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Visitas canceladas (status = cancelada). Medida agregável via SUM.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "visitId";
                    readonly column: "visit_id";
                    readonly type: "uuid";
                    readonly description: "Identificador da visita";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "uuid";
                    readonly description: "Imóvel visitado. FK do relacionamento rel-visit-property (Visit → Property).";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "uuid";
                    readonly description: "Lead que agendou a visita. FK do relacionamento rel-visit-lead (Visit → Lead).";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pela visita. FK do relacionamento rel-visit-corretor (Visit → Corretor).";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "text";
                    readonly description: "Status atual da visita";
                }];
                readonly measures: readonly [{
                    readonly measureId: "visitCount";
                    readonly column: "visit_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Total de visitas";
                }, {
                    readonly measureId: "completedVisitCount";
                    readonly column: "completed_visit_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Visitas realizadas com sucesso";
                }, {
                    readonly measureId: "cancelledVisitCount";
                    readonly column: "cancelled_visit_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Visitas canceladas";
                }];
                readonly sourceWriteEvents: readonly ["visit.created", "visit.status.updated", "visitStatusTransitionEvent.created"];
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["visitLifecycleWorkflow", "action-schedule-visit", "action-update-visit-status"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "compress chunks older than 30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_visits_per_month_metric_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Índice primário de tempo exigido pelo hypertable TimescaleDB. Suporta filtros por período (dia, semana, mês) no Dashboard Operacional.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visits_per_month_metric_corretor_id_recorded_at";
                        readonly columns: readonly ["corretor_id", "recorded_at"];
                        readonly purpose: "Filtro por corretor + período para isolamento RBAC (rule-rbac-data-isolation) e análise de produtividade individual.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visits_per_month_metric_property_id_recorded_at";
                        readonly columns: readonly ["property_id", "recorded_at"];
                        readonly purpose: "Filtro por imóvel + período para análise de demanda por propriedade.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visits_per_month_metric_lead_id_recorded_at";
                        readonly columns: readonly ["lead_id", "recorded_at"];
                        readonly purpose: "Filtro por lead + período para análise de engajamento do lead ao longo do tempo.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visits_per_month_metric_visit_id";
                        readonly columns: readonly ["visit_id"];
                        readonly purpose: "Lookup direto por visita para upserts e deduplicação de registros de métrica.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_visits_per_month_metric_status_recorded_at";
                        readonly columns: readonly ["status", "recorded_at"];
                        readonly purpose: "Filtro por status + período para agregações de visitas realizadas vs. canceladas no Dashboard Operacional.";
                        readonly unique: false;
                    }];
                };
                readonly rulesApplied: readonly ["rule-visit-no-conflict", "rule-visit-requires-property-lead-corretor", "rule-rbac-data-isolation"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitsPerMonthMetric.defs.ts";
                readonly exportName: "visitsPerMonthMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitsPerMonthMetricTableDefinition;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/advanceDealStageUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "advanceDealStageUsecase";
        readonly title: "Avançar / Regredir Etapa do Negócio";
        readonly purpose: "Valida e executa a transição de etapa de um negócio/proposta, registra o evento de transição e atualiza a métrica de pipeline de fechamentos.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["transitionEventLogEntity"];
        readonly outputEntities: readonly ["transitionEventLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "deal_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_pipeline_metric";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-deal-requires-property-and-lead", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "advanceDealStage";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "fromStage";
                readonly type: "DealStageEnum";
                readonly required: true;
            }, {
                readonly name: "toStage";
                readonly type: "DealStageEnum";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "eventId";
                readonly type: "string";
            }, {
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "newStage";
                readonly type: "DealStageEnum";
            }, {
                readonly name: "transitionedAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "markDealLost";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "lostReason";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "eventId";
                readonly type: "string";
            }, {
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "newStage";
                readonly type: "DealStageEnum";
            }, {
                readonly name: "transitionedAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "createDeal";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "proposedValue";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }, {
                readonly name: "stage";
                readonly type: "DealStageEnum";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/classifyLeadAiUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "classifyLeadAiUsecase";
        readonly title: "Classificar Lead com IA (Quente/Morno/Frio)";
        readonly purpose: "Invoca o agente LLM de classificação de lead, registra o comando no log de IA, persiste a classificação no lead e retorna o resultado ao corretor.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["aiCommandLogEntity"];
        readonly outputEntities: readonly ["aiCommandLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "classifyLeadAi";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "commandLogId";
                readonly type: "string";
            }, {
                readonly name: "classification";
                readonly type: "LeadTemperatureEnum";
            }, {
                readonly name: "justification";
                readonly type: "string";
            }, {
                readonly name: "classifiedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["aiCommandLogEntity", "transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/generatePropertyDescriptionUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "generatePropertyDescriptionUsecase";
        readonly title: "Gerar Descrição de Imóvel com IA";
        readonly purpose: "Invoca o agente LLM de geração de descrição de imóvel, registra o comando no log de IA e retorna o texto gerado para o corretor revisar antes de salvar.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["aiCommandLogEntity"];
        readonly outputEntities: readonly ["aiCommandLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_command_log";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "generatePropertyDescription";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "tone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "language";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "commandLogId";
                readonly type: "string";
            }, {
                readonly name: "generatedDescription";
                readonly type: "string";
            }, {
                readonly name: "generatedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["aiCommandLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/getFollowUpSuggestionUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "getFollowUpSuggestionUsecase";
        readonly title: "Obter Sugestão de Mensagem de Follow-up com IA";
        readonly purpose: "Invoca o agente LLM de sugestão de follow-up com base no histórico do lead, registra o comando no log de IA e retorna a mensagem sugerida.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["aiCommandLogEntity"];
        readonly outputEntities: readonly ["aiCommandLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_command_log";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "getFollowUpSuggestion";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "channel";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "commandLogId";
                readonly type: "string";
            }, {
                readonly name: "suggestedMessage";
                readonly type: "string";
            }, {
                readonly name: "generatedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["aiCommandLogEntity", "transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/manageCorretorUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "manageCorretorUsecase";
        readonly title: "Gerenciar Corretores (Admin)";
        readonly purpose: "Permite ao Admin criar, editar e ativar/inativar corretores na plataforma, aplicando RBAC.";
        readonly actor: "adminActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "createCorretor";
            readonly input: readonly [{
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "creci";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "corretorId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "CorretorStatusEnum";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "editCorretor";
            readonly input: readonly [{
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "status";
                readonly type: "CorretorStatusEnum";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "corretorId";
                readonly type: "string";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/manageLeadUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "manageLeadUsecase";
        readonly title: "Gerenciar Lead / Cliente (CRUD)";
        readonly purpose: "Cria e edita leads/clientes, aplicando isolamento de dados por perfil. Atualiza a métrica de leads do mês ao criar um novo lead.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "monthly_leads_metric";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "createLead";
            readonly input: readonly [{
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "source";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }, {
                readonly name: "stage";
                readonly type: "LeadStageEnum";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "editLead";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/moveLeadStageUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "moveLeadStageUsecase";
        readonly title: "Mover Lead no Funil (Transição de Etapa)";
        readonly purpose: "Valida e executa a transição de etapa de um lead no pipeline (Kanban), registra o evento de transição e atualiza as métricas de leads do mês e taxa de conversão.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["transitionEventLogEntity"];
        readonly outputEntities: readonly ["transitionEventLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "monthly_leads_metric";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_conversion_metric";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-lead-stage-transition", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "moveLeadStage";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "fromStage";
                readonly type: "LeadStageEnum";
                readonly required: true;
            }, {
                readonly name: "toStage";
                readonly type: "LeadStageEnum";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "eventId";
                readonly type: "string";
            }, {
                readonly name: "leadId";
                readonly type: "string";
            }, {
                readonly name: "newStage";
                readonly type: "LeadStageEnum";
            }, {
                readonly name: "transitionedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/queryDashboardMetricsUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "queryDashboardMetricsUsecase";
        readonly title: "Consultar Métricas do Dashboard Operacional";
        readonly purpose: "Agrega e retorna as métricas operacionais (imóveis ativos, leads do mês, pipeline de fechamentos, taxa de conversão, visitas realizadas) para o Dashboard do Admin.";
        readonly actor: "adminActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "active_properties_metric";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "monthly_leads_metric";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_pipeline_metric";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_conversion_metric";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visits_per_month_metric";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "getDashboardMetrics";
            readonly input: readonly [{
                readonly name: "periodStart";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "periodEnd";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "activeProperties";
                readonly type: "number";
            }, {
                readonly name: "monthlyLeads";
                readonly type: "number";
            }, {
                readonly name: "dealPipelineValue";
                readonly type: "number";
            }, {
                readonly name: "leadConversionRate";
                readonly type: "number";
            }, {
                readonly name: "visitsPerMonth";
                readonly type: "number";
            }, {
                readonly name: "generatedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/updatePropertyStatusUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "updatePropertyStatusUsecase";
        readonly title: "Atualizar Status do Imóvel";
        readonly purpose: "Valida e executa a transição de status de um imóvel (disponivel → reservado → vendido/alugado/inativo), registra o evento de transição e atualiza a métrica de imóveis ativos.";
        readonly actor: "adminActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["transitionEventLogEntity"];
        readonly outputEntities: readonly ["transitionEventLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property_status_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "property_status_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "active_properties_metric";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-property-status-transition", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "createProperty";
            readonly input: readonly [{
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "type";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "address";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "area";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "bedrooms";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "bathrooms";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "imageUrl";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "PropertyStatusEnum";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "editProperty";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "imageUrl";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "updatePropertyStatus";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "fromStatus";
                readonly type: "PropertyStatusEnum";
                readonly required: true;
            }, {
                readonly name: "toStatus";
                readonly type: "PropertyStatusEnum";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "eventId";
                readonly type: "string";
            }, {
                readonly name: "propertyId";
                readonly type: "string";
            }, {
                readonly name: "newStatus";
                readonly type: "PropertyStatusEnum";
            }, {
                readonly name: "transitionedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_3_usecases/updateVisitStatusUsecase.defs" {
    export const useCase: {
        readonly usecaseId: "updateVisitStatusUsecase";
        readonly title: "Atualizar Status da Visita";
        readonly purpose: "Valida e executa a transição de status de uma visita (agendada → confirmada → realizada / cancelada / reagendada), verifica conflito de horário, registra o evento e atualiza a métrica de visitas do mês.";
        readonly actor: "corretorActor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["transitionEventLogEntity"];
        readonly outputEntities: readonly ["transitionEventLogEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit_status_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visit_status_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visits_per_month_metric";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["rule-visit-no-conflict", "rule-visit-requires-property-lead-corretor", "rule-rbac-data-isolation"];
        readonly commands: readonly [{
            readonly commandId: "scheduleVisit";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "scheduledAt";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "VisitStatusEnum";
            }, {
                readonly name: "scheduledAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "updateVisitStatus";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "fromStatus";
                readonly type: "VisitStatusEnum";
                readonly required: true;
            }, {
                readonly name: "toStatus";
                readonly type: "VisitStatusEnum";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "corretorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "eventId";
                readonly type: "string";
            }, {
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "newStatus";
                readonly type: "VisitStatusEnum";
            }, {
                readonly name: "transitionedAt";
                readonly type: "date";
            }];
        }];
        readonly entityRefs: readonly ["transitionEventLogEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_4_entities/aiCommandLogEntity.defs" {
    export const entity: {
        readonly entityId: "aiCommandLogEntity";
        readonly title: "Entidade: Log de Comandos de IA";
        readonly purpose: "Registra todas as invocações de agentes LLM (geração de descrição de imóvel, classificação de lead, sugestão de follow-up), armazenando input, output e metadados de execução.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "ai_command_log";
            readonly ownership: "moduleOwned";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly ["rule-llm-agent-invocation"];
        readonly usecaseRefs: readonly ["generatePropertyDescriptionUsecase", "classifyLeadAiUsecase", "getFollowUpSuggestionUsecase"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/AiCommandLogEntity.ts";
            readonly className: "AiCommandLogEntity";
            readonly contractName: "IAiCommandLogEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/manterPropertyFlowCrm/layer_4_entities/transitionEventLogEntity.defs" {
    export const entity: {
        readonly entityId: "transitionEventLogEntity";
        readonly title: "Entidade: Logs de Transição de Etapa/Status";
        readonly purpose: "Agrupa os quatro logs de eventos de transição (Lead, Deal, Visit, Property) que registram cada mudança de estado com timestamp, ator e motivo. Serve como fonte para métricas e auditoria.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "lead_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_stage_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_status_transition_event_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property_status_transition_event_log";
            readonly ownership: "moduleOwned";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly ["rule-lead-stage-transition", "rule-deal-stage-transition", "rule-property-status-transition", "rule-visit-no-conflict"];
        readonly usecaseRefs: readonly ["moveLeadStageUsecase", "advanceDealStageUsecase", "updateVisitStatusUsecase", "updatePropertyStatusUsecase", "classifyLeadAiUsecase", "getFollowUpSuggestionUsecase", "queryDashboardMetricsUsecase"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/TransitionEventLogEntity.ts";
            readonly className: "TransitionEventLogEntity";
            readonly contractName: "ITransitionEventLogEntity";
        };
    };
    export default entity;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102045_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102045_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102045_/l2/manterPropertyFlowCrm/dealDetailPage.defs" {
    export const dealDetailPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealDetailPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealDetailPage";
                readonly pageName: "Detalhe do Negócio";
                readonly actor: "corretorActor";
                readonly purpose: "Visualização completa do negócio: imóvel e lead vinculados, histórico de etapas, valor da proposta e ações de progressão ou encerramento.";
                readonly capabilities: readonly ["trackDeals", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealStageProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador único do negócio a ser exibido.";
                    readonly entityRef: "Deal";
                    readonly fieldRef: "dealId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dealTrackerPage";
                    readonly trigger: "Clique no card do negócio";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyListPage";
                    readonly trigger: "Clique no imóvel vinculado";
                    readonly description: "Navega para a lista de imóveis ao clicar no imóvel vinculado ao negócio";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadDetailPage";
                    readonly trigger: "Clique no lead vinculado";
                    readonly description: "Navega para o detalhe do lead ao clicar no lead vinculado ao negócio";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Negócio";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "DealHeaderCard";
                        readonly purpose: "Exibir informações principais do negócio: etapa atual, valor da proposta, tipo de negócio, datas de criação e atualização, e corretor responsável.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Deal", "Corretor"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.stage", "Deal.proposedValue", "Deal.dealType", "Deal.createdAt", "Deal.updatedAt", "Deal.closedAt", "Corretor.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Imóvel e Lead Vinculados";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "LinkedPropertyCard";
                        readonly purpose: "Exibir resumo do imóvel vinculado ao negócio com link de navegação para a lista de imóveis.";
                        readonly userActions: readonly ["Clique no imóvel vinculado"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.status", "Property.price", "Property.type"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "LinkedLeadCard";
                        readonly purpose: "Exibir resumo do lead vinculado ao negócio com link de navegação para o detalhe do lead.";
                        readonly userActions: readonly ["Clique no lead vinculado"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone", "Lead.stage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Histórico de Etapas";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "DealStageHistoryTimeline";
                        readonly purpose: "Exibir linha do tempo cronológica de todas as transições de etapa do negócio, incluindo etapa de origem, destino, responsável, data/hora e observações.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["DealStageTransitionEvent"];
                        readonly readsFields: readonly ["DealStageTransitionEvent.eventId", "DealStageTransitionEvent.fromStage", "DealStageTransitionEvent.toStage", "DealStageTransitionEvent.performedBy", "DealStageTransitionEvent.occurredAt", "DealStageTransitionEvent.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-deal-stage-transition"];
                    }];
                }, {
                    readonly sectionName: "Ações de Progressão";
                    readonly mode: "write";
                    readonly organisms: readonly [{
                        readonly organismName: "AdvanceDealStagePanel";
                        readonly purpose: "Permitir ao corretor avançar a etapa do negócio para a próxima etapa válida conforme as regras de transição. Exibe apenas a ação disponível para a etapa atual e bloqueia ações em estados terminais.";
                        readonly userActions: readonly ["Avançar etapa"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.stage", "Deal.dealId"];
                        readonly writesFields: readonly ["Deal.stage", "Deal.updatedAt"];
                        readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "MarkDealLostPanel";
                        readonly purpose: "Permitir ao corretor marcar o negócio como perdido informando obrigatoriamente o motivo. Disponível em qualquer etapa ativa (proposta, negociação, contrato). Bloqueado em estados terminais.";
                        readonly userActions: readonly ["Marcar como perdido"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["Deal.stage", "Deal.dealId"];
                        readonly writesFields: readonly ["Deal.stage", "Deal.lostReason", "Deal.updatedAt"];
                        readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getDealDetails";
                readonly purpose: "Buscar detalhes completos do negócio incluindo dados do deal, imóvel vinculado, lead vinculado e histórico cronológico de transições de etapa.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "proposedValue";
                    readonly type: "number";
                }, {
                    readonly name: "dealType";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }, {
                    readonly name: "closedAt";
                    readonly type: "date";
                }, {
                    readonly name: "lostReason";
                    readonly type: "string";
                }, {
                    readonly name: "corretorId";
                    readonly type: "string";
                }, {
                    readonly name: "corretorName";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "propertyTitle";
                    readonly type: "string";
                }, {
                    readonly name: "propertyAddress";
                    readonly type: "string";
                }, {
                    readonly name: "propertyStatus";
                    readonly type: "string";
                }, {
                    readonly name: "propertyPrice";
                    readonly type: "number";
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "leadEmail";
                    readonly type: "string";
                }, {
                    readonly name: "leadPhone";
                    readonly type: "string";
                }, {
                    readonly name: "leadStage";
                    readonly type: "string";
                }, {
                    readonly name: "stageHistory";
                    readonly type: "DealStageTransitionEvent[]";
                }];
                readonly readsEntities: readonly ["Deal", "DealStageTransitionEvent", "Property", "Lead", "Corretor"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal_stage_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "advanceDealStage";
                readonly purpose: "Avançar a etapa do negócio para a próxima etapa válida conforme as regras de transição, registrando o evento de transição e atualizando métricas de pipeline.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fromStage";
                    readonly type: "DealStageEnum";
                    readonly required: true;
                }, {
                    readonly name: "toStage";
                    readonly type: "DealStageEnum";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "dealId";
                    readonly type: "string";
                }, {
                    readonly name: "newStage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly ["Deal", "DealStageTransitionEvent"];
                readonly readsTables: readonly ["deal_stage_transition_event_log"];
                readonly writesTables: readonly ["deal_stage_transition_event_log"];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
            }, {
                readonly commandName: "markDealLost";
                readonly purpose: "Marcar o negócio como perdido informando o motivo obrigatório, registrando o evento de transição, sincronizando o status do imóvel para disponível e o lead para perdido.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "lostReason";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "dealId";
                    readonly type: "string";
                }, {
                    readonly name: "newStage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly ["Deal", "DealStageTransitionEvent", "Property", "Lead"];
                readonly readsTables: readonly ["deal_stage_transition_event_log"];
                readonly writesTables: readonly ["deal_stage_transition_event_log"];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default dealDetailPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/dealFormPage.defs" {
    export const dealFormPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealFormPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealFormPage";
                readonly pageName: "Formulário de Negócio";
                readonly actor: "corretorActor";
                readonly purpose: "Criação de novo negócio/proposta vinculando obrigatoriamente um imóvel e um lead, com valor da proposta e etapa inicial (proposta). Garante que ambos os vínculos obrigatórios estejam preenchidos antes de confirmar.";
                readonly capabilities: readonly ["trackDeals", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealStageProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "Lead pré-selecionado quando a página é aberta a partir do detalhe do lead.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "Imóvel pré-selecionado quando a página é aberta a partir do detalhe do imóvel.";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dealTrackerPage";
                    readonly trigger: "Clique em 'Novo Negócio'";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetailPage";
                    readonly trigger: "Clique em 'Criar Negócio'";
                    readonly description: "Abre o formulário com leadId pré-selecionado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealTrackerPage";
                    readonly trigger: "Salvar negócio com sucesso ou cancelar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertySelectorOrganism";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o imóvel a ser vinculado ao negócio. Pré-popula com propertyId recebido via pageInput quando disponível.";
                        readonly userActions: readonly ["Buscar imóvel por endereço ou código", "Selecionar imóvel da lista"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["propertyId", "address", "type", "status", "price"];
                        readonly writesFields: readonly ["propertyId"];
                        readonly rulesApplied: readonly ["rule-deal-requires-property-and-lead", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Seleção de Lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSelectorOrganism";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o lead/cliente a ser vinculado ao negócio. Pré-popula com leadId recebido via pageInput quando disponível.";
                        readonly userActions: readonly ["Buscar lead por nome ou e-mail", "Selecionar lead da lista"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "name", "email", "phone", "stage"];
                        readonly writesFields: readonly ["leadId"];
                        readonly rulesApplied: readonly ["rule-deal-requires-property-and-lead", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Dados da Proposta";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "DealProposalFormOrganism";
                        readonly purpose: "Capturar o valor da proposta, tipo de negócio (venda/aluguel) e observações iniciais. Etapa inicial é sempre 'proposta' e não editável pelo usuário.";
                        readonly userActions: readonly ["Informar valor da proposta", "Selecionar tipo de negócio (venda/aluguel)", "Adicionar observações opcionais"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["proposedValue", "dealType", "notes", "initialStage"];
                        readonly rulesApplied: readonly ["rule-deal-stage-transition"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de Criação";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "DealCreationConfirmOrganism";
                        readonly purpose: "Resumo dos dados selecionados (imóvel, lead, valor, tipo) e botão de confirmação para criar o negócio. Bloqueia envio se propertyId ou leadId estiverem ausentes.";
                        readonly userActions: readonly ["Confirmar criação do negócio", "Cancelar e voltar ao Rastreador de Negócios"];
                        readonly requiredEntities: readonly ["Deal", "Property", "Lead"];
                        readonly readsFields: readonly ["propertyId", "leadId", "proposedValue", "dealType", "notes"];
                        readonly writesFields: readonly ["dealId", "stage", "createdAt"];
                        readonly rulesApplied: readonly ["rule-deal-requires-property-and-lead", "rule-rbac-data-isolation", "rule-deal-stage-transition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listPropertiesForSelection";
                readonly purpose: "Buscar imóveis disponíveis para seleção no formulário de negócio, filtrando por termo de busca (endereço, código). Respeita isolamento RBAC do corretor autenticado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "listLeadsForSelection";
                readonly purpose: "Buscar leads disponíveis para seleção no formulário de negócio, filtrando por nome ou e-mail. Respeita isolamento RBAC do corretor autenticado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "createDeal";
                readonly purpose: "Criar novo negócio/proposta vinculando obrigatoriamente um imóvel e um lead, com valor da proposta e etapa inicial 'proposta'. Registra o evento de transição inicial e atualiza a métrica de pipeline.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "proposedValue";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "dealType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property", "Lead", "Corretor"];
                readonly writesEntities: readonly ["Deal", "DealStageTransitionEvent"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["deal_stage_transition_event_log"];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-deal-requires-property-and-lead", "rule-deal-stage-transition", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default dealFormPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/dealTrackerPage.defs" {
    export const dealTrackerPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealTrackerPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealTrackerPage";
                readonly pageName: "Rastreador de Negócios";
                readonly actor: "corretorActor";
                readonly purpose: "Visualização e gestão do pipeline de negócios/propostas por etapas (Proposta → Negociação → Contrato → Fechado/Perdido). Permite ao corretor visualizar seus negócios agrupados por etapa, avançar etapas, marcar como perdido e criar novos negócios.";
                readonly capabilities: readonly ["trackDeals", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealStageProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dealFormPage";
                    readonly trigger: "Clique em 'Novo Negócio'";
                    readonly description: "Navega para o formulário de criação de novo negócio/proposta";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealDetailPage";
                    readonly trigger: "Clique no card do negócio";
                    readonly description: "Navega para o detalhe completo do negócio selecionado";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "operationalDashboardPage";
                    readonly trigger: "Clique em card de negócios no dashboard";
                    readonly description: "Entrada a partir do Dashboard Operacional";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Barra de Ações e Filtros";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "DealTrackerToolbar";
                        readonly purpose: "Exibir botão 'Novo Negócio' e controles de filtro (por etapa, período, imóvel, lead) para o pipeline do corretor autenticado.";
                        readonly userActions: readonly ["Clicar em 'Novo Negócio' para navegar ao dealFormPage", "Aplicar filtros de etapa, período e entidades vinculadas"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Pipeline Kanban por Etapas";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "DealKanbanBoard";
                        readonly purpose: "Renderizar colunas Kanban para cada etapa do funil (Proposta, Negociação, Contrato, Fechado, Perdido) com os cards dos negócios do corretor autenticado, exibindo imóvel vinculado, lead vinculado, valor da proposta e etapa atual.";
                        readonly userActions: readonly ["Visualizar negócios agrupados por etapa", "Clicar no card do negócio para navegar ao dealDetailPage"];
                        readonly requiredEntities: readonly ["Deal", "DealStageTransitionEvent"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.stage", "Deal.proposedValue", "Deal.dealType", "Deal.createdAt", "Deal.updatedAt", "Deal.propertyId", "Deal.leadId", "Deal.corretorId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-deal-stage-transition"];
                    }];
                }, {
                    readonly sectionName: "Ações Inline de Etapa";
                    readonly mode: "write";
                    readonly organisms: readonly [{
                        readonly organismName: "DealStageAdvanceAction";
                        readonly purpose: "Permitir ao corretor avançar a etapa do negócio diretamente no card Kanban, respeitando as transições válidas definidas pelo lifecycle dealStageProgression.";
                        readonly userActions: readonly ["Avançar etapa do negócio (proposta → negociação → contrato → fechado)", "Confirmar avanço de etapa com observação opcional"];
                        readonly requiredEntities: readonly ["Deal", "DealStageTransitionEvent"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.stage", "Deal.corretorId"];
                        readonly writesFields: readonly ["Deal.stage", "Deal.updatedAt", "DealStageTransitionEvent.fromStage", "DealStageTransitionEvent.toStage", "DealStageTransitionEvent.performedBy", "DealStageTransitionEvent.occurredAt", "DealStageTransitionEvent.notes"];
                        readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "DealMarkLostAction";
                        readonly purpose: "Permitir ao corretor marcar um negócio como perdido a partir de qualquer etapa ativa, exigindo preenchimento do motivo de perda.";
                        readonly userActions: readonly ["Marcar negócio como perdido", "Informar motivo de perda (lostReason) obrigatório", "Confirmar encerramento do negócio"];
                        readonly requiredEntities: readonly ["Deal", "DealStageTransitionEvent"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.stage", "Deal.corretorId"];
                        readonly writesFields: readonly ["Deal.stage", "Deal.lostReason", "Deal.updatedAt", "DealStageTransitionEvent.fromStage", "DealStageTransitionEvent.toStage", "DealStageTransitionEvent.performedBy", "DealStageTransitionEvent.occurredAt", "DealStageTransitionEvent.details"];
                        readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listDealsByStage";
                readonly purpose: "Buscar todos os negócios do corretor autenticado agrupados por etapa do funil, aplicando isolamento RBAC e filtros opcionais, para renderizar o Kanban do Rastreador de Negócios.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stageFilter";
                    readonly type: "DealStageEnum";
                    readonly required: false;
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "fromDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "toDate";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "stage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "deals";
                    readonly type: "Deal[]";
                }, {
                    readonly name: "totalByStage";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Deal", "DealStageTransitionEvent"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal_stage_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "advanceDealStage";
                readonly purpose: "Avançar ou regredir a etapa de um negócio respeitando as transições válidas do lifecycle dealStageProgression, registrando o evento de transição e atualizando métricas de pipeline.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fromStage";
                    readonly type: "DealStageEnum";
                    readonly required: true;
                }, {
                    readonly name: "toStage";
                    readonly type: "DealStageEnum";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "dealId";
                    readonly type: "string";
                }, {
                    readonly name: "newStage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly ["Deal", "DealStageTransitionEvent"];
                readonly readsTables: readonly ["deal_stage_transition_event_log"];
                readonly writesTables: readonly ["deal_stage_transition_event_log"];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
            }, {
                readonly commandName: "markDealLost";
                readonly purpose: "Marcar um negócio como perdido a partir de qualquer etapa ativa, exigindo motivo de perda, registrando o evento de transição e sincronizando status do imóvel e lead vinculados.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "lostReason";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "dealId";
                    readonly type: "string";
                }, {
                    readonly name: "newStage";
                    readonly type: "DealStageEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly ["Deal", "DealStageTransitionEvent"];
                readonly readsTables: readonly ["deal_stage_transition_event_log"];
                readonly writesTables: readonly ["deal_stage_transition_event_log"];
                readonly usecaseRefs: readonly ["advanceDealStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-deal-stage-transition", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default dealTrackerPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/leadDetailPage.defs" {
    export const leadDetailPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadDetailPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 56;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadDetailPage";
                readonly pageName: "Detalhe do Lead";
                readonly actor: "corretorActor";
                readonly purpose: "Visualização completa do perfil do lead: dados de contato, histórico de etapas, visitas agendadas, negócios vinculados, classificação de IA e sugestões de follow-up.";
                readonly capabilities: readonly ["manageLeads", "leadPipelineKanban", "aiLeadClassification", "aiFollowUpSuggestion", "scheduleVisits", "trackDeals", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadStageTransition", "visitLifecycle", "dealStageProgression"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n", "provedor"];
                readonly mdmRefs: readonly ["lead", "property", "broker"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador único do lead cujo detalhe será exibido.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadPipelinePage";
                    readonly trigger: "Clique no card do lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadFormPage";
                    readonly trigger: "Clique em 'Editar'";
                    readonly description: "Navega para o formulário de edição do lead atual";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitFormPage";
                    readonly trigger: "Clique em 'Agendar Visita'";
                    readonly description: "Navega para o formulário de agendamento de visita pré-vinculado ao lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealFormPage";
                    readonly trigger: "Clique em 'Criar Negócio'";
                    readonly description: "Navega para o formulário de criação de negócio pré-vinculado ao lead";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Lead";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadProfileHeader";
                        readonly purpose: "Exibe os dados principais do lead (nome, contato, etapa atual, temperatura/classificação de IA, corretor responsável) e os botões de ação primária (Editar, Agendar Visita, Criar Negócio).";
                        readonly userActions: readonly ["Visualizar dados de contato do lead", "Visualizar etapa atual e classificação de temperatura", "Clicar em 'Editar' para navegar ao formulário de edição", "Clicar em 'Agendar Visita' para navegar ao formulário de visita", "Clicar em 'Criar Negócio' para navegar ao formulário de negócio"];
                        readonly requiredEntities: readonly ["Lead", "Corretor"];
                        readonly readsFields: readonly ["Lead.leadId", "Lead.name", "Lead.email", "Lead.phone", "Lead.source", "Lead.stage", "Lead.temperature", "Lead.temperatureJustification", "Lead.notes", "Lead.assignedCorretorId", "Lead.createdAt", "Lead.updatedAt", "Corretor.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Histórico de Etapas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadStageHistoryTimeline";
                        readonly purpose: "Exibe a linha do tempo cronológica de todas as transições de etapa do lead, com data/hora, etapa de origem, etapa de destino e usuário responsável.";
                        readonly userActions: readonly ["Visualizar histórico completo de transições de etapa do lead"];
                        readonly requiredEntities: readonly ["LeadStageTransitionEvent"];
                        readonly readsFields: readonly ["LeadStageTransitionEvent.eventId", "LeadStageTransitionEvent.fromStage", "LeadStageTransitionEvent.toStage", "LeadStageTransitionEvent.performedBy", "LeadStageTransitionEvent.occurredAt", "LeadStageTransitionEvent.transitionReason"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-lead-stage-transition"];
                    }];
                }, {
                    readonly sectionName: "Visitas Vinculadas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadVisitsList";
                        readonly purpose: "Lista as visitas agendadas e realizadas vinculadas ao lead, exibindo imóvel, data/hora e status de cada visita.";
                        readonly userActions: readonly ["Visualizar visitas vinculadas ao lead", "Clicar em 'Agendar Visita' para criar nova visita para este lead"];
                        readonly requiredEntities: readonly ["Visit", "Property"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.scheduledAt", "Visit.status", "Visit.propertyId", "Property.title", "Property.address"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Negócios Vinculados";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadDealsList";
                        readonly purpose: "Lista os negócios/propostas vinculados ao lead, exibindo imóvel, etapa do negócio, valor e data de criação.";
                        readonly userActions: readonly ["Visualizar negócios vinculados ao lead", "Clicar em 'Criar Negócio' para criar novo negócio para este lead"];
                        readonly requiredEntities: readonly ["Deal", "Property"];
                        readonly readsFields: readonly ["Deal.dealId", "Deal.stage", "Deal.dealValue", "Deal.dealType", "Deal.propertyId", "Deal.createdAt", "Property.title"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Classificação de IA";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadAiClassificationPanel";
                        readonly purpose: "Exibe a classificação de temperatura atual do lead (Quente/Morno/Frio) com justificativa gerada pela IA, e permite ao corretor acionar nova classificação via agente LLM. O resultado é exibido para revisão antes de ser persistido.";
                        readonly userActions: readonly ["Visualizar classificação de temperatura atual e justificativa", "Acionar 'Classificar com IA' para invocar o agente LLM", "Revisar resultado gerado pela IA antes de confirmar persistência"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.temperature", "Lead.temperatureJustification", "Lead.stage"];
                        readonly writesFields: readonly ["Lead.temperature", "Lead.temperatureJustification"];
                        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Sugestão de Follow-up";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadFollowUpSuggestionPanel";
                        readonly purpose: "Permite ao corretor solicitar ao agente LLM uma sugestão de mensagem de follow-up personalizada com base no perfil, classificação e histórico do lead. A mensagem sugerida é exibida para revisão e pode ser copiada ou descartada.";
                        readonly userActions: readonly ["Acionar 'Obter Sugestão de Follow-up' para invocar o agente LLM", "Visualizar mensagem sugerida pelo agente", "Copiar mensagem sugerida para uso externo"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.name", "Lead.stage", "Lead.temperature", "Lead.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLeadDetail";
                readonly purpose: "Buscar perfil completo do lead com dados de contato, etapa atual, classificação de temperatura, histórico de transições de etapa, visitas vinculadas e negócios vinculados.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "source";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "LeadStageEnum";
                }, {
                    readonly name: "temperature";
                    readonly type: "LeadTemperatureEnum";
                }, {
                    readonly name: "temperatureJustification";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "assignedCorretorId";
                    readonly type: "string";
                }, {
                    readonly name: "assignedCorretorName";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "stageHistory";
                    readonly type: "LeadStageTransitionEvent[]";
                }, {
                    readonly name: "visits";
                    readonly type: "Visit[]";
                }, {
                    readonly name: "deals";
                    readonly type: "Deal[]";
                }];
                readonly readsEntities: readonly ["Lead", "Corretor", "Visit", "Property", "Deal"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["manageLeadUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "classifyLeadAi";
                readonly purpose: "Invocar o agente LLM para classificar o lead como Quente/Morno/Frio com base no histórico e anotações. Registra o comando no log de IA e persiste a classificação no lead após revisão do corretor.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "commandLogId";
                    readonly type: "string";
                }, {
                    readonly name: "classification";
                    readonly type: "LeadTemperatureEnum";
                }, {
                    readonly name: "justification";
                    readonly type: "string";
                }, {
                    readonly name: "classifiedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly ["ai_command_log"];
                readonly usecaseRefs: readonly ["classifyLeadAiUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
            }, {
                readonly commandName: "getFollowUpSuggestion";
                readonly purpose: "Invocar o agente LLM para sugerir uma mensagem personalizada de follow-up com base no perfil, classificação e histórico do lead. Registra o comando no log de IA e retorna a mensagem sugerida para revisão do corretor.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "channel";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "commandLogId";
                    readonly type: "string";
                }, {
                    readonly name: "suggestedMessage";
                    readonly type: "string";
                }, {
                    readonly name: "generatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly ["ai_command_log"];
                readonly usecaseRefs: readonly ["getFollowUpSuggestionUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default leadDetailPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/leadFormPage.defs" {
    export const leadFormPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadFormPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadFormPage";
                readonly pageName: "Formulário de Lead";
                readonly actor: "corretorActor";
                readonly purpose: "Criação e edição de lead/cliente com dados de contato, preferências e imóveis de interesse. Suporta modo criação (sem leadId) e modo edição (com leadId via rota).";
                readonly capabilities: readonly ["manageLeads", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadStageTransition"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["lead", "broker"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador do lead a ser editado. Ausente no modo criação.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadPipelinePage";
                    readonly trigger: "Clique em 'Novo Lead'";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetailPage";
                    readonly trigger: "Clique em 'Editar'";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadPipelinePage";
                    readonly trigger: "Salvar ou cancelar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Formulário";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "FormHeaderOrganism";
                        readonly purpose: "Exibe o título dinâmico da página ('Novo Lead' ou 'Editar Lead') e o botão de cancelar para retornar ao pipeline.";
                        readonly userActions: readonly ["Cancelar e retornar ao pipeline"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Dados de Contato";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadContactFormOrganism";
                        readonly purpose: "Formulário com os campos de identificação e contato do lead: nome, e-mail, telefone e origem. Em modo edição, pré-carrega os dados existentes via getLeadByIdQuery.";
                        readonly userActions: readonly ["Preencher nome do lead", "Preencher e-mail", "Preencher telefone", "Selecionar origem do lead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "name", "email", "phone", "source"];
                        readonly writesFields: readonly ["name", "email", "phone", "source"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Preferências e Anotações";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadPreferencesFormOrganism";
                        readonly purpose: "Campos de preferências do lead (tipo de imóvel, faixa de valor, localização desejada) e campo de anotações livres para o corretor.";
                        readonly userActions: readonly ["Preencher preferências de imóvel", "Adicionar anotações"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["notes"];
                        readonly writesFields: readonly ["notes"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Ações do Formulário";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadFormActionsOrganism";
                        readonly purpose: "Botões de ação primária: 'Salvar Lead' (dispara createLeadCommand ou updateLeadCommand conforme o modo) e 'Cancelar'. Exibe feedback de validação e estado de carregamento.";
                        readonly userActions: readonly ["Salvar lead (criar ou atualizar)", "Cancelar e retornar ao pipeline"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId"];
                        readonly writesFields: readonly ["name", "email", "phone", "source", "notes"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLeadByIdQuery";
                readonly purpose: "Busca os dados completos de um lead existente para pré-popular o formulário no modo edição. Aplica isolamento de dados garantindo que o corretor só acesse leads atribuídos a ele.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "source";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "LeadStageEnum";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["manageLeadUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "createLeadCommand";
                readonly purpose: "Cadastra um novo lead no sistema associado ao corretor autenticado. Atualiza a métrica mensal de leads após a criação.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "source";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "LeadStageEnum";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Lead", "Corretor"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["manageLeadUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "updateLeadCommand";
                readonly purpose: "Atualiza os dados de contato, preferências e anotações de um lead existente. Aplica isolamento de dados garantindo que o corretor só edite leads atribuídos a ele.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "source";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Lead", "Corretor"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["manageLeadUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }];
        };
    };
    export default leadFormPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/leadPipelinePage.defs" {
    export const leadPipelinePagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadPipelinePage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadPipelinePage";
                readonly pageName: "Pipeline de Leads (Kanban)";
                readonly actor: "corretorActor";
                readonly purpose: "Visualização e gestão do funil de leads em formato Kanban por etapas. Permite mover leads entre etapas via drag-and-drop, classificar leads com IA (Quente/Morno/Frio) e obter sugestões de follow-up personalizadas.";
                readonly capabilities: readonly ["leadPipelineKanban", "manageLeads", "aiLeadClassification", "aiFollowUpSuggestion", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadStageTransition"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n", "provedor"];
                readonly mdmRefs: readonly ["lead", "broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "leadDetailPage";
                    readonly trigger: "Clique no card do lead";
                    readonly description: "Abre o detalhe completo do lead selecionado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadFormPage";
                    readonly trigger: "Clique em 'Novo Lead'";
                    readonly description: "Abre o formulário de criação de novo lead";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "operationalDashboardPage";
                    readonly trigger: "Clique em card de leads no dashboard";
                    readonly description: "Navega do Dashboard Operacional para o Pipeline de Leads";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Barra de Ferramentas do Pipeline";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "PipelineToolbar";
                        readonly purpose: "Exibe filtros de busca, botão de criação de novo lead e contador de leads por etapa. Permite ao corretor filtrar o Kanban por nome, temperatura ou etapa.";
                        readonly userActions: readonly ["Filtrar leads por nome/telefone", "Filtrar por temperatura (Quente/Morno/Frio)", "Clicar em 'Novo Lead' para navegar ao formulário"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["lead.name", "lead.temperature", "lead.stage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Kanban de Etapas do Funil";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadKanbanBoard";
                        readonly purpose: "Renderiza as colunas do funil (Novo, Contato, Visita, Proposta, Fechado, Perdido) com os cards de leads agrupados por etapa. Suporta drag-and-drop para mover leads entre colunas.";
                        readonly userActions: readonly ["Visualizar leads agrupados por etapa do funil", "Arrastar card de lead para nova coluna (drag-and-drop)", "Confirmar transição de etapa no modal de confirmação", "Informar motivo opcional da transição", "Clicar no card para abrir detalhe do lead"];
                        readonly requiredEntities: readonly ["Lead", "LeadStageTransitionEvent"];
                        readonly readsFields: readonly ["lead.leadId", "lead.name", "lead.phone", "lead.email", "lead.stage", "lead.temperature", "lead.temperatureJustification", "lead.updatedAt", "lead.assignedCorretorId"];
                        readonly writesFields: readonly ["lead.stage"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-lead-stage-transition"];
                    }, {
                        readonly organismName: "LeadKanbanCard";
                        readonly purpose: "Card individual do lead exibido em cada coluna do Kanban. Mostra nome, temperatura (badge colorido), telefone e ações rápidas de IA (classificar, sugerir follow-up).";
                        readonly userActions: readonly ["Clicar no card para abrir detalhe do lead", "Acionar classificação de IA no card", "Acionar sugestão de follow-up no card"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["lead.leadId", "lead.name", "lead.phone", "lead.temperature", "lead.temperatureJustification", "lead.stage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-llm-agent-invocation"];
                    }];
                }, {
                    readonly sectionName: "Modal de Classificação de Lead com IA";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "AiClassificationModal";
                        readonly purpose: "Modal acionado pelo corretor para invocar o agente LLM de classificação do lead. Exibe o resultado (Quente/Morno/Frio) com justificativa para revisão antes de persistir.";
                        readonly userActions: readonly ["Acionar classificação de IA para o lead selecionado", "Revisar resultado de classificação e justificativa", "Confirmar persistência da classificação no lead", "Cancelar sem persistir"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["lead.leadId", "lead.name", "lead.temperature"];
                        readonly writesFields: readonly ["lead.temperature", "lead.temperatureJustification"];
                        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Modal de Sugestão de Follow-up com IA";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "FollowUpSuggestionModal";
                        readonly purpose: "Modal acionado pelo corretor para obter sugestão de mensagem de follow-up personalizada via agente LLM. Exibe a mensagem sugerida para revisão e cópia.";
                        readonly userActions: readonly ["Acionar sugestão de follow-up para o lead selecionado", "Visualizar mensagem sugerida pelo agente LLM", "Copiar mensagem sugerida para área de transferência", "Fechar modal sem persistir"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["lead.leadId", "lead.name", "lead.stage", "lead.temperature"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLeadsByStage";
                readonly purpose: "Buscar todos os leads do corretor autenticado agrupados por etapa do funil para renderizar o Kanban. Aplica isolamento RBAC por corretorId resolvido via sessão.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "filters";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "temperature";
                    readonly type: "LeadTemperatureEnum";
                    readonly required: false;
                }, {
                    readonly name: "stage";
                    readonly type: "LeadStageEnum";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "stage";
                    readonly type: "LeadStageEnum";
                }, {
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }, {
                    readonly name: "count";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead", "Corretor"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["manageLeadUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "moveLeadStage";
                readonly purpose: "Mover lead para nova etapa do funil respeitando as transições válidas definidas em rule-lead-stage-transition. Registra evento de transição e atualiza métricas.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fromStage";
                    readonly type: "LeadStageEnum";
                    readonly required: true;
                }, {
                    readonly name: "toStage";
                    readonly type: "LeadStageEnum";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "newStage";
                    readonly type: "LeadStageEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly ["Lead", "LeadStageTransitionEvent"];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly ["lead_stage_transition_event_log"];
                readonly usecaseRefs: readonly ["moveLeadStageUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-lead-stage-transition", "rule-rbac-data-isolation"];
            }, {
                readonly commandName: "classifyLeadAi";
                readonly purpose: "Invocar agente LLM para classificar o lead como Quente/Morno/Frio com base em anotações e histórico. Retorna resultado para revisão do corretor antes de persistir.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "commandLogId";
                    readonly type: "string";
                }, {
                    readonly name: "classification";
                    readonly type: "LeadTemperatureEnum";
                }, {
                    readonly name: "justification";
                    readonly type: "string";
                }, {
                    readonly name: "classifiedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly ["Lead"];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly ["ai_command_log"];
                readonly usecaseRefs: readonly ["classifyLeadAiUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
            }, {
                readonly commandName: "getFollowUpSuggestion";
                readonly purpose: "Invocar agente LLM para sugerir mensagem de follow-up personalizada com base no perfil, classificação e histórico do lead. Resultado retornado para revisão do corretor.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "channel";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "commandLogId";
                    readonly type: "string";
                }, {
                    readonly name: "suggestedMessage";
                    readonly type: "string";
                }, {
                    readonly name: "generatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_stage_transition_event_log"];
                readonly writesTables: readonly ["ai_command_log"];
                readonly usecaseRefs: readonly ["getFollowUpSuggestionUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default leadPipelinePagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/module.defs" {
    export const initial: {
        readonly moduleName: "manterPropertyFlowCrm";
        readonly requestKind: "module_solution";
        readonly userLanguage: "pt-BR";
        readonly userPrompt: "um app profissional chamado PropertyFlowCRM para imobiliárias e corretores.\nEntidades principais: Imóvel (endereço, tipo, preço, status, características, fotos mock), Lead/Cliente, Visita/Agendamento, Negócio/Proposta (status, valor, imóvel), Corretor.\nTelas chave: Dashboard (imóveis ativos, leads do mês, pipeline de fechamentos), CRUD de imóveis com busca, Pipeline de leads (kanban ou lista), Agendador de visitas, Rastreador de negócios por etapas.\nFuncionalidade LLM: IA que gera descrição do imóvel a partir de bullets ou classifica lead como \"quente/morno/frio\" a partir de anotações e sugere próxima mensagem de follow-up.\nFoco: Gestão de imóveis + leads + coordenação de visitas — específico para corretagem imobiliária.\nlinguagens: 'en' e 'pt-br'";
        readonly createdAt: "2026-06-11T01:03:22.793Z";
    };
}
declare module "_102045_/l2/manterPropertyFlowCrm/operationalDashboardPage.defs" {
    export const operationalDashboardPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "operationalDashboardPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 56;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "operationalDashboardPage";
                readonly pageName: "Dashboard Operacional";
                readonly actor: "adminActor";
                readonly purpose: "Visão consolidada das métricas operacionais da imobiliária: imóveis ativos, leads do mês, pipeline de fechamentos, taxa de conversão e visitas realizadas. Ponto de entrada principal do Admin.";
                readonly capabilities: readonly ["dashboardOverview", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyListPage";
                    readonly trigger: "Clique em card de imóveis";
                    readonly description: "Navega para a lista completa de imóveis";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadPipelinePage";
                    readonly trigger: "Clique em card de leads";
                    readonly description: "Navega para o pipeline Kanban de leads";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealTrackerPage";
                    readonly trigger: "Clique em card de negócios";
                    readonly description: "Navega para o rastreador de negócios";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitListPage";
                    readonly trigger: "Clique em card de visitas";
                    readonly description: "Navega para a lista de visitas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtro de Período";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "PeriodFilterBar";
                        readonly purpose: "Permite ao Admin selecionar o intervalo de datas para filtrar todas as métricas do dashboard";
                        readonly userActions: readonly ["Selecionar data de início", "Selecionar data de fim", "Aplicar filtro de período"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["periodStart", "periodEnd"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Cards de Métricas Operacionais";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ActivePropertiesMetricCard";
                        readonly purpose: "Exibe o total de imóveis ativos no período selecionado com link de navegação para a lista de imóveis";
                        readonly userActions: readonly ["Visualizar contagem de imóveis ativos", "Clicar para navegar para Lista de Imóveis"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["activePropertiesCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "MonthlyLeadsMetricCard";
                        readonly purpose: "Exibe o total de leads captados no mês/período selecionado com link de navegação para o pipeline";
                        readonly userActions: readonly ["Visualizar contagem de leads do mês", "Clicar para navegar para Pipeline de Leads"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["monthlyLeadsCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "DealPipelineMetricCard";
                        readonly purpose: "Exibe o resumo do pipeline de fechamentos (quantidade de negócios por etapa) com link para o rastreador";
                        readonly userActions: readonly ["Visualizar resumo do pipeline de negócios", "Clicar para navegar para Rastreador de Negócios"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["dealPipelineSummary"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "LeadConversionRateMetricCard";
                        readonly purpose: "Exibe a taxa de conversão de leads (leads fechados / total de leads) no período selecionado";
                        readonly userActions: readonly ["Visualizar taxa de conversão de leads"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadConversionRate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "VisitsPerMonthMetricCard";
                        readonly purpose: "Exibe o total de visitas realizadas no mês/período selecionado com link para a lista de visitas";
                        readonly userActions: readonly ["Visualizar contagem de visitas realizadas", "Clicar para navegar para Lista de Visitas"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["visitsPerMonthCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Painel de Indicadores Detalhados";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "DashboardMetricsSummaryPanel";
                        readonly purpose: "Painel consolidado que agrega e exibe todos os indicadores operacionais retornados pelo BFF em uma única chamada, incluindo timestamp de geração";
                        readonly userActions: readonly ["Visualizar métricas consolidadas", "Atualizar dados do dashboard"];
                        readonly requiredEntities: readonly ["Property", "Lead", "Corretor"];
                        readonly readsFields: readonly ["activePropertiesCount", "monthlyLeadsCount", "dealPipelineSummary", "leadConversionRate", "visitsPerMonthCount", "generatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "queryDashboardMetrics";
                readonly purpose: "Buscar todos os indicadores do dashboard operacional em uma única chamada agregada: imóveis ativos, leads do mês, pipeline de fechamentos, taxa de conversão e visitas realizadas no período informado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "activePropertiesCount";
                    readonly type: "number";
                }, {
                    readonly name: "monthlyLeadsCount";
                    readonly type: "number";
                }, {
                    readonly name: "dealPipelineSummary";
                    readonly type: "DealPipelineSummary";
                }, {
                    readonly name: "leadConversionRate";
                    readonly type: "number";
                }, {
                    readonly name: "visitsPerMonthCount";
                    readonly type: "number";
                }, {
                    readonly name: "generatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property", "Lead", "Corretor"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_stage_transition_event_log", "deal_stage_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["queryDashboardMetricsUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }];
        };
    };
    export default operationalDashboardPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/propertyFormPage.defs" {
    export const propertyFormPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyFormPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyFormPage";
                readonly pageName: "Formulário de Imóvel";
                readonly actor: "adminActor";
                readonly purpose: "Criação e edição de imóvel com todos os campos necessários (tipo, endereço, valor, fotos, descrição). Inclui ação de geração de descrição com IA via agente LLM, com revisão obrigatória antes de salvar.";
                readonly capabilities: readonly ["manageProperties", "aiPropertyDescription", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyStatusUpdate"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n", "mockImage", "provedor"];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "ID do imóvel a ser editado. Ausente indica modo criação.";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "propertyListPage";
                    readonly trigger: "Clique em 'Novo Imóvel' ou 'Editar' na lista de imóveis";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyListPage";
                    readonly trigger: "Salvar imóvel com sucesso ou cancelar edição";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Cabeçalho do Formulário";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "FormHeaderOrganism";
                        readonly purpose: "Exibe o título dinâmico do formulário ('Novo Imóvel' ou 'Editar Imóvel') e o status atual do imóvel em modo edição, com botão de cancelar.";
                        readonly userActions: readonly ["Cancelar e retornar à lista"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Dados Principais do Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyBasicDataFormOrganism";
                        readonly purpose: "Formulário com os campos principais do imóvel: título, tipo, endereço, preço, área, quartos, banheiros e status. Carrega dados existentes em modo edição.";
                        readonly userActions: readonly ["Preencher título do imóvel", "Selecionar tipo do imóvel", "Preencher endereço completo", "Informar preço", "Informar área em m²", "Informar número de quartos", "Informar número de banheiros", "Selecionar status do imóvel (modo edição)"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.type", "Property.address", "Property.price", "Property.area", "Property.bedrooms", "Property.bathrooms", "Property.status"];
                        readonly writesFields: readonly ["Property.title", "Property.type", "Property.address", "Property.price", "Property.area", "Property.bedrooms", "Property.bathrooms", "Property.status"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-property-status-transition"];
                    }];
                }, {
                    readonly sectionName: "Fotos do Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyPhotosOrganism";
                        readonly purpose: "Gerencia a URL de imagem do imóvel via plugin mockImage (picsum.photos). Exibe preview da imagem atual e permite informar ou gerar nova URL de imagem placeholder.";
                        readonly userActions: readonly ["Informar URL de imagem", "Gerar URL de imagem placeholder via mockImage"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.imageUrl"];
                        readonly writesFields: readonly ["Property.imageUrl"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Descrição do Imóvel com IA";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyDescriptionAIOrganism";
                        readonly purpose: "Área de edição da descrição textual do imóvel. Permite ao usuário redigir manualmente ou acionar o agente LLM para gerar uma descrição profissional com base nos atributos preenchidos. O resultado gerado é exibido para revisão antes de ser aceito.";
                        readonly userActions: readonly ["Redigir descrição manualmente", "Selecionar idioma alvo para geração (pt-BR ou en)", "Acionar geração de descrição com IA", "Revisar descrição gerada pelo agente", "Aceitar descrição gerada (substituir campo)", "Descartar descrição gerada"];
                        readonly requiredEntities: readonly ["Property", "PropertyDescriptionCommand"];
                        readonly readsFields: readonly ["Property.description", "Property.title", "Property.type", "Property.address", "Property.price", "Property.area", "Property.bedrooms", "Property.bathrooms", "PropertyDescriptionCommand.generatedDescription", "PropertyDescriptionCommand.status"];
                        readonly writesFields: readonly ["Property.description"];
                        readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Ações do Formulário";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyFormActionsOrganism";
                        readonly purpose: "Barra de ações com botão primário de salvar (criar ou atualizar imóvel) e botão secundário de cancelar. Exibe feedback de validação e confirmação de sucesso.";
                        readonly userActions: readonly ["Salvar imóvel (criar ou atualizar)", "Cancelar e retornar à lista"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId"];
                        readonly writesFields: readonly ["Property.title", "Property.type", "Property.address", "Property.price", "Property.area", "Property.bedrooms", "Property.bathrooms", "Property.imageUrl", "Property.description", "Property.status"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-property-status-transition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getPropertyById";
                readonly purpose: "Busca os dados completos de um imóvel existente para pré-preencher o formulário em modo edição.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "area";
                    readonly type: "number";
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updatePropertyStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "createProperty";
                readonly purpose: "Cadastra um novo imóvel no sistema com todos os campos obrigatórios e opcionais. Registra o status inicial como 'disponivel' e persiste via MDM de Imóvel.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["Property"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_status_transition_event_log"];
                readonly usecaseRefs: readonly ["updatePropertyStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-property-status-transition"];
            }, {
                readonly commandName: "updateProperty";
                readonly purpose: "Atualiza os dados de um imóvel existente. Quando o campo status é alterado, delega a transição ao updatePropertyStatusUsecase para validação e registro do evento.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly ["Property"];
                readonly readsTables: readonly ["property_status_transition_event_log"];
                readonly writesTables: readonly ["property_status_transition_event_log"];
                readonly usecaseRefs: readonly ["updatePropertyStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-property-status-transition"];
            }, {
                readonly commandName: "generatePropertyDescription";
                readonly purpose: "Invoca o agente LLM (via plugin provedor) para gerar uma descrição profissional do imóvel com base nos atributos preenchidos no formulário. O resultado é retornado para revisão do usuário antes de ser salvo no campo descrição.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "targetLanguage";
                    readonly type: "enum(pt-BR,en)";
                    readonly required: true;
                }, {
                    readonly name: "tone";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "commandLogId";
                    readonly type: "string";
                }, {
                    readonly name: "generatedDescription";
                    readonly type: "string";
                }, {
                    readonly name: "generatedAt";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "enum(pending,completed,failed)";
                }];
                readonly readsEntities: readonly ["Property", "PropertyDescriptionCommand"];
                readonly writesEntities: readonly ["PropertyDescriptionCommand"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["ai_command_log"];
                readonly usecaseRefs: readonly ["generatePropertyDescriptionUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-llm-agent-invocation", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default propertyFormPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/propertyListPage.defs" {
    export const propertyListPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyListPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyListPage";
                readonly pageName: "Lista de Imóveis";
                readonly actor: "adminActor";
                readonly purpose: "Listagem, busca e filtragem de todos os imóveis cadastrados. Ponto de entrada para criar, editar e atualizar status de imóveis.";
                readonly capabilities: readonly ["manageProperties", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyStatusUpdate"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n", "mockImage"];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro de status do imóvel (disponivel, reservado, vendido, alugado, inativo)";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro por tipo de imóvel (ex: apartamento, casa, comercial)";
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro por cidade do imóvel";
                }, {
                    readonly name: "priceMin";
                    readonly type: "number";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Faixa de preço mínima para filtro";
                }, {
                    readonly name: "priceMax";
                    readonly type: "number";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Faixa de preço máxima para filtro";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyFormPage";
                    readonly trigger: "Clique em 'Novo Imóvel'";
                    readonly description: "Navega para o formulário de criação de imóvel";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyFormPage";
                    readonly trigger: "Clique em 'Editar' no item da lista";
                    readonly description: "Navega para o formulário de edição do imóvel selecionado";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "operationalDashboardPage";
                    readonly trigger: "Clique em card de imóveis";
                    readonly description: "Entrada a partir do Dashboard Operacional";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Barra de Filtros e Busca";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyFilterBar";
                        readonly purpose: "Permitir ao Admin filtrar e buscar imóveis por status, tipo, cidade e faixa de preço antes de visualizar a lista.";
                        readonly userActions: readonly ["Selecionar filtro de status", "Selecionar filtro de tipo", "Digitar cidade", "Definir faixa de preço mínima e máxima", "Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["status", "type", "city", "price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Lista de Imóveis";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyListTable";
                        readonly purpose: "Exibir a lista paginada de imóveis com seus dados principais (título, tipo, cidade, preço, status, foto mock) e ações rápidas de editar e atualizar status.";
                        readonly userActions: readonly ["Visualizar lista de imóveis", "Navegar entre páginas (paginação)", "Clicar em 'Editar' para ir ao formulário de edição", "Clicar em 'Atualizar Status' para abrir modal de transição de status"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["propertyId", "title", "type", "city", "price", "status", "imageUrl", "area", "bedrooms", "bathrooms"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Ações Globais";
                    readonly mode: "write";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyListActions";
                        readonly purpose: "Disponibilizar a ação de criação de novo imóvel e acesso rápido ao formulário.";
                        readonly userActions: readonly ["Clicar em 'Novo Imóvel' para navegar ao formulário de criação"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Modal de Atualização de Status";
                    readonly mode: "write";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertyStatusUpdateModal";
                        readonly purpose: "Permitir ao Admin selecionar o novo status de um imóvel respeitando as transições válidas definidas pela rule-property-status-transition e confirmar a mudança.";
                        readonly userActions: readonly ["Visualizar status atual do imóvel", "Selecionar novo status (apenas transições válidas habilitadas)", "Confirmar atualização de status", "Cancelar e fechar modal"];
                        readonly requiredEntities: readonly ["Property", "PropertyStatusTransitionEvent"];
                        readonly readsFields: readonly ["propertyId", "status"];
                        readonly writesFields: readonly ["status"];
                        readonly rulesApplied: readonly ["rule-property-status-transition", "rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listPropertiesQuery";
                readonly purpose: "Listar imóveis com filtros (status, tipo, cidade, faixa de preço) e paginação, respeitando isolamento de dados por perfil RBAC.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "priceMin";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "priceMax";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "city";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "PropertyStatusEnum";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                }, {
                    readonly name: "area";
                    readonly type: "number";
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                }, {
                    readonly name: "totalCount";
                    readonly type: "number";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updatePropertyStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "updatePropertyStatusCommand";
                readonly purpose: "Atualizar o status de um imóvel respeitando as transições válidas definidas pela rule-property-status-transition, registrando o evento de transição em propertyStatusTransitionEventLog.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fromStatus";
                    readonly type: "PropertyStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "toStatus";
                    readonly type: "PropertyStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "newStatus";
                    readonly type: "PropertyStatusEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly ["Property", "PropertyStatusTransitionEvent"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_status_transition_event_log"];
                readonly usecaseRefs: readonly ["updatePropertyStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-property-status-transition", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default propertyListPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/visitFormPage.defs" {
    export const visitFormPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitFormPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitFormPage";
                readonly pageName: "Formulário de Visita";
                readonly actor: "corretorActor";
                readonly purpose: "Agendamento de nova visita vinculando imóvel, lead e corretor com data/hora. Valida conflito de horário antes de confirmar.";
                readonly capabilities: readonly ["scheduleVisits", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do lead pré-selecionado quando a página é aberta a partir do detalhe do lead.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "ID do imóvel pré-selecionado quando a página é aberta a partir do detalhe do imóvel.";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "visitListPage";
                    readonly trigger: "Clique em 'Agendar Visita' na lista de visitas";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadDetailPage";
                    readonly trigger: "Clique em 'Agendar Visita' no detalhe do lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitListPage";
                    readonly trigger: "Salvar agendamento com sucesso ou cancelar formulário";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de Imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PropertySelectorOrganism";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o imóvel que será visitado. Pré-popula com propertyId quando fornecido via pageInput.";
                        readonly userActions: readonly ["Buscar imóvel por nome/endereço", "Selecionar imóvel da lista"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["propertyId", "title", "address", "type", "status"];
                        readonly writesFields: readonly ["propertyId"];
                        readonly rulesApplied: readonly ["rule-visit-requires-property-lead-corretor", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Seleção de Lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadSelectorOrganism";
                        readonly purpose: "Permitir ao corretor buscar e selecionar o lead que realizará a visita. Pré-popula com leadId quando fornecido via pageInput.";
                        readonly userActions: readonly ["Buscar lead por nome/contato", "Selecionar lead da lista"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "name", "email", "phone", "stage"];
                        readonly writesFields: readonly ["leadId"];
                        readonly rulesApplied: readonly ["rule-visit-requires-property-lead-corretor", "rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Dados do Agendamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitScheduleFormOrganism";
                        readonly purpose: "Capturar data/hora da visita e observações opcionais. Exibe aviso de conflito de horário em tempo real antes de confirmar.";
                        readonly userActions: readonly ["Definir data e hora da visita", "Adicionar observações opcionais", "Verificar disponibilidade de horário"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["scheduledAt", "notes"];
                        readonly writesFields: readonly ["scheduledAt", "notes"];
                        readonly rulesApplied: readonly ["rule-visit-no-conflict"];
                    }];
                }, {
                    readonly sectionName: "Confirmação do Agendamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitScheduleConfirmOrganism";
                        readonly purpose: "Resumo dos dados selecionados (imóvel, lead, corretor, data/hora) e botão de confirmação do agendamento. Exibe erros de validação de conflito ou vínculos ausentes.";
                        readonly userActions: readonly ["Confirmar agendamento", "Cancelar e voltar para lista de visitas"];
                        readonly requiredEntities: readonly ["Visit", "Property", "Lead", "Corretor"];
                        readonly readsFields: readonly ["propertyId", "leadId", "corretorId", "scheduledAt", "notes"];
                        readonly writesFields: readonly ["visitId", "status"];
                        readonly rulesApplied: readonly ["rule-visit-requires-property-lead-corretor", "rule-visit-no-conflict", "rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listPropertiesForSelector";
                readonly purpose: "Buscar lista paginada de imóveis ativos para o seletor de imóvel no formulário de visita, filtrando por termo de busca.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "totalCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateVisitStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "listLeadsForSelector";
                readonly purpose: "Buscar lista paginada de leads do corretor autenticado para o seletor de lead no formulário de visita, filtrando por termo de busca.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                }, {
                    readonly name: "totalCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Lead"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateVisitStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "checkVisitConflict";
                readonly purpose: "Verificar em tempo real se existe conflito de horário para o corretor autenticado na data/hora informada, antes de confirmar o agendamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "scheduledAt";
                    readonly type: "date";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "hasConflict";
                    readonly type: "boolean";
                }, {
                    readonly name: "conflictingVisitId";
                    readonly type: "string";
                }, {
                    readonly name: "conflictingScheduledAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Visit"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit_status_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateVisitStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-visit-no-conflict", "rule-rbac-data-isolation"];
            }, {
                readonly commandName: "scheduleVisit";
                readonly purpose: "Criar agendamento de nova visita validando vínculos obrigatórios (imóvel, lead, corretor) e ausência de conflito de horário. Registra evento de transição de status e atualiza métrica de visitas.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "corretorId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "VisitStatusEnum";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "date";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "corretorId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Visit", "Property", "Lead", "Corretor"];
                readonly writesEntities: readonly ["Visit", "VisitStatusTransitionEvent"];
                readonly readsTables: readonly ["visit_status_transition_event_log"];
                readonly writesTables: readonly ["visit_status_transition_event_log"];
                readonly usecaseRefs: readonly ["updateVisitStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-visit-requires-property-lead-corretor", "rule-visit-no-conflict", "rule-rbac-data-isolation"];
            }];
        };
    };
    export default visitFormPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/visitListPage.defs" {
    export const visitListPagePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitListPage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitListPage";
                readonly pageName: "Lista de Visitas";
                readonly actor: "corretorActor";
                readonly purpose: "Listagem e gerenciamento de visitas agendadas do corretor autenticado. Permite visualizar, filtrar por status e intervalo de datas, atualizar o status de cada visita (confirmar, marcar como realizada, cancelar, reagendar) e navegar para o agendamento de nova visita.";
                readonly capabilities: readonly ["scheduleVisits", "roleBasedAccess"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["i18n"];
                readonly mdmRefs: readonly ["property", "lead", "broker"];
                readonly pageInputs: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "VisitStatusEnum";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Filtro opcional de status da visita (agendada, confirmada, realizada, cancelada, reagendada).";
                }, {
                    readonly name: "dateRangeStart";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data de início do intervalo de filtro.";
                }, {
                    readonly name: "dateRangeEnd";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data de fim do intervalo de filtro.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "visitFormPage";
                    readonly trigger: "Clique em 'Agendar Visita'";
                    readonly description: "Navega para o formulário de agendamento de nova visita.";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "operationalDashboardPage";
                    readonly trigger: "Clique em card de visitas";
                    readonly description: "Acesso a partir do Dashboard Operacional via card de visitas.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Barra de Filtros";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitFilterBar";
                        readonly purpose: "Permite ao corretor filtrar a lista de visitas por status e intervalo de datas. Exibe controles de seleção de status e date-picker de período.";
                        readonly userActions: readonly ["Selecionar status de filtro", "Definir intervalo de datas (dateRangeStart / dateRangeEnd)", "Limpar filtros"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["statusFilter", "dateRangeStart", "dateRangeEnd"];
                        readonly writesFields: readonly ["statusFilter", "dateRangeStart", "dateRangeEnd"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }, {
                    readonly sectionName: "Lista de Visitas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "VisitListTable";
                        readonly purpose: "Exibe a lista paginada de visitas do corretor autenticado com colunas de imóvel, lead, data/hora agendada e status atual. Aplica isolamento RBAC garantindo que apenas visitas do corretor autenticado sejam exibidas.";
                        readonly userActions: readonly ["Visualizar lista de visitas", "Paginar resultados"];
                        readonly requiredEntities: readonly ["Visit", "Property", "Lead"];
                        readonly readsFields: readonly ["visitId", "propertyId", "propertyTitle", "leadId", "leadName", "scheduledAt", "status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }, {
                        readonly organismName: "VisitStatusActionMenu";
                        readonly purpose: "Menu de ações inline por visita que expõe as transições de status disponíveis (confirmar, marcar como realizada, cancelar, reagendar) de acordo com o status atual da visita. Aciona o BFF de atualização de status.";
                        readonly userActions: readonly ["Confirmar visita (agendada → confirmada)", "Marcar visita como realizada (confirmada → realizada)", "Cancelar visita com motivo (agendada/confirmada/reagendada → cancelada)", "Reagendar visita para nova data/hora (agendada/confirmada → reagendada)"];
                        readonly requiredEntities: readonly ["Visit", "VisitStatusTransitionEvent"];
                        readonly readsFields: readonly ["visitId", "status", "scheduledAt"];
                        readonly writesFields: readonly ["status", "transitionReason", "scheduledAt"];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-visit-no-conflict"];
                    }];
                }, {
                    readonly sectionName: "Ação Principal";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ScheduleVisitCTA";
                        readonly purpose: "Botão de ação principal que navega para o formulário de agendamento de nova visita.";
                        readonly userActions: readonly ["Clicar em 'Agendar Visita' para navegar ao visitFormPage"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listVisitsQuery";
                readonly purpose: "Retorna a lista paginada de visitas do corretor autenticado, aplicando filtros opcionais de status e intervalo de datas. O isolamento RBAC é garantido pelo usecase, que restringe os resultados ao corretorId resolvido pela sessão.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "VisitStatusEnum";
                    readonly required: false;
                }, {
                    readonly name: "dateRangeStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dateRangeEnd";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "propertyTitle";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "VisitStatusEnum";
                }, {
                    readonly name: "totalCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Visit", "Property", "Lead", "Corretor"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit_status_transition_event_log"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateVisitStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation"];
            }, {
                readonly commandName: "updateVisitStatusCommand";
                readonly purpose: "Executa a transição de status de uma visita (confirmar, marcar como realizada, cancelar ou reagendar). Valida conflito de horário quando aplicável, registra o VisitStatusTransitionEvent e atualiza a métrica de visitas do mês.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "fromStatus";
                    readonly type: "VisitStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "toStatus";
                    readonly type: "VisitStatusEnum";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "newScheduledAt";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "eventId";
                    readonly type: "string";
                }, {
                    readonly name: "visitId";
                    readonly type: "string";
                }, {
                    readonly name: "newStatus";
                    readonly type: "VisitStatusEnum";
                }, {
                    readonly name: "transitionedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Visit", "Property", "Lead", "Corretor"];
                readonly writesEntities: readonly ["Visit", "VisitStatusTransitionEvent"];
                readonly readsTables: readonly ["visit_status_transition_event_log"];
                readonly writesTables: readonly ["visit_status_transition_event_log"];
                readonly usecaseRefs: readonly ["updateVisitStatusUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-rbac-data-isolation", "rule-visit-no-conflict"];
            }];
        };
    };
    export default visitListPagePagePlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/plugins/calend.defs" {
    export const calendPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "calend";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "calend";
                readonly provider: "Calend";
                readonly priority: "later";
                readonly reason: "Plugin para sincronização do agendador de visitas com calendários externos (Google Calendar, Microsoft Outlook). Identificado como risco de negócio mas fora do escopo do MVP — avaliação para versão futura.";
                readonly events: readonly ["calendar.eventCreated", "calendar.eventUpdated", "calendar.eventCancelled", "calendar.syncCompleted"];
                readonly requiredCredentials: readonly ["GOOGLE_CALENDAR_CLIENT_ID", "GOOGLE_CALENDAR_CLIENT_SECRET", "OUTLOOK_CLIENT_ID", "OUTLOOK_CLIENT_SECRET"];
                readonly inputData: readonly ["visitId", "visitDateTime", "leadName", "propertyAddress", "corretorEmail", "calendarProvider"];
                readonly outputData: readonly ["externalEventId", "calendarLink", "syncStatus"];
                readonly webhooks: readonly ["calendar.eventChanged"];
                readonly risks: readonly ["Autenticação OAuth com Google/Microsoft requer configuração de aplicativo nas respectivas plataformas.", "Sincronização bidirecional pode gerar conflitos se o corretor editar o evento diretamente no calendário externo.", "Escopo de permissões OAuth pode ser sensível para usuários corporativos."];
                readonly questions: readonly ["A integração deve suportar Google Calendar, Microsoft Outlook ou ambos?", "A sincronização será unidirecional (PropertyFlowCRM → Calendário) ou bidirecional?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/calend/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/calend.defs.ts";
            };
        };
    };
    export default calendPluginConnectionPlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/plugins/i18n.defs" {
    export const i18nPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "i18n";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "i18n";
                readonly provider: "I18n";
                readonly priority: "now";
                readonly reason: "Plugin para gerenciar traduções e alternância de idioma entre pt-BR (padrão) e inglês em toda a interface do PropertyFlowCRM. Requisito explícito definido na clarificação.";
                readonly events: readonly ["i18n.languageChanged", "i18n.translationMissing"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["locale", "translationKey", "interpolationParams"];
                readonly outputData: readonly ["translatedText", "currentLocale", "availableLocales"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Chaves de tradução ausentes podem causar fallback para o idioma padrão sem aviso visível ao usuário.", "Manutenção de dois conjuntos de traduções (pt-BR e en) aumenta o esforço de atualização de conteúdo."];
                readonly questions: readonly ["As traduções serão gerenciadas diretamente no código (arquivos JSON/TS) ou via plataforma externa de localização?", "Existe necessidade de suporte a outros idiomas além de pt-BR e en no futuro próximo?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/i18n/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/i18n.defs.ts";
            };
        };
    };
    export default i18nPluginConnectionPlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/plugins/mockImage.defs" {
    export const mockImagePluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "mockImage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "mockImage";
                readonly provider: "Mock Image";
                readonly priority: "now";
                readonly reason: "Plugin utilitário para gerar e gerenciar URLs de imagens placeholder (picsum.photos) para fotos de imóveis no MVP. Encapsula a lógica para facilitar migração futura para upload real.";
                readonly events: readonly ["mockImage.urlGenerated"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["imageId", "width", "height", "seed"];
                readonly outputData: readonly ["imageUrl", "thumbnailUrl"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de serviço externo (picsum.photos) — indisponibilidade do serviço impacta a exibição de fotos no MVP.", "URLs geradas são públicas e não representam imóveis reais, podendo causar confusão em demonstrações para clientes."];
                readonly questions: readonly ["O plugin mockImage e o picsumPhotos representam a mesma integração? Confirmar se apenas um deles deve ser utilizado para evitar duplicidade."];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/mockImage/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/mockImage.defs.ts";
            };
        };
    };
    export default mockImagePluginConnectionPlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/plugins/photoUpload.defs" {
    export const photoUploadPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "photoUpload";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "photoUpload";
                readonly provider: "Photo Upload";
                readonly priority: "later";
                readonly reason: "Plugin para upload e armazenamento de fotos reais de imóveis, substituindo as URLs de placeholder do picsum.photos. Explicitamente adiado para versão futura na clarificação.";
                readonly events: readonly ["photo.uploaded", "photo.deleted", "photo.reordered"];
                readonly requiredCredentials: readonly ["STORAGE_PROVIDER_KEY", "STORAGE_BUCKET_NAME"];
                readonly inputData: readonly ["propertyId", "photoFile", "photoOrder", "caption"];
                readonly outputData: readonly ["photoUrl", "thumbnailUrl", "photoId", "storageKey"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Escolha do provedor de armazenamento (AWS S3, Google Cloud Storage, Cloudinary etc.) impacta custos e configuração.", "Validação de tamanho e formato de arquivo deve ser implementada para evitar uploads inválidos.", "Migração das URLs mock para fotos reais requer estratégia de transição para dados existentes."];
                readonly questions: readonly ["Qual provedor de armazenamento de arquivos será utilizado para as fotos reais (AWS S3, Cloudinary, Google Cloud Storage)?", "Existe limite de número de fotos por imóvel ou tamanho máximo por arquivo?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/photoUpload/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/photoUpload.defs.ts";
            };
        };
    };
    export default photoUploadPluginConnectionPlan;
}
declare module "_102045_/l2/manterPropertyFlowCrm/plugins/provedor.defs" {
    export const provedorPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "provedor";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "provedor";
                readonly provider: "provedor";
                readonly priority: "now";
                readonly reason: "Plugin de integração com provedor LLM (OpenAI, Anthropic, Google Gemini ou similar) obrigatório para os três agentes de IA do MVP: geração de descrição de imóvel, classificação de lead e sugestão de follow-up.";
                readonly events: readonly ["llm.request", "llm.response", "llm.error"];
                readonly requiredCredentials: readonly ["LLM_PROVIDER_API_KEY"];
                readonly inputData: readonly ["prompt", "model", "temperature", "maxTokens", "language"];
                readonly outputData: readonly ["generatedText", "tokensUsed", "modelUsed"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["O provedor específico (OpenAI, Anthropic, Gemini) ainda não foi definido — a configuração da credencial depende dessa decisão do Admin.", "Custos de API podem variar significativamente entre provedores e volumes de uso.", "Latência do provedor externo pode impactar a experiência do usuário nos agentes de IA."];
                readonly questions: readonly ["Qual provedor LLM será utilizado por padrão: OpenAI, Anthropic (Claude) ou Google Gemini?", "O Admin poderá trocar o provedor LLM pela interface ou apenas via configuração de ambiente?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/provedor/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/provedor.defs.ts";
            };
        };
    };
    export default provedorPluginConnectionPlan;
}
declare module "_102045_/l2/plugins/calend/plugin.defs" {
    export const calendPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "calend";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "calend";
                readonly provider: "Calend";
                readonly priority: "later";
                readonly reason: "Plugin para sincronização do agendador de visitas com calendários externos (Google Calendar, Microsoft Outlook). Identificado como risco de negócio mas fora do escopo do MVP — avaliação para versão futura.";
                readonly events: readonly ["calendar.eventCreated", "calendar.eventUpdated", "calendar.eventCancelled", "calendar.syncCompleted"];
                readonly requiredCredentials: readonly ["GOOGLE_CALENDAR_CLIENT_ID", "GOOGLE_CALENDAR_CLIENT_SECRET", "OUTLOOK_CLIENT_ID", "OUTLOOK_CLIENT_SECRET"];
                readonly inputData: readonly ["visitId", "visitDateTime", "leadName", "propertyAddress", "corretorEmail", "calendarProvider"];
                readonly outputData: readonly ["externalEventId", "calendarLink", "syncStatus"];
                readonly webhooks: readonly ["calendar.eventChanged"];
                readonly risks: readonly ["Autenticação OAuth com Google/Microsoft requer configuração de aplicativo nas respectivas plataformas.", "Sincronização bidirecional pode gerar conflitos se o corretor editar o evento diretamente no calendário externo.", "Escopo de permissões OAuth pode ser sensível para usuários corporativos."];
                readonly questions: readonly ["A integração deve suportar Google Calendar, Microsoft Outlook ou ambos?", "A sincronização será unidirecional (PropertyFlowCRM → Calendário) ou bidirecional?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/calend/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/calend.defs.ts";
            };
        };
    };
    export default calendPluginPlan;
}
declare module "_102045_/l2/plugins/i18n/plugin.defs" {
    export const i18nPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "i18n";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "i18n";
                readonly provider: "I18n";
                readonly priority: "now";
                readonly reason: "Plugin para gerenciar traduções e alternância de idioma entre pt-BR (padrão) e inglês em toda a interface do PropertyFlowCRM. Requisito explícito definido na clarificação.";
                readonly events: readonly ["i18n.languageChanged", "i18n.translationMissing"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["locale", "translationKey", "interpolationParams"];
                readonly outputData: readonly ["translatedText", "currentLocale", "availableLocales"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Chaves de tradução ausentes podem causar fallback para o idioma padrão sem aviso visível ao usuário.", "Manutenção de dois conjuntos de traduções (pt-BR e en) aumenta o esforço de atualização de conteúdo."];
                readonly questions: readonly ["As traduções serão gerenciadas diretamente no código (arquivos JSON/TS) ou via plataforma externa de localização?", "Existe necessidade de suporte a outros idiomas além de pt-BR e en no futuro próximo?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/i18n/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/i18n.defs.ts";
            };
        };
    };
    export default i18nPluginPlan;
}
declare module "_102045_/l2/plugins/mockImage/plugin.defs" {
    export const mockImagePluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "mockImage";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "mockImage";
                readonly provider: "Mock Image";
                readonly priority: "now";
                readonly reason: "Plugin utilitário para gerar e gerenciar URLs de imagens placeholder (picsum.photos) para fotos de imóveis no MVP. Encapsula a lógica para facilitar migração futura para upload real.";
                readonly events: readonly ["mockImage.urlGenerated"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["imageId", "width", "height", "seed"];
                readonly outputData: readonly ["imageUrl", "thumbnailUrl"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de serviço externo (picsum.photos) — indisponibilidade do serviço impacta a exibição de fotos no MVP.", "URLs geradas são públicas e não representam imóveis reais, podendo causar confusão em demonstrações para clientes."];
                readonly questions: readonly ["O plugin mockImage e o picsumPhotos representam a mesma integração? Confirmar se apenas um deles deve ser utilizado para evitar duplicidade."];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/mockImage/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/mockImage.defs.ts";
            };
        };
    };
    export default mockImagePluginPlan;
}
declare module "_102045_/l2/plugins/photoUpload/plugin.defs" {
    export const photoUploadPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "photoUpload";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "photoUpload";
                readonly provider: "Photo Upload";
                readonly priority: "later";
                readonly reason: "Plugin para upload e armazenamento de fotos reais de imóveis, substituindo as URLs de placeholder do picsum.photos. Explicitamente adiado para versão futura na clarificação.";
                readonly events: readonly ["photo.uploaded", "photo.deleted", "photo.reordered"];
                readonly requiredCredentials: readonly ["STORAGE_PROVIDER_KEY", "STORAGE_BUCKET_NAME"];
                readonly inputData: readonly ["propertyId", "photoFile", "photoOrder", "caption"];
                readonly outputData: readonly ["photoUrl", "thumbnailUrl", "photoId", "storageKey"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Escolha do provedor de armazenamento (AWS S3, Google Cloud Storage, Cloudinary etc.) impacta custos e configuração.", "Validação de tamanho e formato de arquivo deve ser implementada para evitar uploads inválidos.", "Migração das URLs mock para fotos reais requer estratégia de transição para dados existentes."];
                readonly questions: readonly ["Qual provedor de armazenamento de arquivos será utilizado para as fotos reais (AWS S3, Cloudinary, Google Cloud Storage)?", "Existe limite de número de fotos por imóvel ou tamanho máximo por arquivo?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/photoUpload/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/photoUpload.defs.ts";
            };
        };
    };
    export default photoUploadPluginPlan;
}
declare module "_102045_/l2/plugins/provedor/plugin.defs" {
    export const provedorPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "provedor";
        readonly moduleName: "manterPropertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "provedor";
                readonly provider: "provedor";
                readonly priority: "now";
                readonly reason: "Plugin de integração com provedor LLM (OpenAI, Anthropic, Google Gemini ou similar) obrigatório para os três agentes de IA do MVP: geração de descrição de imóvel, classificação de lead e sugestão de follow-up.";
                readonly events: readonly ["llm.request", "llm.response", "llm.error"];
                readonly requiredCredentials: readonly ["LLM_PROVIDER_API_KEY"];
                readonly inputData: readonly ["prompt", "model", "temperature", "maxTokens", "language"];
                readonly outputData: readonly ["generatedText", "tokensUsed", "modelUsed"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["O provedor específico (OpenAI, Anthropic, Gemini) ainda não foi definido — a configuração da credencial depende dessa decisão do Admin.", "Custos de API podem variar significativamente entre provedores e volumes de uso.", "Latência do provedor externo pode impactar a experiência do usuário nos agentes de IA."];
                readonly questions: readonly ["Qual provedor LLM será utilizado por padrão: OpenAI, Anthropic (Claude) ou Google Gemini?", "O Admin poderá trocar o provedor LLM pela interface ou apenas via configuração de ambiente?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/provedor/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/provedor.defs.ts";
            };
        };
    };
    export default provedorPluginPlan;
}
