declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Broker.defs" {
    export const BrokerMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Broker";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Broker";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "broker";
            readonly domainTitle: "Corretor";
            readonly sourceOfTruth: "authRolesModule";
            readonly governanceRules: readonly ["ruleBrokerPermissions", "Perfis de corretor/gestor devem ser mantidos no módulo de autenticação e autorização", "Vínculo de imóvel e lead ao corretor deve ser feito por referência ao identificador mestre"];
            readonly title: "Corretor";
            readonly description: "Usuário responsável pelo atendimento e gestão do funil.";
            readonly fields: readonly [];
        };
    };
    export default BrokerMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Lead.defs" {
    export const LeadMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Lead";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Lead";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "lead";
            readonly domainTitle: "Lead/Cliente";
            readonly sourceOfTruth: "leadDetailPage e casos de uso de lead (createLeadUsecase, updateLeadStageUsecase, updateLeadNotesUsecase)";
            readonly governanceRules: readonly ["ruleLeadTemperature", "ruleLeadStageTransition", "Dados de lead devem ser mantidos centralizados e referenciados por identificador único", "Movimentações no pipeline devem registrar histórico de alterações"];
            readonly title: "Lead/Cliente";
            readonly description: "Pessoa interessada com dados de contato, notas, estágio e temperatura.";
            readonly fields: readonly [];
        };
    };
    export default LeadMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Property.defs" {
    export const PropertyMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Property";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Property";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "property";
            readonly domainTitle: "Imóvel";
            readonly sourceOfTruth: "propertyFormPage e casos de uso de imóvel (createPropertyUsecase, updatePropertyUsecase, archivePropertyUsecase)";
            readonly governanceRules: readonly ["rulePropertyStatus", "Dados de imóvel devem ser mantidos centralizados e referenciados por identificador único", "Alterações de status devem ser auditadas e replicadas aos consumidores"];
            readonly title: "Imóvel";
            readonly description: "Unidade imobiliária cadastrada para venda ou locação, com atributos, status e mídia.";
            readonly fields: readonly [];
        };
    };
    export default PropertyMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/dealMetrics.defs" {
    export const dealMetricsDefs: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dealMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dealMetrics";
                readonly tableName: "deal_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Negócios";
                readonly purpose: "Acompanhar a criação e evolução de propostas e negócios";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Momento do evento de métrica";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo negócio";
                }, {
                    readonly name: "deal_stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Etapa atual do negócio";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel vinculado ao negócio";
                }, {
                    readonly name: "deals_created";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Negócios criados";
                }, {
                    readonly name: "deal_stage_transitions";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Transições de etapa do negócio";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pelo negócio";
                }, {
                    readonly dimensionId: "dealStage";
                    readonly column: "deal_stage";
                    readonly type: "string";
                    readonly description: "Etapa atual do negócio";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "uuid";
                    readonly description: "Imóvel vinculado ao negócio";
                }];
                readonly measures: readonly [{
                    readonly measureId: "dealsCreated";
                    readonly column: "deals_created";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Negócios criados";
                }, {
                    readonly measureId: "dealStageTransitions";
                    readonly column: "deal_stage_transitions";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Transições de etapa do negócio";
                }];
                readonly sourceWriteEvents: readonly ["createDeal", "updateDealStage"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly indexes: readonly [{
                        readonly indexName: "deal_metrics_event_time_idx";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consulta temporal por janela";
                    }, {
                        readonly indexName: "deal_metrics_broker_time_idx";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Filtros por corretor em série temporal";
                    }, {
                        readonly indexName: "deal_metrics_stage_time_idx";
                        readonly columns: readonly ["deal_stage", "event_time"];
                        readonly purpose: "Filtros por etapa em série temporal";
                    }, {
                        readonly indexName: "deal_metrics_property_time_idx";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Filtros por imóvel em série temporal";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createDealUsecase", "updateDealStageUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleDealRequiresProperty", "ruleDealStageTransition"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealMetrics.defs.ts";
                readonly exportName: "dealMetricsDefs";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealMetricsDefs;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadMetrics.defs" {
    export const leadMetricsTable: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "leadMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 44;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "leadMetrics";
                readonly tableName: "lead_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Leads";
                readonly purpose: "Monitorar o fluxo de leads pelo pipeline e suas qualificações";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Momento do evento de métrica";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pelo lead";
                }, {
                    readonly name: "lead_stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Estágio atual do lead no pipeline";
                }, {
                    readonly name: "lead_temperature";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Temperatura/classificação do lead";
                }, {
                    readonly name: "leads_created";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de leads cadastrados";
                }, {
                    readonly name: "lead_stage_transitions";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Movimentações de estágio no kanban";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pelo lead";
                }, {
                    readonly dimensionId: "leadStage";
                    readonly column: "lead_stage";
                    readonly type: "string";
                    readonly description: "Estágio atual do lead no pipeline";
                }, {
                    readonly dimensionId: "leadTemperature";
                    readonly column: "lead_temperature";
                    readonly type: "string";
                    readonly description: "Temperatura/classificação do lead";
                }];
                readonly measures: readonly [{
                    readonly measureId: "leadsCreated";
                    readonly column: "leads_created";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de leads cadastrados";
                }, {
                    readonly measureId: "leadStageTransitions";
                    readonly column: "lead_stage_transitions";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Movimentações de estágio no kanban";
                }];
                readonly sourceWriteEvents: readonly ["createLead", "updateLeadStage", "updateLeadNotes"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly indexes: readonly [{
                        readonly indexName: "lead_metrics_time_idx";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Suporte a consultas por período";
                        readonly unique: false;
                    }, {
                        readonly indexName: "lead_metrics_broker_time_idx";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Filtrar por corretor ao longo do tempo";
                        readonly unique: false;
                    }, {
                        readonly indexName: "lead_metrics_stage_time_idx";
                        readonly columns: readonly ["lead_stage", "event_time"];
                        readonly purpose: "Análise por estágio do pipeline";
                        readonly unique: false;
                    }, {
                        readonly indexName: "lead_metrics_temperature_time_idx";
                        readonly columns: readonly ["lead_temperature", "event_time"];
                        readonly purpose: "Análise por temperatura de lead";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createLeadUsecase", "updateLeadStageUsecase", "updateLeadNotesUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleLeadTemperature", "ruleLeadStageTransition"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadMetrics.defs.ts";
                readonly exportName: "leadMetricsTable";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadMetricsTable;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/propertyMetrics.defs" {
    export const propertyMetricsTable: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "propertyMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 43;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "propertyMetrics";
                readonly tableName: "property_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Imóveis";
                readonly purpose: "Acompanhar o volume e status dos imóveis cadastrados ao longo do tempo";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento do evento que alimenta a métrica";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Corretor responsável pelo imóvel";
                }, {
                    readonly name: "property_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Status atual do imóvel";
                }, {
                    readonly name: "properties_created";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de imóveis cadastrados";
                }, {
                    readonly name: "properties_archived";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de imóveis inativados";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pelo imóvel";
                }, {
                    readonly dimensionId: "propertyStatus";
                    readonly column: "property_status";
                    readonly type: "string";
                    readonly description: "Status atual do imóvel";
                }];
                readonly measures: readonly [{
                    readonly measureId: "propertiesCreated";
                    readonly column: "properties_created";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de imóveis cadastrados";
                }, {
                    readonly measureId: "propertiesArchived";
                    readonly column: "properties_archived";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de imóveis inativados";
                }];
                readonly sourceWriteEvents: readonly ["createProperty", "updateProperty", "archiveProperty"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "property_metrics_event_time_idx";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Ordenação e filtros por tempo";
                    }, {
                        readonly indexName: "property_metrics_broker_time_idx";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consulta por corretor e janela temporal";
                    }, {
                        readonly indexName: "property_metrics_status_time_idx";
                        readonly columns: readonly ["property_status", "event_time"];
                        readonly purpose: "Consulta por status e janela temporal";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createPropertyUsecase", "updatePropertyUsecase", "archivePropertyUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["rulePropertyStatus"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/propertyMetrics.defs.ts";
                readonly exportName: "propertyMetricsTable";
                readonly saveAsDefs: true;
            };
        };
    };
    export default propertyMetricsTable;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/visitMetrics.defs" {
    export const visitMetricsTable: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "visitMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "visitMetrics";
                readonly tableName: "visit_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Visitas";
                readonly purpose: "Rastrear agendamentos, reagendamentos e cancelamentos de visitas";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Momento do evento de visita";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável pela visita";
                }, {
                    readonly name: "visit_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da visita";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel visitado";
                }, {
                    readonly name: "visits_scheduled";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Visitas agendadas";
                }, {
                    readonly name: "visits_rescheduled";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Visitas reagendadas";
                }, {
                    readonly name: "visits_cancelled";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Visitas canceladas";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "uuid";
                    readonly description: "Corretor responsável pela visita";
                }, {
                    readonly dimensionId: "visitStatus";
                    readonly column: "visit_status";
                    readonly type: "string";
                    readonly description: "Status da visita";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "uuid";
                    readonly description: "Imóvel visitado";
                }];
                readonly measures: readonly [{
                    readonly measureId: "visitsScheduled";
                    readonly column: "visits_scheduled";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Visitas agendadas";
                }, {
                    readonly measureId: "visitsRescheduled";
                    readonly column: "visits_rescheduled";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Visitas reagendadas";
                }, {
                    readonly measureId: "visitsCancelled";
                    readonly column: "visits_cancelled";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Visitas canceladas";
                }];
                readonly sourceWriteEvents: readonly ["scheduleVisit", "rescheduleVisit", "cancelVisit"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "visit_metrics_time_idx";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Otimizar consultas por janela temporal";
                    }, {
                        readonly indexName: "visit_metrics_broker_time_idx";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Análises por corretor ao longo do tempo";
                    }, {
                        readonly indexName: "visit_metrics_status_time_idx";
                        readonly columns: readonly ["visit_status", "event_time"];
                        readonly purpose: "Análises por status ao longo do tempo";
                    }, {
                        readonly indexName: "visit_metrics_property_time_idx";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Análises por imóvel ao longo do tempo";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["scheduleVisitUsecase", "rescheduleVisitUsecase", "cancelVisitUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleVisitRequiresLinks"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitMetrics.defs.ts";
                readonly exportName: "visitMetricsTable";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitMetricsTable;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/archiveProperty.defs" {
    export const useCase: {
        readonly usecaseId: "archiveProperty";
        readonly title: "Inativar imóvel";
        readonly purpose: "Inativar imóvel no MDM e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyAggregate"];
        readonly outputEntities: readonly ["propertyAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "archiveProperty";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/cancelVisit.defs" {
    export const useCase: {
        readonly usecaseId: "cancelVisit";
        readonly title: "Cancelar visita";
        readonly purpose: "Cancelar visita e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitAggregate"];
        readonly outputEntities: readonly ["visitAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "cancelVisit";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createDeal.defs" {
    export const useCase: {
        readonly usecaseId: "createDeal";
        readonly title: "Criar proposta/negócio";
        readonly purpose: "Criar negócio vinculado a imóvel e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealAggregate"];
        readonly outputEntities: readonly ["dealAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "createDeal";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "stage";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "value";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleDealRequiresProperty", "ruleDealStageTransition", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createLead.defs" {
    export const useCase: {
        readonly usecaseId: "createLead";
        readonly title: "Cadastrar lead";
        readonly purpose: "Cadastrar lead no MDM e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadAggregate"];
        readonly outputEntities: readonly ["leadAggregate"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "createLead";
            readonly input: readonly [{
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "email";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "phone";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "temperature";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "stage";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleLeadTemperature", "ruleLeadStageTransition", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/createProperty.defs" {
    export const useCase: {
        readonly usecaseId: "createProperty";
        readonly title: "Cadastrar imóvel";
        readonly purpose: "Cadastrar um imóvel no MDM e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyAggregate"];
        readonly outputEntities: readonly ["propertyAggregate"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "createProperty";
            readonly input: readonly [{
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "address";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/generatePropertyDescription.defs" {
    export const useCase: {
        readonly usecaseId: "generatePropertyDescription";
        readonly title: "Gerar descrição com IA";
        readonly purpose: "Gerar descrição de imóvel a partir dos dados existentes.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyAggregate"];
        readonly outputEntities: readonly ["propertyAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "generatePropertyDescription";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "tone";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "description";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/getLead.defs" {
    export const useCase: {
        readonly usecaseId: "getLead";
        readonly title: "Carregar lead";
        readonly purpose: "Carregar detalhes de um lead para a página de detalhe.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadAggregate"];
        readonly outputEntities: readonly ["leadAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "getLead";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "lead";
                readonly type: "Lead";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/getProperty.defs" {
    export const useCase: {
        readonly usecaseId: "getProperty";
        readonly title: "Carregar imóvel";
        readonly purpose: "Carregar dados de um imóvel específico para edição e visualização.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyAggregate"];
        readonly outputEntities: readonly ["propertyAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "getProperty";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "property";
                readonly type: "Property";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listDeals.defs" {
    export const useCase: {
        readonly usecaseId: "listDeals";
        readonly title: "Listar negócios";
        readonly purpose: "Listar negócios por etapa para o pipeline de propostas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealAggregate"];
        readonly outputEntities: readonly ["dealAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Deal";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listDeals";
            readonly input: readonly [{
                readonly name: "stage";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "deals";
                readonly type: "Deal[]";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listLeads.defs" {
    export const useCase: {
        readonly usecaseId: "listLeads";
        readonly title: "Listar leads";
        readonly purpose: "Listar leads para o pipeline e filtros do corretor.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadAggregate"];
        readonly outputEntities: readonly ["leadAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listLeads";
            readonly input: readonly [{
                readonly name: "stage";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "temperature";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "query";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "leads";
                readonly type: "Lead[]";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listVisits.defs" {
    export const useCase: {
        readonly usecaseId: "listVisits";
        readonly title: "Listar visitas";
        readonly purpose: "Listar visitas para o agendador do corretor.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitAggregate"];
        readonly outputEntities: readonly ["visitAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "listVisits";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "fromDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "toDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visits";
                readonly type: "Visit[]";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/qualifyLeadWithAi.defs" {
    export const useCase: {
        readonly usecaseId: "qualifyLeadWithAi";
        readonly title: "Classificar lead com IA";
        readonly purpose: "Classificar lead e sugerir follow-up usando IA.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadAggregate"];
        readonly outputEntities: readonly ["leadAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "qualifyLeadWithAi";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "temperature";
                readonly type: "string";
            }, {
                readonly name: "nextAction";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleLeadTemperature", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/rescheduleVisit.defs" {
    export const useCase: {
        readonly usecaseId: "rescheduleVisit";
        readonly title: "Reagendar visita";
        readonly purpose: "Reagendar visita existente e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitAggregate"];
        readonly outputEntities: readonly ["visitAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "rescheduleVisit";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "scheduledAt";
                readonly type: "date";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/scheduleVisit.defs" {
    export const useCase: {
        readonly usecaseId: "scheduleVisit";
        readonly title: "Agendar visita";
        readonly purpose: "Agendar visita vinculada a imóvel e lead e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitAggregate"];
        readonly outputEntities: readonly ["visitAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "scheduleVisit";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "scheduledAt";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/searchProperties.defs" {
    export const useCase: {
        readonly usecaseId: "searchProperties";
        readonly title: "Buscar imóveis";
        readonly purpose: "Consultar imóveis por filtros para o corretor.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyAggregate"];
        readonly outputEntities: readonly ["propertyAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "searchProperties";
            readonly input: readonly [{
                readonly name: "query";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "minPrice";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "maxPrice";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "properties";
                readonly type: "Property[]";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateDealStage.defs" {
    export const useCase: {
        readonly usecaseId: "updateDealStage";
        readonly title: "Atualizar etapa do negócio";
        readonly purpose: "Atualizar etapa do negócio e refletir métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealAggregate"];
        readonly outputEntities: readonly ["dealAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Deal";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateDealStage";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "stage";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "dealId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleDealStageTransition", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateLeadNotes.defs" {
    export const useCase: {
        readonly usecaseId: "updateLeadNotes";
        readonly title: "Registrar anotações do lead";
        readonly purpose: "Registrar anotações no lead.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadAggregate"];
        readonly outputEntities: readonly ["leadAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateLeadNotes";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateLeadStage.defs" {
    export const useCase: {
        readonly usecaseId: "updateLeadStage";
        readonly title: "Mover lead no kanban";
        readonly purpose: "Atualizar estágio do lead e refletir métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadAggregate"];
        readonly outputEntities: readonly ["leadAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateLeadStage";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "stage";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleLeadStageTransition", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/updateProperty.defs" {
    export const useCase: {
        readonly usecaseId: "updateProperty";
        readonly title: "Editar imóvel";
        readonly purpose: "Atualizar informações de um imóvel e refletir métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyAggregate"];
        readonly outputEntities: readonly ["propertyAggregate"];
        readonly readsTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateProperty";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "address";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/viewDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "viewDashboard";
        readonly title: "Visualizar dashboard";
        readonly purpose: "Carregar métricas agregadas para o gestor.";
        readonly actor: "gestor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dashboardMetrics"];
        readonly outputEntities: readonly ["dashboardMetrics"];
        readonly readsTables: readonly [{
            readonly tableName: "property_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visit_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "viewDashboard";
            readonly input: readonly [{
                readonly name: "periodStart";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "periodEnd";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "metrics";
                readonly type: "DashboardMetrics";
            }];
        }];
        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
    };
    export default useCase;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102045_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102045_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102045_/l2/propertyFlowCrm/dealForm.defs" {
    export const dealFormPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealForm";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealForm";
                readonly pageName: "Criar proposta/negócio";
                readonly actor: "corretor";
                readonly purpose: "Registrar proposta/negócio com seleção de imóvel e lead antes de confirmar.";
                readonly capabilities: readonly ["trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealPipelineWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "Identificador do imóvel pré-selecionado.";
                    readonly entityRef: "Property";
                    readonly fieldRef: "propertyId";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "Identificador do lead pré-selecionado.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dealsPipeline";
                    readonly trigger: "Criar proposta/negócio";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "dealDetail";
                    readonly trigger: "Editar proposta/negócio";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Vincular imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "propertyIdInput";
                        readonly purpose: "Selecionar o imóvel obrigatório para a proposta.";
                        readonly userActions: readonly ["informarPropertyId", "limparSelecao"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["propertyId"];
                        readonly writesFields: readonly ["propertyId"];
                        readonly rulesApplied: readonly ["ruleDealRequiresProperty"];
                    }];
                }, {
                    readonly sectionName: "Vincular lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "leadIdInput";
                        readonly purpose: "Selecionar o lead relacionado à proposta (opcional).";
                        readonly userActions: readonly ["informarLeadId", "limparSelecao"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId"];
                        readonly writesFields: readonly ["leadId"];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Detalhes da proposta";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "dealTermsForm";
                        readonly purpose: "Registrar etapa inicial e valor proposto.";
                        readonly userActions: readonly ["definirStage", "informarValor"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["stage", "value"];
                        readonly writesFields: readonly ["stage", "value"];
                        readonly rulesApplied: readonly ["ruleDealStageTransition", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Confirmar proposta/negócio";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "dealCreateConfirmation";
                        readonly purpose: "Confirmar e criar a proposta/negócio.";
                        readonly userActions: readonly ["confirmarCriacao"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["propertyId", "leadId", "stage", "value"];
                        readonly writesFields: readonly ["dealId"];
                        readonly rulesApplied: readonly ["ruleDealRequiresProperty", "ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "createDeal";
                readonly purpose: "Criar proposta/negócio.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "value";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["propertyAggregate", "leadAggregate"];
                readonly writesEntities: readonly ["dealAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["deal_metrics"];
                readonly usecaseRefs: readonly ["createDeal"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealRequiresProperty", "ruleDealStageTransition", "ruleBrokerPermissions"];
            }];
        };
    };
    export default dealFormPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/dealsPipeline.defs" {
    export const dealsPipelinePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealsPipeline";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealsPipeline";
                readonly pageName: "Pipeline de negócios";
                readonly actor: "corretor";
                readonly purpose: "Gerenciar propostas e negócios por etapas.";
                readonly capabilities: readonly ["trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealPipelineWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dealDetail";
                    readonly trigger: "Abrir negócio";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dealForm";
                    readonly trigger: "Criar proposta/negócio";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Pipeline por etapas";
                    readonly mode: "kanban";
                    readonly organisms: readonly [{
                        readonly organismName: "dealPipelineBoard";
                        readonly purpose: "Visualizar negócios agrupados por etapa e permitir movimentação entre etapas.";
                        readonly userActions: readonly ["visualizarNegocio", "moverNegocioDeEtapa", "abrirNegocio"];
                        readonly requiredEntities: readonly ["Deal", "Property", "Lead"];
                        readonly readsFields: readonly ["Deal.id", "Deal.stage", "Deal.value", "Deal.propertyId", "Deal.leadId", "Property.id", "Property.title", "Lead.id", "Lead.name"];
                        readonly writesFields: readonly ["Deal.stage"];
                        readonly rulesApplied: readonly ["ruleDealStageTransition", "ruleDealRequiresProperty", "ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listDeals";
                readonly purpose: "Listar negócios por etapa para o pipeline.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "deals";
                    readonly type: "Deal[]";
                }];
                readonly readsEntities: readonly ["dealAggregate", "propertyAggregate", "leadAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listDeals"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }, {
                readonly commandName: "updateDealStage";
                readonly purpose: "Atualizar etapa do negócio ao mover no pipeline.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["dealAggregate"];
                readonly writesEntities: readonly ["dealAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["deal_metrics"];
                readonly usecaseRefs: readonly ["updateDealStage"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealStageTransition", "ruleBrokerPermissions"];
            }];
        };
    };
    export default dealsPipelinePagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadDetail.defs" {
    export const leadDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadDetail";
                readonly pageName: "Detalhe do lead";
                readonly actor: "corretor";
                readonly purpose: "Visualizar e atualizar informações do lead.";
                readonly capabilities: readonly ["manageLeads"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadPipelineWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador do lead para carregar os detalhes.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadsKanban";
                    readonly trigger: "Abrir lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadForm";
                    readonly trigger: "Editar lead";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do lead";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "leadSummaryCard";
                        readonly purpose: "Exibir dados principais do lead.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "name", "phone", "email", "stage", "temperature"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleLeadTemperature", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Estágio do lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "leadStageUpdater";
                        readonly purpose: "Atualizar o estágio do lead no pipeline.";
                        readonly userActions: readonly ["updateLeadStage"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "stage"];
                        readonly writesFields: readonly ["stage"];
                        readonly rulesApplied: readonly ["ruleLeadStageTransition", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Anotações";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "leadNotesEditor";
                        readonly purpose: "Registrar e atualizar anotações do lead.";
                        readonly userActions: readonly ["updateLeadNotes"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["leadId", "notes"];
                        readonly writesFields: readonly ["notes"];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getLead";
                readonly purpose: "Carregar dados do lead.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "lead";
                    readonly type: "Lead";
                }];
                readonly readsEntities: readonly ["leadAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }, {
                readonly commandName: "updateLeadStage";
                readonly purpose: "Atualizar o estágio do lead.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadAggregate"];
                readonly writesEntities: readonly ["leadAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_metrics"];
                readonly usecaseRefs: readonly ["updateLeadStage"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadStageTransition", "ruleBrokerPermissions"];
            }, {
                readonly commandName: "updateLeadNotes";
                readonly purpose: "Atualizar anotações do lead.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadAggregate"];
                readonly writesEntities: readonly ["leadAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_metrics"];
                readonly usecaseRefs: readonly ["updateLeadNotes"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }];
        };
    };
    export default leadDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadsKanban.defs" {
    export const leadsKanbanPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadsKanban";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadsKanban";
                readonly pageName: "Pipeline de leads";
                readonly actor: "corretor";
                readonly purpose: "Gerenciar leads por etapas no kanban.";
                readonly capabilities: readonly ["manageLeads"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadPipelineWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "leadDetail";
                    readonly trigger: "Abrir lead";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "leadForm";
                    readonly trigger: "Cadastrar lead";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e busca";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadFilters";
                        readonly purpose: "Filtrar leads por estágio, temperatura e texto.";
                        readonly userActions: readonly ["filtrarLeads", "buscarLeads"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.stage", "Lead.temperature", "Lead.name", "Lead.email", "Lead.phone"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Kanban de leads";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadsKanbanBoard";
                        readonly purpose: "Visualizar leads por estágio e mover entre colunas.";
                        readonly userActions: readonly ["moverLeadNoKanban", "abrirLead"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.id", "Lead.name", "Lead.stage", "Lead.temperature", "Lead.lastContactAt"];
                        readonly writesFields: readonly ["Lead.stage"];
                        readonly rulesApplied: readonly ["ruleLeadStageTransition", "ruleLeadTemperature", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Anotações rápidas";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadNotesInlineEditor";
                        readonly purpose: "Registrar anotações rápidas no lead selecionado.";
                        readonly userActions: readonly ["registrarNota"];
                        readonly requiredEntities: readonly ["Lead"];
                        readonly readsFields: readonly ["Lead.id", "Lead.notes"];
                        readonly writesFields: readonly ["Lead.notes"];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listLeads";
                readonly purpose: "Listar leads para o kanban.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "temperature";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "query";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leads";
                    readonly type: "Lead[]";
                }];
                readonly readsEntities: readonly ["leadAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }, {
                readonly commandName: "updateLeadStage";
                readonly purpose: "Mover lead no kanban.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadAggregate"];
                readonly writesEntities: readonly ["leadAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_metrics"];
                readonly usecaseRefs: readonly ["updateLeadStage"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadStageTransition", "ruleBrokerPermissions"];
            }, {
                readonly commandName: "updateLeadNotes";
                readonly purpose: "Registrar anotações do lead.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadAggregate"];
                readonly writesEntities: readonly ["leadAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_metrics"];
                readonly usecaseRefs: readonly ["updateLeadNotes"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }];
        };
    };
    export default leadsKanbanPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/managerDashboard.defs" {
    export const managerDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "managerDashboard";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "managerDashboard";
                readonly pageName: "Dashboard de métricas";
                readonly actor: "gestor";
                readonly purpose: "Visualizar métricas básicas de imóveis, leads, visitas e negócios.";
                readonly capabilities: readonly ["viewDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data inicial opcional para filtrar métricas.";
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data final opcional para filtrar métricas.";
                }];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de período";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Seletor de intervalo";
                        readonly purpose: "Definir o período para atualização das métricas.";
                        readonly userActions: readonly ["filtrarPeriodo"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Resumo de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Cards de KPIs";
                        readonly purpose: "Exibir totais e variações das métricas principais.";
                        readonly userActions: readonly ["visualizarMetricas"];
                        readonly requiredEntities: readonly ["dashboardMetrics"];
                        readonly readsFields: readonly ["dashboardMetrics.propertyTotals", "dashboardMetrics.leadTotals", "dashboardMetrics.visitTotals", "dashboardMetrics.dealTotals"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Tendências por período";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Gráficos de séries temporais";
                        readonly purpose: "Mostrar séries e tendências de imóveis, leads, visitas e negócios.";
                        readonly userActions: readonly ["visualizarSeries"];
                        readonly requiredEntities: readonly ["dashboardMetrics"];
                        readonly readsFields: readonly ["dashboardMetrics.propertySeries", "dashboardMetrics.leadSeries", "dashboardMetrics.visitSeries", "dashboardMetrics.dealSeries"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getDashboardMetrics";
                readonly purpose: "Carregar métricas consolidadas para o gestor.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "metrics";
                    readonly type: "DashboardMetrics";
                }];
                readonly readsEntities: readonly ["dashboardMetrics"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["property_metrics", "lead_metrics", "visit_metrics", "deal_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }];
        };
    };
    export default managerDashboardPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertiesList.defs" {
    export const propertiesListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertiesList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertiesList";
                readonly pageName: "Imóveis";
                readonly actor: "corretor";
                readonly purpose: "Listar e buscar imóveis cadastrados.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycleWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyDetail";
                    readonly trigger: "Selecionar imóvel";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyForm";
                    readonly trigger: "Cadastrar imóvel";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Busca e filtros";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "propertySearchFilters";
                        readonly purpose: "Filtrar imóveis por texto, faixa de preço e status.";
                        readonly userActions: readonly ["searchProperties"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.title", "Property.address", "Property.price", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Lista de imóveis";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "propertiesListResults";
                        readonly purpose: "Exibir imóveis encontrados e permitir seleção para ver detalhes.";
                        readonly userActions: readonly ["Selecionar imóvel"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Property.address", "Property.price", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listProperties";
                readonly purpose: "Listar imóveis com filtros e paginação para o corretor.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "query";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "minPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "maxPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "properties";
                    readonly type: "Property[]";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["searchProperties"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }];
        };
    };
    export default propertiesListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertyDetail.defs" {
    export const propertyDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 64;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyDetail";
                readonly pageName: "Detalhe do imóvel";
                readonly actor: "corretor";
                readonly purpose: "Visualizar informações completas do imóvel.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycleWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do imóvel para carregar detalhes.";
                    readonly entityRef: "Property";
                    readonly fieldRef: "Property.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "propertiesList";
                    readonly trigger: "Selecionar imóvel";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "propertyForm";
                    readonly trigger: "Editar imóvel";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do imóvel";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "propertySummaryCard";
                        readonly purpose: "Exibir informações principais do imóvel.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.id", "Property.title", "Property.address", "Property.price", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Detalhes completos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "propertyDetailsPanel";
                        readonly purpose: "Exibir dados completos do imóvel para consulta.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.title", "Property.address", "Property.price", "Property.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Ações do imóvel";
                    readonly mode: "interaction";
                    readonly organisms: readonly [{
                        readonly organismName: "propertyActionsBar";
                        readonly purpose: "Permitir editar ou inativar o imóvel.";
                        readonly userActions: readonly ["updateProperty", "archiveProperty"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.id", "Property.status"];
                        readonly writesFields: readonly ["Property.status"];
                        readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getProperty";
                readonly purpose: "Carregar dados do imóvel para visualização.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "property";
                    readonly type: "Property";
                }];
                readonly readsEntities: readonly ["propertyAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getProperty"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }, {
                readonly commandName: "updateProperty";
                readonly purpose: "Atualizar informações do imóvel a partir do detalhe.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["propertyAggregate"];
                readonly writesEntities: readonly ["propertyAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_metrics"];
                readonly usecaseRefs: readonly ["updateProperty"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
            }, {
                readonly commandName: "archiveProperty";
                readonly purpose: "Inativar o imóvel a partir do detalhe.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["propertyAggregate"];
                readonly writesEntities: readonly ["propertyAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_metrics"];
                readonly usecaseRefs: readonly ["archiveProperty"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatus", "ruleBrokerPermissions"];
            }];
        };
    };
    export default propertyDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitDetail.defs" {
    export const visitDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitDetail";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 67;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitDetail";
                readonly pageName: "Detalhe da visita";
                readonly actor: "corretor";
                readonly purpose: "Ver detalhes e atualizar visita.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycleWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["visitReminderAutomation"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador da visita selecionada.";
                    readonly entityRef: "visitAggregate";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "visitsCalendar";
                    readonly trigger: "Selecionar visita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitForm";
                    readonly trigger: "Reagendar visita";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo da visita";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "visitDetailCard";
                        readonly purpose: "Exibir dados principais da visita e status.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["visitAggregate"];
                        readonly readsFields: readonly ["visitId", "scheduledAt", "status", "leadId", "propertyId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
                    }];
                }, {
                    readonly sectionName: "Vínculos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "linkedLeadSummary";
                        readonly purpose: "Exibir dados resumidos do lead vinculado.";
                        readonly userActions: readonly ["Abrir lead"];
                        readonly requiredEntities: readonly ["leadAggregate"];
                        readonly readsFields: readonly ["leadId", "name", "phone", "email"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitRequiresLinks"];
                    }, {
                        readonly organismName: "linkedPropertySummary";
                        readonly purpose: "Exibir dados resumidos do imóvel vinculado.";
                        readonly userActions: readonly ["Abrir imóvel"];
                        readonly requiredEntities: readonly ["propertyAggregate"];
                        readonly readsFields: readonly ["propertyId", "title", "address", "price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitRequiresLinks"];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "rescheduleVisitPanel";
                        readonly purpose: "Reagendar data e hora da visita.";
                        readonly userActions: readonly ["Reagendar visita"];
                        readonly requiredEntities: readonly ["visitAggregate"];
                        readonly readsFields: readonly ["visitId", "scheduledAt"];
                        readonly writesFields: readonly ["scheduledAt"];
                        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
                    }, {
                        readonly organismName: "cancelVisitPanel";
                        readonly purpose: "Cancelar a visita com motivo opcional.";
                        readonly userActions: readonly ["Cancelar visita"];
                        readonly requiredEntities: readonly ["visitAggregate"];
                        readonly readsFields: readonly ["visitId"];
                        readonly writesFields: readonly ["status", "cancelReason"];
                        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getVisit";
                readonly purpose: "Carregar dados da visita e vínculos.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "leadPhone";
                    readonly type: "string";
                }, {
                    readonly name: "leadEmail";
                    readonly type: "string";
                }, {
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "propertyTitle";
                    readonly type: "string";
                }, {
                    readonly name: "propertyAddress";
                    readonly type: "string";
                }, {
                    readonly name: "propertyPrice";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["visitAggregate", "leadAggregate", "propertyAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
            }, {
                readonly commandName: "rescheduleVisit";
                readonly purpose: "Reagendar visita selecionada.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "date";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitAggregate"];
                readonly writesEntities: readonly ["visitAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit_metrics"];
                readonly usecaseRefs: readonly ["rescheduleVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
            }, {
                readonly commandName: "cancelVisit";
                readonly purpose: "Cancelar visita selecionada.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitAggregate"];
                readonly writesEntities: readonly ["visitAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit_metrics"];
                readonly usecaseRefs: readonly ["cancelVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
            }];
        };
    };
    export default visitDetailPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitsCalendar.defs" {
    export const visitsCalendarPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitsCalendar";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitsCalendar";
                readonly pageName: "Agenda de visitas";
                readonly actor: "corretor";
                readonly purpose: "Visualizar e gerenciar visitas agendadas.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitLifecycleWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["visitReminderAutomation"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "visitForm";
                    readonly trigger: "Agendar visita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "visitDetail";
                    readonly trigger: "Selecionar visita";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Calendário de visitas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Filtro de período e status";
                        readonly purpose: "Definir intervalo e filtros para listar visitas.";
                        readonly userActions: readonly ["Filtrar por período", "Filtrar por status", "Filtrar por imóvel", "Filtrar por lead"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.scheduledAt", "Visit.status", "Visit.propertyId", "Visit.leadId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }, {
                        readonly organismName: "Grade de calendário";
                        readonly purpose: "Exibir visitas no calendário e permitir seleção para ações.";
                        readonly userActions: readonly ["Selecionar visita", "Abrir detalhe da visita"];
                        readonly requiredEntities: readonly ["Visit", "Property", "Lead"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.scheduledAt", "Visit.status", "Visit.propertyId", "Visit.leadId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleBrokerPermissions"];
                    }, {
                        readonly organismName: "Ações rápidas da visita";
                        readonly purpose: "Reagendar ou cancelar visitas diretamente no calendário.";
                        readonly userActions: readonly ["Reagendar visita", "Cancelar visita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.scheduledAt", "Visit.status"];
                        readonly writesFields: readonly ["Visit.scheduledAt", "Visit.status"];
                        readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listVisits";
                readonly purpose: "Listar visitas para o período e filtros do calendário.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "fromDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "toDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visits";
                    readonly type: "Visit[]";
                }];
                readonly readsEntities: readonly ["visitAggregate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listVisits"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleBrokerPermissions"];
            }, {
                readonly commandName: "rescheduleVisit";
                readonly purpose: "Reagendar uma visita selecionada no calendário.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "date";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitAggregate"];
                readonly writesEntities: readonly ["visitAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit_metrics"];
                readonly usecaseRefs: readonly ["rescheduleVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
            }, {
                readonly commandName: "cancelVisit";
                readonly purpose: "Cancelar uma visita selecionada no calendário.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["visitAggregate"];
                readonly writesEntities: readonly ["visitAggregate"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit_metrics"];
                readonly usecaseRefs: readonly ["cancelVisit"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitRequiresLinks", "ruleBrokerPermissions"];
            }];
        };
    };
    export default visitsCalendarPagePlan;
}
